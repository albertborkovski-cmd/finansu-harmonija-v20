import { useEffect, useState, type RefObject } from 'react';
import { createPortal } from 'react-dom';
import WorkspaceExpandButton from './WorkspaceExpandButton';
import useWorkspaceExpansion from '../hooks/useWorkspaceExpansion';

/** Expands the existing list without remounting filters or selected records. */
export default function TableWorkspaceExpand({ scrollRef, scrollbarRef }: {
  scrollRef?: RefObject<HTMLElement>;
  scrollbarRef: RefObject<HTMLElement>;
}) {
  const [target, setTarget] = useState<{ root: HTMLElement; toolbar: HTMLElement; viewport: HTMLElement }>();
  const [expanded, setExpanded] = useState(false);
  useEffect(() => {
    const scrollbar = scrollbarRef.current;
    const viewport = scrollRef?.current ?? scrollbar?.previousElementSibling as HTMLElement | null;
    if (!scrollbar || !viewport || viewport.closest('[data-reconciliation-workspace]')) return;
    let root = viewport.parentElement;
    let candidate: { root: HTMLElement; toolbar: HTMLElement; viewport: HTMLElement } | undefined;
    while (root && !root.matches('[data-app-main], body')) {
      // Never expand a neighbouring list or an entire multi-panel dashboard.
      if ([...root.querySelectorAll('[data-table-scrollbar]')].filter(element => !element.closest('[role="dialog"], [aria-modal="true"]')).length > 1) break;
      const candidateRoot = candidate?.root;
      if (candidateRoot && [...root.querySelectorAll('aside')].some(panel => !candidateRoot.contains(panel) && !['fixed', 'absolute'].includes(getComputedStyle(panel).position))) break;
      const toolbar = candidate?.toolbar ?? root.querySelector<HTMLElement>('[data-table-workspace-tools]')
        ?? root.querySelector<HTMLElement>('button[data-button-family="column-settings"]')?.parentElement;
      if (root.contains(scrollbar) && toolbar) {
        if (toolbar.querySelector('[data-button-family="workspace-expand"]')) return;
        candidate = { root, toolbar, viewport };
        // Include the page actions as well as filters, but not neighbouring panels.
        if (root.querySelector('[data-system-page-header]')) break;
      }
      if (root.matches('[role="dialog"], [aria-modal="true"]')) break;
      root = root.parentElement;
    }
    if (candidate) { setTarget(candidate); return; }
    if (viewport.parentElement?.contains(scrollbar)) {
      // Lists without column tools get a top-right tools row, never a footer control.
      const toolbar = document.createElement('div');
      toolbar.className = 'flex h-7 min-h-7 shrink-0 items-center justify-end gap-4';
      toolbar.setAttribute('data-table-workspace-tools', '');
      viewport.parentElement.insertBefore(toolbar, viewport);
      setTarget({ root: viewport.parentElement, toolbar, viewport });
      return () => toolbar.remove();
    }
  }, [scrollRef, scrollbarRef]);

  useWorkspaceExpansion(expanded, target?.root, setExpanded);

  if (!target) return null;
  return createPortal(<WorkspaceExpandButton expanded={expanded} onClick={() => setExpanded(value => !value)} />, target.toolbar);
}
