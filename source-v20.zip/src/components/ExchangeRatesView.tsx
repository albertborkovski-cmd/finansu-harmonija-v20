import { useMemo, useRef, useState } from 'react';
import { Download, Pencil, X } from 'lucide-react';
import { usePersistentState } from '../hooks/usePersistentState';
import { PageHeader, PageActionButton } from './PageHeader';
import OrganizationReferenceValuesView, { loadOrganizationReferenceRecords } from './OrganizationReferenceValuesView';
import SearchableSelect from './SearchableSelect';
import OcrSearchField from './OcrSearchField';
import SystemAddFilters from './SystemAddFilters';
import ColumnSettingsPanel, { type ColConfig } from './ColumnSettingsPanel';
import { ColumnSettingsButton } from './ScopedActionButtons';
import ColumnSortButton, { useMultiColumnSort } from './ColumnSortButton';
import { ResizeHandle, useColumnResize } from './useColumnResize';
import RefreshAllButton from './RefreshAllButton';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
import TablePagination from './TablePagination';

type Rate = { id: string; currency: string; code: string; date: string; quantity: number; rate: number };
type RateRow = Omit<Rate, 'rate'> & { rate: number | null; missing?: boolean };
const KEY = 'finansu-harmonija:v19:exchange-rates';
const COLUMNS: ColConfig[] = [
  { key: 'currency', label: 'Currency', width: 240, visible: true },
  { key: 'code', label: 'Code', width: 90, visible: true },
  { key: 'date', label: 'Exchange date', width: 150, visible: true },
  { key: 'quantity', label: 'Quantity', width: 100, visible: true },
  { key: 'rate', label: 'Rate', width: 150, visible: true },
  { key: 'id', label: 'ID', width: 260, visible: false },
];
const inputClass = 'h-10 w-full rounded-lg border border-[#D3E1EC] bg-white px-3 text-[13px] text-[#10233A]';

export default function ExchangeRatesView({ initialTab = 'manual' }: { initialTab?: 'currency' | 'manual' | 'ecb' }) {
  const [rates, setRates] = usePersistentState<Rate[]>(KEY, []);
  const [columns, setColumns] = usePersistentState<ColConfig[]>(`${KEY}:columns`, COLUMNS);
  const [tab, setTab] = useState<'currency' | 'manual' | 'ecb'>(initialTab);
  const [query, setQuery] = useState('');
  const [filterKeys, setFilterKeys] = useState<string[]>([]);
  const [filters, setFilters] = useState<Record<string, string[]>>({});
  const [showColumns, setShowColumns] = useState(false);
  const [page, setPage] = useState(1);
  const [draft, setDraft] = useState<Rate | null>(null);
  const [error, setError] = useState('');
  const tableRef = useRef<HTMLDivElement>(null);
  const { startResize } = useColumnResize(columns, setColumns);
  const currencies = loadOrganizationReferenceRecords('Base currency').filter(row => row.status !== 'Inactive');
  const source: RateRow[] = tab === 'manual' ? [
    ...rates,
    ...currencies.filter(currency => !rates.some(rate => rate.code === currency.code)).map(currency => ({
      id: `missing:${currency.code}`, currency: currency.fullName, code: currency.code,
      date: '', quantity: 1, rate: null, missing: true,
    })),
  ] : [];
  const cellValue = (row: RateRow, key: keyof Rate) => row.missing && (key === 'id' || key === 'date') ? '' : row[key] ?? '';
  const filtered = useMemo(() => source.filter(row =>
    Object.values(row).join(' ').toLowerCase().includes(query.toLowerCase()) &&
    filterKeys.every(key => !filters[key]?.length || filters[key].includes(String(cellValue(row, key as keyof Rate))))
  ), [source, query, filterKeys, filters]);
  const sorter = useMultiColumnSort<RateRow, keyof Rate>(filtered, (row, key) => cellValue(row, key));
  const visible = columns.filter(column => column.visible);
  const grid = `${visible.map(column => `${column.width}px`).join(' ')} minmax(48px, 1fr)`;
  const exportRows = () => {
    const csv = [visible.map(column => column.label), ...sorter.sortedRows.map(row => visible.map(column => String(cellValue(row, column.key as keyof Rate))))];
    const url = URL.createObjectURL(new Blob(['\uFEFF' + csv.map(row => row.map(value => `"${value.replace(/"/g, '""')}"`).join(',')).join('\r\n')], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a'); link.href = url; link.download = 'exchange-rates.csv'; link.click(); URL.revokeObjectURL(url);
  };
  const save = () => {
    if (!draft) return;
    if (!draft.code || !draft.date || !Number.isFinite(draft.quantity) || draft.quantity <= 0 || !Number.isFinite(draft.rate) || draft.rate <= 0) { setError('Select a currency and date, and enter a positive quantity and rate.'); return; }
    if (rates.some(row => row.id !== draft.id && row.code === draft.code && row.date === draft.date)) { setError('A rate for this currency and date already exists. Edit the existing record.'); return; }
    setRates(current => [...current.filter(row => row.id !== draft.id), draft].sort((a, b) => b.date.localeCompare(a.date)));
    setDraft(null);
  };
  const navigation = <div role="tablist" aria-label="Currency settings" className="flex gap-1 border-b border-[#D3E1EC]">
    {(['currency', 'manual', 'ecb'] as const).map(value => <button key={value} role="tab" aria-selected={tab === value} onClick={() => { setTab(value); setPage(1); }} className={`border-b-2 px-4 py-3 text-[13px] font-medium ${tab === value ? 'border-[#007EA7] text-[#007EA7]' : 'border-transparent text-[#7288A3]'}`}>{value === 'currency' ? 'Currency' : value === 'manual' ? 'Exchange rates' : 'ECB exchange rates'}</button>)}
  </div>;
  if (tab === 'currency') return <OrganizationReferenceValuesView section="Base currency" displayTitle="Currency" breadcrumbParents={['Settings', 'General settings']} navigation={navigation} />;
  return <main className="flex h-screen min-w-0 flex-col gap-8 overflow-hidden bg-white py-14 font-montserrat" style={{ paddingLeft: 'clamp(24px, 5vw, 72px)', paddingRight: 'clamp(24px, 5vw, 72px)' }}>
    <PageHeader title={tab === 'ecb' ? 'ECB exchange rates' : 'Exchange rates'} actions={tab === 'manual' ? <PageActionButton onClick={() => { setError(''); setDraft({ id: crypto.randomUUID(), code: '', currency: '', date: '', quantity: 1, rate: 1 }); }}>Create new</PageActionButton> : undefined} />
    <div data-system-breadcrumb className="flex items-center gap-2 font-montserrat text-[12px] font-medium text-[#7288A3]"><span>Settings</span><span>/</span><span>General settings</span><span>/</span><span className="text-[#A1B6C6]">{tab === 'ecb' ? 'ECB exchange rates' : 'Exchange rates'}</span></div>
    {navigation}
    <div className="flex flex-wrap items-center justify-between gap-4">
      <div className="flex min-w-0 flex-1 flex-wrap items-center gap-1">
        <OcrSearchField ariaLabel="Search exchange rates" value={query} onChange={value => { setQuery(value); setPage(1); }} className="!w-[260px] !min-w-[260px] !max-w-[260px] !flex-none" />
        <SystemAddFilters columns={COLUMNS.map(column => ({ key: column.key, label: column.label, options: [...new Set(source.map(row => String(cellValue(row, column.key as keyof Rate))))].filter(Boolean) }))} activeKeys={filterKeys} values={filters} onActiveKeysChange={setFilterKeys} onValuesChange={value => { setFilters(value); setPage(1); }} />
      </div>
      <div data-table-workspace-tools className="ml-auto flex h-7 shrink-0 items-center gap-4">
        <ColumnSettingsButton onClick={() => setShowColumns(true)} />
        <button aria-label="EXPORT" title="EXPORT" data-button-family="export" onClick={exportRows} className="text-[#7288A3]"><Download size={16} /></button>
        <RefreshAllButton onRefresh={() => { try { setRates(JSON.parse(localStorage.getItem(KEY) || '[]')); } catch { /* Keep the current records if storage is unavailable. */ } }} />
      </div>
    </div>
    <div ref={tableRef} className="min-h-0 flex-1 overflow-auto scrollbar-hide">
      <div style={{ minWidth: visible.reduce((sum, column) => sum + column.width, 48) }}>
        <div className="system-table-header-row mb-3 grid h-6 items-center text-[12px] font-medium text-[#10233A]" style={{ gridTemplateColumns: grid }}>
          {visible.map(column => <div key={column.key} className="relative flex items-center gap-1 border-l border-[#D3E1EC] px-3">{column.label}<ColumnSortButton columnLabel={column.label} direction={sorter.directionFor(column.key as keyof Rate)} onDirectionChange={direction => sorter.changeSort(column.key as keyof Rate, direction)} /><ResizeHandle onMouseDown={event => startResize(columns.findIndex(item => item.key === column.key), event)} /></div>)}<span />
        </div>
        {sorter.sortedRows.slice(0, page * 50).map((row, index) => <div key={row.id} style={{ gridTemplateColumns: grid }} className={`mb-0.5 grid h-10 items-center rounded-lg text-[12px] text-[#10233A] hover:bg-[#E7F4F9] ${index % 2 ? 'bg-white' : 'bg-[#F8FDFF]'}`}>
          {visible.map(column => <span key={column.key} className="truncate px-3" title={column.key === 'rate' && row.missing ? 'Rate not entered' : String(cellValue(row, column.key as keyof Rate))}>{column.key === 'rate' ? row.rate?.toLocaleString('en-GB', { maximumFractionDigits: 10 }) ?? '—' : cellValue(row, column.key as keyof Rate) || '—'}</span>)}
          <div className="system-table-row-actions flex h-10 items-center justify-end px-2"><button aria-label={`${row.missing ? 'Add rate for' : 'Edit'} ${row.code} ${row.date}`.trim()} title={row.missing ? 'Add exchange rate' : 'Edit exchange rate'} className="flex h-4 w-4 shrink-0 items-center justify-center text-[#7288A3] transition-colors hover:text-[#007EA7]" onClick={() => { setError(''); setDraft({ id: row.missing ? crypto.randomUUID() : row.id, currency: row.currency, code: row.code, date: row.date, quantity: row.quantity, rate: row.rate ?? 1 }); }}><Pencil size={16} /></button></div>
        </div>)}
        {!filtered.length && <p className="py-12 text-center text-[13px] text-[#7288A3]">{tab === 'ecb' ? 'No ECB rates available. ECB synchronization is not connected.' : 'No exchange rates found.'}</p>}
      </div>
    </div>
    <HorizontalTableScrollbar scrollRef={tableRef} />
    <TablePagination currentPage={page} totalPages={Math.max(1, Math.ceil(filtered.length / 50))} itemCount={filtered.length} onPageChange={setPage} scrollRef={tableRef} />
    {showColumns && <ColumnSettingsPanel columns={columns} defaultColumns={COLUMNS} onSave={value => { setColumns(value); setShowColumns(false); }} onClose={() => setShowColumns(false)} />}
    {draft && <div className="fixed inset-0 z-[300] flex items-center justify-center bg-[#10233A]/30 p-4" onMouseDown={event => { if (event.target === event.currentTarget) setDraft(null); }}>
      <form role="dialog" aria-modal="true" aria-label="Exchange rate" onSubmit={event => { event.preventDefault(); save(); }} onKeyDown={event => { if (event.key === 'Escape') setDraft(null); }} className="flex w-full max-w-[520px] flex-col gap-5 rounded-xl border border-[#D3E1EC] bg-white p-6 shadow-xl">
        <div className="flex items-center justify-between"><h2 className="text-lg font-semibold">Exchange rate</h2><button type="button" aria-label="Close exchange rate" onClick={() => setDraft(null)}><X size={20} /></button></div>
        <label className="text-[13px]">Currency *<SearchableSelect value={draft.code} ariaLabel="Currency" options={currencies.map(currency => ({ value: currency.code, label: `${currency.code} — ${currency.fullName}` }))} onChange={code => setDraft({ ...draft, code, currency: currencies.find(currency => currency.code === code)?.fullName || code })} /></label>
        <label className="text-[13px]">Exchange date *<input aria-label="Exchange date" type="date" required value={draft.date} onChange={event => setDraft({ ...draft, date: event.target.value })} className={inputClass} /></label>
        <div className="grid grid-cols-2 gap-4">{(['quantity', 'rate'] as const).map(key => <label key={key} className="text-[13px]">{key === 'quantity' ? 'Quantity (EUR)' : 'Rate'} *<input aria-label={key === 'quantity' ? 'Quantity' : 'Rate'} type="number" min="0.0000000001" step="any" required value={draft[key]} onChange={event => setDraft({ ...draft, [key]: Number(event.target.value) })} className={inputClass} /></label>)}</div>
        {error && <p role="alert" className="text-[12px] text-red-600">{error}</p>}
        <div className="flex justify-end gap-2"><button type="button" onClick={() => setDraft(null)} className="rounded border border-[#D3E1EC] px-4 py-2 text-[13px] text-[#7288A3]">Cancel</button><button type="submit" className="rounded border border-[#D3E1EC] px-4 py-2 text-[13px] text-[#7288A3] active:bg-[#007EA7] active:text-white">Save</button></div>
      </form>
    </div>}
  </main>;
}
