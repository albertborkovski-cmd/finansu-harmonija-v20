import { useState } from 'react';
import { X } from 'lucide-react';
import type { CustomerPrice, RecurringContract, StockItem, StockLocation, WarehouseStore } from '../lib/warehouse';
import SearchableSelect from './SearchableSelect';
import { CancelButton, SaveButton } from './ScopedActionButtons';
import { warehouseInput, WarehouseField } from './WarehouseDocumentEditor';

export type WarehouseMasterCollection = 'items' | 'locations' | 'prices' | 'contracts';
export type WarehouseMasterRecord = StockItem | StockLocation | CustomerPrice | RecurringContract;
type Field = { key: string; label: string; type?: 'number' | 'date'; options?: string[] | { value: string; label: string }[] };
export default function WarehouseMasterEditor({ collection, record, store, onSave, onClose }: { collection: WarehouseMasterCollection; record: WarehouseMasterRecord; store: WarehouseStore; onSave: (record: WarehouseMasterRecord) => void; onClose: () => void }) {
  const [draft, setDraft] = useState<Record<string, unknown>>({ ...record });
  const [error, setError] = useState('');
  const items = store.items.filter(row => !row.inactive).map(row => ({ value: row.id, label: `${row.code} · ${row.name}` }));
  const locations = store.locations.filter(row => !row.inactive).map(row => ({ value: row.id, label: row.name }));
  const fields: Field[] = collection === 'items' ? [
    { key: 'code', label: 'Code *' }, { key: 'name', label: 'Name *' }, { key: 'type', label: 'Item type', options: ['Product', 'Service'] },
    { key: 'group', label: 'Group' }, { key: 'barcode', label: 'Barcode' }, { key: 'unit', label: 'Unit *', options: ['pcs', 'kg', 'l', 'm', 'hour', 'month', 'pack'] },
    { key: 'salePrice', label: 'Sale price, EUR', type: 'number' }, { key: 'vatRate', label: 'VAT rate %', type: 'number' }, { key: 'minimumStock', label: 'Minimum stock', type: 'number' },
    { key: 'stockAccount', label: 'Stock GL account' }, { key: 'salesAccount', label: 'Sales GL account' }, { key: 'costAccount', label: 'Cost GL account' },
  ] : collection === 'locations' ? [{ key: 'code', label: 'Warehouse code *' }, { key: 'name', label: 'Name *' }, { key: 'address', label: 'Address' }]
    : collection === 'prices' ? [{ key: 'counterparty', label: 'Counterparty *' }, { key: 'itemId', label: 'Item *', options: items }, { key: 'unitPrice', label: 'Unit price, EUR *', type: 'number' }, { key: 'discount', label: 'Discount %', type: 'number' }, { key: 'validFrom', label: 'Valid from *', type: 'date' }, { key: 'validTo', label: 'Valid to', type: 'date' }]
      : [{ key: 'number', label: 'Contract No. *' }, { key: 'counterparty', label: 'Counterparty *' }, { key: 'warehouseId', label: 'Warehouse *', options: locations }, { key: 'itemId', label: 'Item *', options: items }, { key: 'quantity', label: 'Quantity *', type: 'number' }, { key: 'unitPrice', label: 'Unit price, EUR *', type: 'number' }, { key: 'frequency', label: 'Frequency', options: ['Monthly', 'Quarterly', 'Yearly'] }, { key: 'startDate', label: 'Start date *', type: 'date' }, { key: 'endDate', label: 'End date', type: 'date' }, { key: 'nextDate', label: 'Next invoice date *', type: 'date' }];
  const title = { items: 'Item / service', locations: 'Warehouse', prices: 'Customer price', contracts: 'Recurring contract' }[collection];
  return <div className="fixed inset-0 z-[250] flex items-center justify-center bg-[#10233A]/35 p-5"><section role="dialog" aria-modal="true" aria-label={title} className="flex max-h-[90dvh] w-full max-w-[700px] flex-col rounded-xl border border-[#D3E1EC] bg-white font-montserrat shadow-2xl">
    <header className="flex items-center justify-between border-b border-[#E5EDF9] px-6 py-4"><h2 className="text-[20px] font-semibold text-[#10233A]">{title}</h2><button aria-label="Close form" className="text-[#7288A3]" onClick={onClose}><X size={20} /></button></header>
    <div className="grid min-h-0 gap-4 overflow-auto p-6 sm:grid-cols-2">{error && <p role="alert" className="text-[12px] text-red-700 sm:col-span-2">{error}</p>}{fields.map(field => <WarehouseField key={field.key} label={field.label}>{field.options ? <SearchableSelect ariaLabel={field.label} className={warehouseInput} value={String(draft[field.key] ?? '')} options={field.options} onChange={value => setDraft(current => ({ ...current, [field.key]: value }))} /> : <input aria-label={field.label} className={warehouseInput} type={field.type ?? 'text'} step={field.type === 'number' ? 'any' : undefined} min={field.type === 'number' ? 0 : undefined} value={String(draft[field.key] ?? '')} onChange={event => setDraft(current => ({ ...current, [field.key]: field.type === 'number' ? Number(event.target.value) : event.target.value }))} />}</WarehouseField>)}</div>
    <footer className="flex justify-end gap-3 border-t border-[#E5EDF9] px-6 py-4"><CancelButton onClick={onClose} /><SaveButton onClick={() => { try { onSave(draft as unknown as WarehouseMasterRecord); } catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not save this record.'); } }}>Save</SaveButton></footer>
  </section></div>;
}
