import { useEffect, useRef, useState } from 'react';
import { Check, Pencil, X } from 'lucide-react';

export default function DocumentInlineTextCell({ value, label, disabledReason, onSave }: {
  value: string; label: string; disabledReason: string; onSave: (value: string) => Promise<void>;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const busy = useRef(false);
  const input = useRef<HTMLInputElement>(null);
  useEffect(() => { if (editing) input.current?.focus(); }, [editing]);
  const save = async () => {
    if (busy.current || disabledReason) return;
    if (draft === value) { setEditing(false); return; }
    busy.current = true; setSaving(true); setError('');
    try { await onSave(draft); setEditing(false); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to save.'); }
    finally { busy.current = false; setSaving(false); }
  };
  if (!editing) return <button type="button" disabled={Boolean(disabledReason)} title={disabledReason || `Edit ${label}${value ? `: ${value}` : ''}`} aria-label={`Edit ${label}`} onClick={event => { event.stopPropagation(); setDraft(value); setError(''); setEditing(true); }} className="group/cell flex h-7 w-full min-w-0 items-center gap-1 rounded border border-transparent bg-transparent px-2 text-left font-montserrat text-[12px] text-[#10233A] enabled:hover:border-[#D3E1EC] enabled:hover:text-[#007EA7] disabled:cursor-default"><span className="min-w-0 flex-1 truncate">{value || '—'}</span>{!disabledReason && <Pencil size={12} className="shrink-0 text-[#007EA7]" />}</button>;
  return <div className="relative min-w-0" onClick={event => event.stopPropagation()} onKeyDown={event => { if (event.key === 'Escape' && !saving) { event.stopPropagation(); setEditing(false); } if (event.key === 'Enter') { event.preventDefault(); void save(); } }}>
    <div className="flex h-7 min-w-0 items-center rounded border border-[#007EA7] bg-white">
      <input ref={input} aria-label={label} value={draft} disabled={saving || Boolean(disabledReason)} onChange={event => setDraft(event.target.value)} className="h-full min-w-0 flex-1 bg-transparent px-2 font-montserrat text-[12px] text-[#10233A] outline-none" />
      <button type="button" aria-label={`Save ${label}`} disabled={saving || Boolean(disabledReason)} onClick={() => void save()} className="p-1 text-[#007EA7] disabled:opacity-40"><Check size={13} /></button>
      <button type="button" aria-label={`Cancel ${label}`} disabled={saving} onClick={() => setEditing(false)} className="p-1 text-[#7288A3]"><X size={13} /></button>
    </div>
    {(error || disabledReason) && <span role="alert" className="block text-[10px] text-[#B42318]">{error || disabledReason}</span>}
  </div>;
}
