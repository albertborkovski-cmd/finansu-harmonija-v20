import { useLayoutEffect, useState, type ReactNode, type RefObject } from 'react';
import { createPortal } from 'react-dom';
import { dropdownPosition } from '../lib/dropdownPosition';

/** Keeps existing system menus outside clipped table/toolbar scroll containers. */
export default function DropdownPortal({ anchorRef, menuRef, children, width = 280, height = 360, role, ariaLabel, onKeyDown }: {
  anchorRef: RefObject<HTMLElement | null>;
  menuRef: RefObject<HTMLDivElement>;
  children: ReactNode;
  width?: number;
  height?: number;
  role?: 'listbox' | 'dialog';
  ariaLabel?: string;
  onKeyDown?: React.KeyboardEventHandler<HTMLDivElement>;
}) {
  const [position, setPosition] = useState<ReturnType<typeof dropdownPosition> | null>(null);
  useLayoutEffect(() => {
    const update = () => {
      const rect = anchorRef.current?.getBoundingClientRect();
      if (rect) setPosition(rect.bottom < 0 || rect.top > window.innerHeight ? null : dropdownPosition(rect, { width: window.innerWidth, height: window.innerHeight }, width, height));
    };
    update();
    window.addEventListener('resize', update);
    window.addEventListener('scroll', update, true);
    const observer = new ResizeObserver(update);
    if (anchorRef.current) observer.observe(anchorRef.current);
    return () => { window.removeEventListener('resize', update); window.removeEventListener('scroll', update, true); observer.disconnect(); };
  }, [anchorRef, width, height]);
  return createPortal(<div ref={menuRef} role={role} aria-label={ariaLabel}
    data-system-dropdown-portal="true" onKeyDown={onKeyDown} onClick={event => event.stopPropagation()}
    style={{ ...position, visibility: position ? 'visible' : 'hidden' }}
    className="fixed z-[1100] flex min-h-0 flex-col overflow-hidden rounded-lg border border-[#D3E1EC] bg-white p-1.5 shadow-[0_8px_24px_rgba(16,35,58,0.14)]">
    {children}
  </div>, document.body);
}
