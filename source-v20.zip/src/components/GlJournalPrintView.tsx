import { Printer } from 'lucide-react';
import { journalCurrencyTotals, type GlJournalRow } from '../lib/glJournal';
import GlJournalDialog from './GlJournalDialog';
import { PageActionButton } from './PageHeader';

export default function GlJournalPrintView({ companyName, rows, columns, value, period, account, onClose }: {
  companyName: string; rows: GlJournalRow[]; columns: { key: string; label: string }[]; value: (row: GlJournalRow, key: string) => string;
  period: { from: string; to: string }; account: string; onClose: () => void;
}) {
  const totals = journalCurrencyTotals(rows.filter(row => !row.inactive));
  return <GlJournalDialog printable wide title="GL journal · Print preview" subtitle={`${companyName} · ${period.from || 'All dates'}${period.to ? ` — ${period.to}` : ''}${account ? ` · GL ${account}` : ''}`} onClose={onClose} footer={<><PageActionButton onClick={onClose}>Close</PageActionButton><PageActionButton icon={<Printer size={15} />} onClick={() => window.print()}>Print</PageActionButton></>}>
    <p className="mb-4 text-[12px] text-[#7288A3]">{rows.length} filtered GL lines · {new Set(rows.map(row => row.document.id)).size} documents.</p>
    <table className="gl-journal-print-table w-full border-collapse text-[11px]" aria-label="Printable GL journal"><thead><tr>{columns.map(column => <th key={column.key} className="border border-[#D3E1EC] bg-[#F8FDFF] p-2 text-left font-semibold">{column.label}</th>)}</tr></thead><tbody>{rows.map(row => <tr key={row.id} data-record-inactive={row.inactive || undefined}>{columns.map(column => <td key={column.key} className="border border-[#E5EDF9] p-2 align-top">{value(row, column.key)}</td>)}</tr>)}</tbody></table>
    <div className="mt-4 space-y-1 text-[12px]"><p className="font-semibold">Active totals</p>{totals.map(total => <p key={total.currency}>{total.currency} · Debit {total.debit.toFixed(2)} · Credit {total.credit.toFixed(2)}</p>)}</div>
  </GlJournalDialog>;
}
