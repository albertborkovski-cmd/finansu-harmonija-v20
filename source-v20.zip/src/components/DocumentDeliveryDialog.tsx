import { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { AlertCircle, Download, Loader2, Send, X } from 'lucide-react';
import SearchableSelect from './SearchableSelect';
import { PageActionButton } from './PageHeader';
import { documentDeliveryDestinations, type DocumentExportFormat } from '../lib/documentExport';
import { hasBlockingDocumentIssue } from '../lib/documentIssues';
import type { Document } from './Documents';
import type { Company } from '../lib/supabase';

export default function DocumentDeliveryDialog({ mode, ids, columnsCount, loadRecords, onExport, onClose }: {
  mode: 'transfer' | 'export'; ids: string[]; columnsCount: number;
  loadRecords: () => Promise<{ documents: Document[]; companies: Company[] }>;
  onExport: (format: DocumentExportFormat) => Promise<void>; onClose: () => void;
}) {
  const titleId = useId(), root = useRef<HTMLDivElement>(null);
  const [records, setRecords] = useState<Document[]>([]), [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const [destination, setDestination] = useState(''), [format, setFormat] = useState<DocumentExportFormat>('csv');
  const [complete, setComplete] = useState(false);
  const load = useRef(loadRecords);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    let current = true;
    root.current?.focus();
    load.current().then(result => { if (current) { setRecords(result.documents); setCompanies(result.companies); } }).catch(cause => { if (current) setError(cause instanceof Error ? cause.message : 'Unable to load selected documents.'); }).finally(() => { if (current) setLoading(false); });
    return () => { current = false; previous?.focus(); };
  }, []);
  const companyIds = new Set(records.map(record => record.companyId));
  const company = companies.find(item => companyIds.has(item.id));
  const destinations = companyIds.size === 1 ? documentDeliveryDestinations(company?.counterparties_settings) : [];
  const blocked = records.filter(record => hasBlockingDocumentIssue({ status: record.status, digitization_issues: record.digitizationIssues }));
  const exportFile = async () => {
    if (busy) return;
    setBusy(true); setError(''); setComplete(false);
    try { await onExport(format); setComplete(true); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'The export file could not be created.'); }
    finally { setBusy(false); }
  };
  return createPortal(<div className="fixed inset-0 z-[5000] flex items-center justify-center bg-[#10233A]/35 p-4" onMouseDown={event => { if (event.target === event.currentTarget && !busy) onClose(); }}>
    <div ref={root} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby={titleId} className="flex max-h-[90vh] w-full max-w-[600px] flex-col rounded-xl border border-[#D3E1EC] bg-white font-montserrat text-[12px] text-[#10233A] shadow-xl outline-none"
      onKeyDown={event => {
        if (event.key === 'Escape' && !busy) {
          event.stopPropagation();
          if ((event.target as HTMLElement).closest('[role="combobox"]') || root.current?.querySelector('[role="combobox"][aria-expanded="true"]')) root.current?.focus();
          else onClose();
        }
        if (event.key === 'Tab') {
          const nodes = [...(root.current?.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), [tabindex="0"]') ?? [])].filter(node => node.getClientRects().length);
          const first = nodes[0], last = nodes.at(-1);
          if (event.shiftKey && (document.activeElement === first || document.activeElement === root.current)) { event.preventDefault(); last?.focus(); }
          else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
        }
      }}>
      <header className="flex items-center justify-between gap-4 border-b border-[#D3E1EC] px-6 py-4"><h2 id={titleId} className="text-[18px] font-semibold">{mode === 'transfer' ? 'Send to accounting' : 'Export documents'}</h2><PageActionButton iconOnly className="!px-0" ariaLabel="Close document delivery" disabled={busy} onClick={onClose} icon={<X size={16} className="shrink-0" />}>Close</PageActionButton></header>
      <div className="space-y-5 overflow-y-auto px-6 py-5">
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-[#F2F5F9] px-4 py-3"><span className="font-medium">{ids.length} selected {ids.length === 1 ? 'document' : 'documents'}</span><span className="text-[#7288A3]">{companyIds.size === 1 ? company?.name : `${companyIds.size} companies`}{mode === 'export' ? ` · ${columnsCount} columns` : ''}</span></div>
        {loading && <p role="status" className="flex items-center gap-2 text-[#7288A3]"><Loader2 size={15} className="animate-spin" />Loading selected documents…</p>}
        {error && <p role="alert" className="rounded-lg bg-[#FFF0F0] p-3 text-[#B42318]">{error}</p>}
        {complete && <p role="status" className="rounded-lg bg-[#E5EDF9] p-3 text-[#007EA7]">Export file prepared. Document statuses have not changed.</p>}
        {mode === 'transfer' ? <>
          <label className="block space-y-2"><span className="font-semibold">Destination system <span className="text-red-500">*</span></span><SearchableSelect portalMenu menuClassName="!z-[5100]" ariaLabel="Destination system" value={destination} onChange={setDestination} options={destinations} disabled={loading || !!error} placeholder="Select accounting system" /></label>
          {companyIds.size > 1 && <p role="alert" className="text-[#B42318]">Select documents from one company for each transfer.</p>}
          {!!blocked.length && <p role="alert" className="rounded-lg bg-[#FFF8EB] p-3 text-[#926317]">Resolve the reported issues before transferring: {blocked.map(record => record.number || record.fileCase).join(', ')}.</p>}
          {destination && <div role="status" className="flex items-start gap-2 rounded-lg border border-[#D3E1EC] bg-[#F8FDFF] p-3 text-[#526A83]"><AlertCircle size={16} className="mt-0.5 shrink-0" /><p>Document transfer is not connected for {destinations.find(item => item.value === destination)?.label}. An API connector is required. No documents will be sent or marked as Transferred.</p></div>}
          <div className="max-h-40 overflow-y-auto rounded-lg border border-[#D3E1EC]"><table className="w-full text-left"><thead className="sticky top-0 bg-[#F2F5F9]"><tr><th className="px-3 py-2 font-medium">Document No.</th><th className="px-3 py-2 font-medium">Status</th></tr></thead><tbody>{records.map(record => <tr key={record.id} className="border-t border-[#E5EDF9]"><td className="px-3 py-2">{record.number || record.fileCase}</td><td className="px-3 py-2">{record.status}</td></tr>)}</tbody></table></div>
        </> : <>
          <label className="block space-y-2"><span className="font-semibold">File format <span className="text-red-500">*</span></span><SearchableSelect portalMenu menuClassName="!z-[5100]" ariaLabel="Export file format" value={format} onChange={value => { setFormat(value as DocumentExportFormat); setComplete(false); }} options={[{ value: 'csv', label: 'CSV' }, { value: 'xlsx', label: 'Excel (XLSX)' }, { value: 'json', label: 'JSON' }]} disabled={busy} /></label>
          <p className="text-[#7288A3]">Only selected documents and the current visible columns are included. This downloads a file; it does not send documents to an accounting system.</p>
        </>}
      </div>
      <footer className="flex justify-end gap-2 border-t border-[#D3E1EC] px-6 py-4"><PageActionButton disabled={busy} onClick={onClose}>Close</PageActionButton>{mode === 'export' ? <PageActionButton disabled={loading || busy || !records.length || !columnsCount} onClick={() => void exportFile()} icon={busy ? <Loader2 size={15} className="animate-spin" /> : <Download size={15} />}>Download file</PageActionButton> : <PageActionButton disabled icon={<Send size={15} />}>Send documents</PageActionButton>}</footer>
    </div>
  </div>, document.body);
}
