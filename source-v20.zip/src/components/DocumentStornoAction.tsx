import { useCallback, useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { ArrowLeftRight, X } from 'lucide-react';
import { applyDocumentStorno, supabase, type Company } from '../lib/supabase';
import { accountingToday, documentStornoBlocker, postedOperationError, reversePostedLines, savedDocumentStornoError, stornoPeriodError, type StornoDocument, type StornoPeriodPolicy } from '../lib/documentStorno';
import { canStornoDocument, canViewStornoDocument, loadStornoPeriodPolicy } from '../lib/documentStornoAccess';
import ScheduleDatePicker from './ScheduleDatePicker';
import { SaveButton } from './ScopedActionButtons';

const buttonClass = 'inline-flex h-8 shrink-0 items-center justify-center gap-2 rounded-md border-2 border-[#D3E1EC] bg-white px-3 font-montserrat text-[12px] font-semibold text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40';
const money = (minor: number) => (minor / 100).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export default function DocumentStornoAction({ documentId, companyId, unsavedChanges = false }: { documentId: string; companyId: string; unsavedChanges?: boolean }) {
  const [open, setOpen] = useState(false);
  return <>
    <span title={unsavedChanges ? 'Save or discard document changes before opening Storno.' : 'Reverse a confirmed GL operation'}>
      <button type="button" disabled={unsavedChanges} className={buttonClass} onClick={() => setOpen(true)}><ArrowLeftRight size={14} />Storno</button>
    </span>
    {open && <DocumentStornoDialog documentId={documentId} companyId={companyId} onClose={() => setOpen(false)} />}
  </>;
}

export function DocumentStornoDialog({ documentId, companyId, onClose }: { documentId: string; companyId: string; onClose: () => void }) {
  const titleId = useId();
  const root = useRef<HTMLDivElement>(null);
  const saving = useRef(false);
  const [document, setDocument] = useState<StornoDocument | null>(null);
  const [company, setCompany] = useState<Company | null>(null);
  const [allowed, setAllowed] = useState(false);
  const [policy, setPolicy] = useState<StornoPeriodPolicy | null>(null);
  const [date, setDate] = useState(accountingToday);
  const [reason, setReason] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);
  const load = useCallback(async () => {
    const [documents, companies] = await Promise.all([
      supabase.from('documents').select('*').eq('id', documentId).eq('company_id', companyId),
      supabase.from('companies').select('*').eq('id', companyId),
    ]);
    if (documents.error || companies.error || !documents.data?.[0] || !companies.data?.[0]) throw new Error('The document or its company is unavailable. Refresh before continuing.');
    const currentCompany = companies.data[0] as unknown as Company;
    if (!canViewStornoDocument(currentCompany)) throw new Error('You no longer have access to this company’s documents.');
    return { company: currentCompany, document: documents.data[0] as StornoDocument, allowed: canStornoDocument(currentCompany), policy: loadStornoPeriodPolicy(companyId) };
  }, [documentId, companyId]);
  useEffect(() => {
    let current = true;
    void load().then(value => {
      if (!current) return;
      setCompany(value.company); setDocument(value.document); setAllowed(value.allowed); setPolicy(value.policy);
    }).catch(value => { if (current) setError(value instanceof Error ? value.message : 'The operation could not be loaded.'); });
    return () => { current = false; };
  }, [load]);
  useEffect(() => {
    const previous = window.document.activeElement as HTMLElement | null;
    root.current?.focus();
    return () => { if (previous?.isConnected) previous.focus({ preventScroll: true }); };
  }, []);
  const posting = document?.accounting_posting;
  const integrityError = document ? savedDocumentStornoError(document) : '';
  const reversal = integrityError ? undefined : document?.accounting_storno;
  const originalValid = posting && document && !postedOperationError(posting, document);
  const blocker = integrityError || (document ? documentStornoBlocker(document, allowed) : '');
  const periodError = posting && policy ? stornoPeriodError(date, posting.date, accountingToday(), policy) : '';
  const lines = reversal?.lines ?? (originalValid ? reversePostedLines(posting, 'preview') : []);
  const perform = async () => {
    if (!document || !posting || saving.current) return;
    saving.current = true; setBusy(true); setError('');
    try {
      const next = await applyDocumentStorno(documentId, companyId, { expectedPosting: JSON.stringify(posting), date, reason });
      setDocument(next as unknown as StornoDocument); setSaved(true);
    } catch (value) { setError(value instanceof Error ? value.message : 'Storno could not be saved.'); }
    finally { saving.current = false; setBusy(false); }
  };
  return createPortal(<div className="fixed inset-0 z-[5100] flex items-center justify-center bg-[#10233A]/35 p-4" onMouseDown={event => { if (event.target === event.currentTarget && !busy) onClose(); }}>
    <div ref={root} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby={titleId} className="flex max-h-[92vh] w-full max-w-[1040px] flex-col rounded-xl border border-[#D3E1EC] bg-white font-montserrat text-[12px] text-[#10233A] shadow-xl outline-none" onKeyDown={event => {
      if (event.key === 'Escape') {
        event.stopPropagation();
        const calendar = root.current?.querySelector<HTMLButtonElement>('button[aria-haspopup="dialog"][aria-expanded="true"]');
        const combobox = root.current?.querySelector('[role="combobox"][aria-expanded="true"]');
        if (combobox) return;
        if (calendar) { calendar.click(); calendar.focus(); return; }
        if (!busy) onClose();
      }
      if (event.key === 'Tab') {
        const nodes = [...root.current!.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), textarea:not(:disabled), [tabindex="0"]')].filter(node => node.getClientRects().length);
        if (event.shiftKey && (window.document.activeElement === nodes[0] || window.document.activeElement === root.current)) { event.preventDefault(); nodes.at(-1)?.focus(); }
        else if (!event.shiftKey && (window.document.activeElement === nodes.at(-1) || window.document.activeElement === root.current)) { event.preventDefault(); nodes[0]?.focus(); }
      }
    }}>
      <header className="flex items-start justify-between gap-3 border-b border-[#D3E1EC] px-6 py-4"><div><h2 id={titleId} className="text-[18px] font-semibold">{reversal ? 'Storno · Posted reversal' : 'Storno · Reverse GL operation'}</h2><p className="mt-1 text-[#7288A3]">{company?.name} · {String(document?.number || documentId)}</p></div><button className={`${buttonClass} !w-8 !px-0`} aria-label="Close Storno" disabled={busy} onClick={onClose}><X size={16} /></button></header>
      <div className="space-y-4 overflow-y-auto p-6">
        {error && <p role="alert" className="rounded-lg border border-[#F4C7C7] bg-[#FFF0F0] p-3 text-[#B42318]">{error}</p>}
        {!document && !error && <p role="status">Loading confirmed GL operation…</p>}
        {document && <>
          {saved && <p role="status" className="rounded-lg bg-[#E6F2F6] p-3 text-[#007EA7]">Storno posted. The original operation is unchanged; the opposite entries are now in the GL journal.</p>}
          {!reversal && blocker && <p role="status" className="rounded-lg border border-[#EEB648] bg-[#FFF4DC] p-3 text-[#926317]">{blocker}</p>}
          {posting && <dl className="grid grid-cols-2 gap-4 rounded-lg border border-[#D3E1EC] p-4 sm:grid-cols-4"><div><dt className="text-[#7288A3]">Original operation</dt><dd className="mt-1 font-semibold">{posting.number}</dd></div><div><dt className="text-[#7288A3]">Posting date</dt><dd className="mt-1">{posting.date}</dd></div><div><dt className="text-[#7288A3]">Posted by</dt><dd className="mt-1">{posting.postedBy}</dd></div><div><dt className="text-[#7288A3]">Integration</dt><dd className="mt-1">{posting.integration?.destination || 'Unknown'} · {posting.integration?.status || 'Unknown'}</dd></div></dl>}
          {!reversal && originalValid && <fieldset disabled={busy || Boolean(blocker)} className="grid gap-4 sm:grid-cols-[220px_minmax(0,1fr)]"><div><label className="mb-2 block font-medium">Reversal date *</label><ScheduleDatePicker value={date} onChange={setDate} ariaLabel="Reversal date" placeholder="YYYY-MM-DD" />{periodError && <p className="mt-2 text-[#B42318]">{periodError}</p>}</div><div><label htmlFor={`${titleId}-reason`} className="mb-2 block font-medium">Reason *</label><textarea id={`${titleId}-reason`} value={reason} onChange={event => setReason(event.target.value)} maxLength={2000} rows={3} className="w-full rounded-lg border border-[#D3E1EC] p-3 outline-none focus:border-[#007EA7]" /></div></fieldset>}
          {!!lines.length && <section><h3 className="mb-2 font-semibold">{reversal ? 'Posted opposite entries' : 'Opposite entries · Preview'}</h3><div className="max-h-[300px] overflow-auto rounded-lg border border-[#D3E1EC]"><table className="w-full min-w-[760px] border-collapse text-left"><thead className="sticky top-0 z-10 bg-[#F0F5FA] text-[#7288A3]"><tr>{['GL account', 'Counterparty', 'Currency', 'Original D', 'Original C', 'Storno D', 'Storno C'].map(label => <th key={label} className="px-3 py-2 font-medium">{label}</th>)}</tr></thead><tbody>{lines.map((line, index) => <tr key={line.id} className="border-t border-[#E5EDF9]"><td className="px-3 py-2"><span className="font-medium">{line.account}</span><span className="ml-2 text-[#7288A3]">{line.accountName}</span></td><td className="px-3 py-2">{line.counterparty || '—'}</td><td className="px-3 py-2">{line.currency}</td><td className="px-3 py-2 tabular-nums">{money(posting!.lines[index].debitMinor)}</td><td className="px-3 py-2 tabular-nums">{money(posting!.lines[index].creditMinor)}</td><td className="px-3 py-2 tabular-nums">{money(line.debitMinor)}</td><td className="px-3 py-2 tabular-nums">{money(line.creditMinor)}</td></tr>)}</tbody></table></div><p className="mt-2 text-[11px] text-[#7288A3]">Exact D ↔ C reversal, including the original booked {posting?.baseCurrency} amounts and dimensions. No new exchange rate is applied.</p></section>}
          {reversal && <section className="space-y-3 rounded-lg border border-[#D3E1EC] p-4"><div className="flex flex-wrap gap-x-6 gap-y-1"><strong>{reversal.number}</strong><span>{reversal.date}</span><span className="rounded bg-[#E6F2F6] px-2 text-[#007EA7]">Posted</span></div><p className="whitespace-pre-wrap break-words">{reversal.reason}</p><h3 className="font-semibold">Action history</h3>{reversal.history.map(event => <div key={event.id} className="border-t border-[#E5EDF9] pt-2"><p>{event.action} · {event.actor} · {new Date(event.at).toLocaleString()}</p><p className="mt-1 break-words text-[#7288A3]">{event.details}</p></div>)}</section>}
        </>}
      </div>
      <footer className="flex justify-end gap-3 border-t border-[#D3E1EC] px-6 py-3"><button className={buttonClass} disabled={busy} onClick={onClose}>Close</button>{!reversal && <SaveButton className="!h-8 !text-[12px]" disabled={!document || !policy || busy || Boolean(blocker) || Boolean(periodError) || !reason.trim()} onClick={() => void perform()}>{busy ? 'Posting…' : 'Confirm Storno'}</SaveButton>}</footer>
    </div>
  </div>, window.document.body);
}
