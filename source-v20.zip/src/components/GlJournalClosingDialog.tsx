import { useEffect, useId, useMemo, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { Mail, Save, X } from 'lucide-react';
import { closingPeriodError, JOURNAL_CLOSING_TITLES, loadClosingPeriod, saveClosingPeriod, type JournalClosingKind, type JournalClosingPeriod } from '../lib/glJournalClosing';
import ScheduleDatePicker from './ScheduleDatePicker';
import { PageActionButton } from './PageHeader';
import SearchableSelect from './SearchableSelect';
import { journalMailto, journalVatCalculation } from '../lib/glJournalVatEmail';
import { loadOrganizationEmailTemplates, saveOrganizationEmailTemplates, type OrganizationEmailTemplate } from '../lib/organizationEmail';
import { VAT_EMAIL_TEMPLATES, renderVatTemplate, validateVatTemplate, VAT_TEMPLATE_TOKENS } from '../lib/vatEmailTemplates';
import type { GlJournalRow } from '../lib/glJournal';
import type { JournalAccountOption } from '../lib/glJournalDrafts';

export default function GlJournalClosingDialog({ companyId, companyName, kind, initialPeriod, rows, accounts, initialRecipient = '', emailOnly = false, companySelection, testData = false, onPeriodChange, onSaved, onClose }: {
  companyId: string;
  companyName: string;
  kind: JournalClosingKind;
  initialPeriod: JournalClosingPeriod;
  rows: GlJournalRow[];
  accounts: JournalAccountOption[];
  initialRecipient?: string;
  emailOnly?: boolean;
  companySelection?: ReactNode;
  testData?: boolean;
  onPeriodChange?: (period: JournalClosingPeriod) => void;
  onSaved?: (period: JournalClosingPeriod) => void;
  onClose: () => void;
}) {
  const titleId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  const [period, setPeriod] = useState<JournalClosingPeriod>(() => {
    if (!closingPeriodError(initialPeriod)) return initialPeriod;
    try {
      const saved = loadClosingPeriod(window.localStorage, companyId, kind);
      if (saved) return saved;
      if (emailOnly) {
        const today = new Date();
        const month = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
        return { from: `${month}-01`, to: `${month}-${new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate()}` };
      }
      return initialPeriod;
    }
    catch { return initialPeriod; }
  });
  const [saveError, setSaveError] = useState('');
  const [recipient, setRecipient] = useState(initialRecipient);
  const [contactName, setContactName] = useState('');
  const message = '';
  const [templates, setTemplates] = useState<OrganizationEmailTemplate[]>(() => [...VAT_EMAIL_TEMPLATES, ...loadOrganizationEmailTemplates(companyId).filter(template => template.active && template.id.startsWith('vat-custom-'))]);
  const [templateId, setTemplateId] = useState('vat-confirmation-en');
  const [templateDraft, setTemplateDraft] = useState<Pick<OrganizationEmailTemplate, 'name' | 'subject' | 'body'> | null>(null);
  const [emailNotice, setEmailNotice] = useState('');
  const [vatAccounts] = useState(() => ['2441', '4484'].map(code => accounts.some(account => account.code === code) ? code : ''));
  const error = closingPeriodError(period);
  const title = emailOnly ? 'VAT reconciliation' : JOURNAL_CLOSING_TITLES[kind];
  const calculation = useMemo(() => journalVatCalculation(rows, period, vatAccounts), [rows, period, vatAccounts]);
  const summary = calculation.amounts.map(total => `${total.recoverableMinor > 0 ? 'VAT surplus' : 'VAT payable'}: ${((total.recoverableMinor || total.payableMinor) / 100).toFixed(2)} ${total.currency}`).join('\n');
  const template = templates.find(item => item.id === templateId) || VAT_EMAIL_TEMPLATES[0];
  const templateData = { company: companyName, recipient: contactName.trim() || companyName, periodFrom: period.from || '{{periodFrom}}', periodTo: period.to || '{{periodTo}}', vatSummary: summary, message };
  const subject = `${testData ? '[TEST DATA] ' : ''}${renderVatTemplate(template.subject, templateData)}`.replace(/[\r\n]/g, ' ');
  const body = `${testData ? 'TEST DATA — not actual company tax figures.\n\n' : ''}${renderVatTemplate(template.body, templateData)}\n\nCalculated from posted, active GL period movements; currencies are separate. This is not a VAT declaration or a remaining tax-debt balance.`;
  const clearEmailFeedback = () => { setSaveError(''); setEmailNotice(''); };
  const saveTemplate = () => {
    if (!templateDraft) return;
    const validation = validateVatTemplate(templateDraft);
    if (validation) { setSaveError(validation); return; }
    try {
      const saved = { ...templateDraft, id: `vat-custom-${crypto.randomUUID()}`, language: 'EN', active: true };
      saveOrganizationEmailTemplates([...loadOrganizationEmailTemplates(companyId), saved], companyId);
      setTemplates(current => [...current, saved]); setTemplateId(saved.id); setTemplateDraft(null); clearEmailFeedback();
    } catch { setSaveError('The template could not be saved. Please try again.'); }
  };

  useEffect(() => {
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    dialogRef.current?.focus();
    const onKey = (event: KeyboardEvent) => {
      const dialog = dialogRef.current;
      if (!dialog) return;
      if (event.key === 'Escape') {
        if (dialog.querySelector('[role="combobox"][aria-expanded="true"]')) return;
        const calendar = dialog.querySelector<HTMLButtonElement>('button[aria-haspopup="dialog"][aria-expanded="true"]');
        event.preventDefault();
        if (calendar) { calendar.click(); calendar.focus(); return; }
        closeRef.current();
      }
      if (event.key !== 'Tab') return;
      const controls = Array.from(dialog.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), textarea:not(:disabled), [tabindex="0"]')).filter(element => element.getClientRects().length > 0);
      const first = controls[0];
      const last = controls[controls.length - 1];
      if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog)) {
        event.preventDefault(); last?.focus();
      } else if (!event.shiftKey && (document.activeElement === last || document.activeElement === dialog)) {
        event.preventDefault(); first?.focus();
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => {
      window.removeEventListener('keydown', onKey, true);
      document.body.style.overflow = previousOverflow;
      if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true });
    };
  }, []);

  const save = () => {
    if (error) return;
    try {
      saveClosingPeriod(window.localStorage, companyId, kind, period);
      onSaved?.(period);
    } catch {
      setSaveError('The period could not be saved. Please try again.');
    }
  };
  const prepareEmail = () => {
    try {
      if (error) throw new Error(error);
      if (calculation.error) throw new Error(calculation.error);
      if (!calculation.amounts.length) throw new Error('No posted VAT entries in this period.');
      const href = journalMailto(recipient, subject, body);
      window.location.href = href;
      setSaveError(''); setEmailNotice('Email draft requested in your mail application. Review and send it there; no email has been sent by this system.');
    } catch (error) { setSaveError(error instanceof Error ? error.message : 'The email draft could not be prepared.'); }
  };

  return createPortal(<div className="fixed inset-0 z-[240] flex items-center justify-center bg-[#10233A]/30 p-4" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
    <div ref={dialogRef} role="dialog" aria-modal="true" aria-labelledby={titleId} tabIndex={-1} className={`flex max-h-[calc(100dvh-32px)] w-full ${emailOnly ? 'max-w-[680px]' : 'max-w-[480px]'} flex-col rounded-xl bg-white font-montserrat text-[#10233A] shadow-xl outline-none`}>
      <header className="flex shrink-0 items-start justify-between gap-4 border-b border-[#E5EDF9] px-6 py-4">
        <div><h2 id={titleId} className="text-[22px] font-semibold leading-8">{title}</h2><p className="mt-1 text-[12px] text-[#7288A3]">{companyName}</p></div>
        <button type="button" aria-label={`Close ${title}`} onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded text-[#7288A3] hover:text-[#007EA7]"><X size={20} /></button>
      </header>
      <div className="min-h-0 overflow-auto px-6 py-5">
        {emailOnly && companySelection}
        {emailOnly && testData && <p className="mb-4 text-[12px] text-[#C45100]">Test GL entries · amounts are not actual company tax figures.</p>}
        <p className="mb-4 text-[13px] font-medium">{emailOnly ? 'Reconciliation period' : 'Select the closing period'}</p>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {(['from', 'to'] as const).map(key => <div key={key} className="min-w-0">
            <div className="mb-2 text-[12px] font-medium text-[#7288A3]">{key === 'from' ? 'From' : 'To'} <span className="text-[#E5484D]">*</span></div>
            <ScheduleDatePicker value={period[key]} onChange={value => { const next = { ...period, [key]: value }; setPeriod(next); onPeriodChange?.(next); clearEmailFeedback(); }} placeholder="YYYY-MM-DD" ariaLabel={`${emailOnly ? 'Reconciliation' : 'Closing'} period ${key}`} align={key === 'to' ? 'right' : 'left'} />
          </div>)}
        </div>
        {period.from && period.to && error && <p role="alert" className="mt-3 text-[12px] text-[#C45100]">{error}</p>}
        {saveError && <p role="alert" className="mt-3 text-[12px] text-[#C45100]">{saveError}</p>}
        {emailOnly && kind === 'vat' && <section className="mt-5 space-y-4 border-t border-[#E5EDF9] pt-4" aria-label="VAT reconciliation email">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <label className="block text-[12px] text-[#7288A3]">Recipient email <span className="text-[#E5484D]">*</span><input type="email" aria-label="VAT email recipient" value={recipient} onChange={event => { setRecipient(event.target.value); clearEmailFeedback(); }} placeholder="name@company.lt" className="mt-2 h-[42px] w-full rounded-lg border border-[#D3E1EC] px-3 text-[#10233A] outline-none focus:border-[#007EA7]" /></label>
            <label className="block text-[12px] text-[#7288A3]">Contact name (optional)<input type="text" aria-label="VAT contact name" value={contactName} onChange={event => { setContactName(event.target.value); clearEmailFeedback(); }} placeholder="Client contact" className="mt-2 h-[42px] w-full rounded-lg border border-[#D3E1EC] px-3 text-[#10233A] outline-none focus:border-[#007EA7]" /></label>
          </div>
          {!initialRecipient?.trim() && <p className="text-[11px] text-[#7288A3]">No email is saved for this company. Add it in Companies → Manage company, or enter the recipient above for this draft.</p>}
          {calculation.error ? <p role="alert" className="text-[12px] text-[#C45100]">{calculation.error}</p> : calculation.amounts.map(total => <div key={total.currency} className="flex items-center justify-between rounded-lg border border-[#D3E1EC] px-3 py-3 text-[13px]"><span className="text-[#7288A3]">{total.recoverableMinor > 0 ? 'VAT surplus' : 'VAT payable'}</span><strong>{((total.recoverableMinor || total.payableMinor) / 100).toFixed(2)} {total.currency}</strong></div>)}
          <div className="rounded-lg border border-[#D3E1EC] bg-[#F8FDFF] p-3">
            <div className="mb-2 text-[12px] text-[#7288A3]">Email template</div><div className="flex items-center gap-2"><div className="min-w-0 flex-1"><SearchableSelect portalMenu ariaLabel="VAT email template" value={templateId} options={templates.map(item => ({ value: item.id, label: item.name }))} onChange={value => { setTemplateId(value); clearEmailFeedback(); }} /></div><PageActionButton onClick={() => { setTemplateDraft({ name: '', subject: template.subject, body: template.body }); clearEmailFeedback(); }}>New template</PageActionButton></div>
            {templateDraft && <div className="my-3 space-y-3 rounded-lg border border-[#D3E1EC] bg-white p-3">{(['name', 'subject', 'body'] as const).map(key => <label key={key} className="block text-[12px] text-[#7288A3]">{key === 'name' ? 'Template name *' : key === 'subject' ? 'Subject *' : 'Message *'}<textarea aria-label={`VAT template ${key}`} rows={key === 'body' ? 5 : 1} value={templateDraft[key]} onChange={event => setTemplateDraft(current => current ? { ...current, [key]: event.target.value } : null)} className="mt-1 w-full rounded border border-[#D3E1EC] p-2 text-[#10233A]" /></label>)}<p className="text-[11px] leading-5 text-[#7288A3]">Placeholders: {VAT_TEMPLATE_TOKENS.map(token => `{{${token}}}`).join(', ')}</p><div className="flex justify-end gap-2"><PageActionButton onClick={() => setTemplateDraft(null)}>Cancel</PageActionButton><PageActionButton onClick={saveTemplate}>Save template</PageActionButton></div></div>}
            <p className="mt-3 text-[11px] text-[#7288A3]">Subject</p><p className="mt-1 text-[12px] font-medium">{subject}</p>
            <label className="mt-3 block text-[11px] text-[#7288A3]">Message preview<textarea aria-label="VAT email preview" readOnly rows={7} value={body} className="mt-1 w-full resize-y rounded border border-[#E5EDF9] bg-white p-3 text-[12px] leading-5 text-[#10233A] outline-none focus:border-[#007EA7]" /></label>
          </div>
          {!error && !calculation.amounts.length && <p className="text-[11px] text-[#7288A3]">No posted VAT movements for the selected accounts and period.</p>}
          {emailNotice && <p role="status" className="text-[11px] leading-5 text-[#087A5B]">{emailNotice}</p>}
        </section>}
        {emailOnly && <p className="mt-4 text-[11px] leading-5 text-[#7288A3]">Opens your email application with a prepared draft. Review and send it there; the client can reply with confirmation or corrections. This does not post closing entries or mark VAT as reconciled.</p>}
        {!emailOnly && kind === 'classes56' && <p className="mt-4 text-[11px] leading-5 text-[#7288A3]">Saves the selected period only. No closing entries are posted.</p>}
      </div>
      <footer className="flex shrink-0 flex-wrap justify-end gap-2 border-t border-[#E5EDF9] px-6 py-4">
        <PageActionButton onClick={onClose}>Close</PageActionButton>
        {emailOnly && kind === 'vat' && <PageActionButton icon={<Mail size={15} />} disabled={Boolean(error || calculation.error) || !recipient.trim() || !calculation.amounts.length || Boolean(templateDraft)} onClick={prepareEmail}>Open email draft</PageActionButton>}
        {!emailOnly && <PageActionButton icon={<Save size={15} />} disabled={Boolean(error)} onClick={save}>Save period</PageActionButton>}
      </footer>
    </div>
  </div>, document.body);
}
