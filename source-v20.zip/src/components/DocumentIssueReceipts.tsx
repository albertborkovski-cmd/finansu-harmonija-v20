import { useEffect, useState } from 'react';
import { supabase, type Company, type DbDocument } from '../lib/supabase';
import type { DocumentIssue } from '../lib/documentIssues';
import { canAccessIssueOrganization } from '../lib/documentIssueAccess';
import { DocumentIssueBadge } from './DocumentIssueDialog';

/** Keep the reporting company's receipt visible even after a document is reassigned.
 * Do not expose the receiving company's document or its subsequent accounting data. */
export default function DocumentIssueReceipts({ companyId }: { companyId: string }) {
  const [receipts, setReceipts] = useState<DocumentIssue[]>([]);
  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      const company = await supabase.from('companies').select('*').eq('id', companyId);
      if (company.error || !company.data?.[0] || !canAccessIssueOrganization(company.data[0] as unknown as Company)) return;
      const result = await supabase.from('documents').select('id,company_id,digitization_issues');
      if (cancelled || result.error) return;
      setReceipts((result.data as unknown as DbDocument[] ?? []).filter(document => document.company_id !== companyId)
        .flatMap(document => (document.digitization_issues ?? []).filter(issue => issue.organizationId === companyId)));
    };
    const refresh = (event: Event) => { if (event.type === 'storage' || (event as CustomEvent).detail?.table === 'documents') void load(); };
    void load(); window.addEventListener('finansu-harmonija:data-changed', refresh); window.addEventListener('storage', refresh);
    return () => { cancelled = true; window.removeEventListener('finansu-harmonija:data-changed', refresh); window.removeEventListener('storage', refresh); };
  }, [companyId]);
  if (!receipts.length) return null;
  return <details className="rounded-lg border border-[#D3E1EC] bg-[#F8FDFF] p-3 font-montserrat text-[12px] text-[#10233A]"><summary className="cursor-pointer font-medium">Reported issues · Reassigned documents ({receipts.length})</summary><div className="mt-3 divide-y divide-[#D3E1EC]">{receipts.map(issue => <div key={issue.id} className="space-y-2 py-3"><div className="flex flex-wrap items-center justify-between gap-2"><strong>{issue.documentLabel || 'Reassigned document'}</strong><DocumentIssueBadge status={issue.status} /></div><p className="whitespace-pre-wrap">{issue.message}</p>{issue.resolution && <p className="text-[#237A50]">Resolution: {issue.resolution}</p>}<p className="text-[#7288A3]">Reported by {issue.createdBy} · {new Date(issue.createdAt).toLocaleString()}</p></div>)}</div></details>;
}
