import { useCallback, useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { AlertCircle, X } from 'lucide-react';
import { applyDocumentIssueAction, supabase, type Company, type DbDocument } from '../lib/supabase';
import { documentIssueStatus, hasBlockingDocumentIssue, type DocumentIssueCommand, type DocumentIssueStatus } from '../lib/documentIssues';
import { canAccessIssueOrganization, canReviewDocumentIssues } from '../lib/documentIssueAccess';
import SearchableSelect from './SearchableSelect';

export const issueButtonClass = 'inline-flex h-8 shrink-0 items-center justify-center gap-2 rounded-md border-2 border-[#D3E1EC] bg-white px-3 text-[12px] font-semibold text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40';
export function DocumentIssueBadge({ status }: { status: DocumentIssueStatus | '' }) {
  return status ? <span className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded px-2 py-1 text-[11px] font-medium ${status === 'Resolved' ? 'bg-[#E7F7EF] text-[#237A50]' : status === 'In progress' ? 'bg-[#E5EDF9] text-[#007EA7]' : 'bg-[#FFF4DC] text-[#926317]'}`}><span className="h-1.5 w-1.5 rounded-full bg-current" />{status}</span> : <span>—</span>;
}

export default function DocumentIssueDialog({ documentId, companyId, worker = false, initialIssueId = '', onClose, onEditDocument }: {
  documentId: string; companyId: string; worker?: boolean; initialIssueId?: string; onClose: () => void; onEditDocument?: (document: DbDocument) => void;
}) {
  const [document, setDocument] = useState<DbDocument | null>(null);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [message, setMessage] = useState('');
  const [note, setNote] = useState('');
  const [organization, setOrganization] = useState(companyId);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [selectedIssueId, setSelectedIssueId] = useState(initialIssueId);
  const root = useRef<HTMLDivElement>(null);
  const titleId = useId();
  const isWorker = worker && canReviewDocumentIssues();
  const currentIssue = document?.digitization_issues?.find(issue => issue.id === selectedIssueId)
    ?? document?.digitization_issues?.find(issue => issue.status !== 'Resolved') ?? document?.digitization_issues?.at(-1);
  const load = useCallback(async () => {
    const [docs, organizations] = await Promise.all([supabase.from('documents').select('*').eq('id', documentId), supabase.from('companies').select('*')]);
    if (docs.error || organizations.error) throw new Error(docs.error?.message || organizations.error?.message);
    const next = docs.data?.[0] as unknown as DbDocument | undefined;
    const allowed = (organizations.data as unknown as Company[] ?? []).filter(company => canAccessIssueOrganization(company));
    if (!next || !allowed.some(company => company.id === next.company_id) || (!isWorker && next.company_id !== companyId)) throw new Error('This document has moved or is no longer accessible. Refresh the document list.');
    setDocument(next); setCompanies(allowed); setOrganization(next.company_id ?? '');
  }, [documentId, companyId, isWorker]);
  useEffect(() => { void load().catch(reason => setError(reason.message)); }, [load]);
  useEffect(() => {
    const previous = window.document.activeElement as HTMLElement | null;
    root.current?.focus();
    return () => { if (previous?.isConnected) previous.focus(); };
  }, []);
  const perform = async (command: DocumentIssueCommand) => {
    if (!document || busy) return;
    setBusy(true); setError(''); setNotice('');
    try {
      const next = await applyDocumentIssueAction(document.id, document.company_id ?? '', command);
      setDocument(next); setOrganization(next.company_id ?? ''); setNote('');
      if (command.type === 'report') { setMessage(''); setSelectedIssueId(next.digitization_issues?.at(-1)?.id ?? ''); setNotice('Reported to the MESO Worker review queue.'); }
      if (command.type === 'resolve') setNotice('Issue resolved. The document still requires the usual validation and approval.');
      if (command.type === 'request-ocr') setNotice('OCR rerun requested. Automatic OCR processing is not connected in this prototype; no rescan or approval has been performed.');
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Unable to save the issue.'); }
    finally { setBusy(false); }
  };
  return createPortal(<div className="fixed inset-0 z-[5000] flex items-center justify-center bg-[#10233A]/35 p-4" onMouseDown={event => { if (event.target === event.currentTarget && !busy) onClose(); }}>
    <div ref={root} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby={titleId} className="flex max-h-[90vh] w-full max-w-[820px] flex-col rounded-xl border border-[#D3E1EC] bg-white font-montserrat text-[12px] text-[#10233A] shadow-xl outline-none"
      onKeyDown={event => {
        if (event.key === 'Escape' && !event.defaultPrevented && !busy) { event.stopPropagation(); onClose(); }
        if (event.key === 'Tab') {
          const nodes = [...(root.current?.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), textarea:not(:disabled), [tabindex="0"]') ?? [])].filter(node => node.getClientRects().length);
          const first = nodes[0], last = nodes.at(-1);
          if (event.shiftKey && (window.document.activeElement === first || window.document.activeElement === root.current)) { event.preventDefault(); last?.focus(); }
          else if (!event.shiftKey && window.document.activeElement === last) { event.preventDefault(); first?.focus(); }
        }
      }}>
      <header className="flex items-start justify-between gap-4 border-b border-[#D3E1EC] px-6 py-4"><div><h2 id={titleId} className="text-[18px] font-semibold">{isWorker ? 'MESO Worker · Issue review' : 'Report issue'}</h2><p className="mt-1 text-[#7288A3]">{document?.number || document?.file_case || 'Document'} · {companies.find(company => company.id === document?.company_id)?.name}</p></div><button type="button" aria-label="Close issue review" disabled={busy} onClick={onClose} className={issueButtonClass + ' !w-8 !px-0'}><X size={16} /></button></header>
      <div className="space-y-5 overflow-y-auto p-6">
        {error && <p role="alert" className="rounded-lg bg-[#FFF0F0] p-3 text-[#B42318]">{error}</p>}
        {notice && <p role="status" className="rounded-lg bg-[#E5EDF9] p-3 text-[#007EA7]">{notice}</p>}
        {!document && !error && <p>Loading document…</p>}
        {document && <>
          <div className="flex flex-wrap items-center gap-3"><DocumentIssueBadge status={documentIssueStatus(document)} />{hasBlockingDocumentIssue(document) && <p className="flex items-center gap-2 text-[#926317]"><AlertCircle size={15} />Approval and transfer to accounting are blocked.</p>}</div>
          {!isWorker && <form onSubmit={event => { event.preventDefault(); void perform({ type: 'report', message }); }} className="space-y-3"><label className="block font-medium" htmlFor={`${titleId}-message`}>Describe the digitization issue *</label><textarea id={`${titleId}-message`} required maxLength={5000} value={message} onChange={event => setMessage(event.target.value)} rows={4} placeholder="For example: this document belongs to another organization. Please check the buyer details." className="w-full resize-y rounded-lg border border-[#D3E1EC] p-3 outline-none focus:border-[#007EA7]" /><p className="text-[#7288A3]">MESO Worker reviews and corrects the document. OCR is rerun only if needed.</p><button type="submit" disabled={busy || !message.trim()} className={issueButtonClass}>Send to MESO Worker</button></form>}
          {!!document.digitization_issues?.length && <section className="space-y-3"><h3 className="font-semibold">Reported issues</h3><div className="flex flex-wrap gap-2">{document.digitization_issues.map((issue, index) => <button type="button" key={issue.id} onClick={() => { setSelectedIssueId(issue.id); setNote(''); }} className={`${issueButtonClass} ${currentIssue?.id === issue.id ? '!border-[#007EA7] !text-[#007EA7]' : ''}`}>#{index + 1} · {issue.status}</button>)}</div>
            {currentIssue && <><div className="rounded-lg border border-[#D3E1EC] p-4"><p className="whitespace-pre-wrap break-words">{currentIssue.message}</p><p className="mt-2 text-[11px] text-[#7288A3]">{currentIssue.createdBy} · {new Date(currentIssue.createdAt).toLocaleString()}</p></div>
              {isWorker && currentIssue.status !== 'Resolved' && <div className="space-y-3 rounded-lg border border-[#D3E1EC] bg-[#F8FDFF] p-4"><div className="flex flex-wrap gap-2"><button disabled={busy || currentIssue.status === 'In progress'} onClick={() => void perform({ type: 'start', issueId: currentIssue.id })} className={issueButtonClass}>Start review</button>{onEditDocument && <button disabled={busy} onClick={() => onEditDocument(document)} className={issueButtonClass}>Edit document</button>}</div>
                <label className="block font-medium">Organization<SearchableSelect value={organization} options={companies.map(company => ({ value: company.id, label: company.name }))} onChange={setOrganization} ariaLabel="Correct organization" disabled={busy} /></label>
                <label className="block font-medium" htmlFor={`${titleId}-note`}>Correction / resolution note *</label><textarea id={`${titleId}-note`} value={note} onChange={event => setNote(event.target.value)} maxLength={5000} rows={3} className="w-full rounded-lg border border-[#D3E1EC] bg-white p-3 font-normal outline-none focus:border-[#007EA7]" />
                <div className="flex flex-wrap gap-2"><button disabled={busy || !note.trim() || organization === document.company_id} onClick={() => void perform({ type: 'organization', issueId: currentIssue.id, organizationId: organization, note })} className={issueButtonClass}>Save organization correction</button><button disabled={busy || !note.trim()} onClick={() => void perform({ type: 'request-ocr', issueId: currentIssue.id, note })} className={issueButtonClass}>Request OCR rerun</button><button disabled={busy || !note.trim() || organization !== document.company_id} onClick={() => void perform({ type: 'resolve', issueId: currentIssue.id, note })} className={issueButtonClass}>Resolve issue</button></div></div>}
              <h3 className="pt-2 font-semibold">Action history</h3><ol className="divide-y divide-[#D3E1EC] rounded-lg border border-[#D3E1EC]">{[...currentIssue.events].reverse().map(event => <li key={event.id} className="space-y-1 p-3"><div className="flex flex-wrap items-center justify-between gap-2"><strong className="font-medium">{event.action}</strong><span className="text-[11px] text-[#7288A3]">{event.actor} · {new Date(event.at).toLocaleString()}</span></div><p className="break-words whitespace-pre-wrap text-[#526A83]">{event.details}</p>{!!event.changes?.length && <details className="pt-1"><summary className="cursor-pointer text-[#007EA7]">View changes</summary><dl className="mt-2 space-y-2">{event.changes.map(change => <div key={change.field}><dt className="font-medium">{change.field.replaceAll('_', ' ')}</dt><dd className="max-h-40 overflow-auto whitespace-pre-wrap break-words rounded bg-[#F0F5FA] p-2 text-[11px]">{JSON.stringify(change.before, null, 2)} → {JSON.stringify(change.after, null, 2)}</dd></div>)}</dl></details>}</li>)}</ol>
            </>}
          </section>}
        </>}
      </div>
      <footer className="flex justify-end border-t border-[#D3E1EC] px-6 py-3"><button disabled={busy} onClick={onClose} className={issueButtonClass}>Close</button></footer>
    </div>
  </div>, window.document.body);
}
