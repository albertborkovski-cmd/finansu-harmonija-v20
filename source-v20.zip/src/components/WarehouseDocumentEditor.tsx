import { useMemo, useState, type ReactNode } from 'react';
import { Plus, Printer, Trash2, X } from 'lucide-react';
import { documentTotals, effectivePrice, lineTotals, newWarehouseId, warehouseLedger, type WarehouseDocument, type WarehouseLine, type WarehouseStore } from '../lib/warehouse';
import SearchableSelect from './SearchableSelect';
import { PageActionButton } from './PageHeader';
import { CancelButton, SaveButton } from './ScopedActionButtons';
import { warehousePdf } from '../lib/warehouseExport';

export const warehouseInput = 'h-10 w-full min-w-0 rounded-lg border border-[#D3E1EC] bg-white px-3 text-[13px] font-medium text-[#10233A] outline-none focus:border-[#007EA7] disabled:bg-[#F6F8FB] disabled:text-[#7288A3]';
export function WarehouseField({ label, children }: { label: string; children: ReactNode }) {
  return <label className="flex min-w-0 flex-col gap-1.5 text-[12px] font-medium text-[#7288A3]"><span>{label}</span>{children}</label>;
}
export default function WarehouseDocumentEditor({ document: initial, store, companyName, readOnly, onSave, onClose }: {
  document: WarehouseDocument; store: WarehouseStore; companyName: string; readOnly: boolean;
  onSave: (document: WarehouseDocument, post: boolean) => void; onClose: () => void;
}) {
  const [draft, setDraft] = useState(() => structuredClone(initial));
  const [error, setError] = useState('');
  const [newParty, setNewParty] = useState(false);
  const stockOperation = ['Stocktake', 'Transfer', 'Write-off', 'Consignment', 'Consignment return'].includes(draft.kind);
  const count = draft.kind === 'Stocktake';
  const isReturn = draft.kind === 'Sales return';
  const totals = documentTotals(draft);
  const itemOptions = store.items.filter(item => !item.inactive && (!stockOperation || item.type === 'Product')).map(item => ({ value: item.id, label: `${item.code} · ${item.name}` }));
  const locationOptions = store.locations.filter(row => !row.inactive || row.id === draft.warehouseId).map(row => ({ value: row.id, label: `${row.code} · ${row.name}` }));
  const partyOptions = [...new Set([...store.documents.map(row => row.counterparty), ...store.prices.map(row => row.counterparty), ...store.contracts.map(row => row.counterparty), draft.counterparty].filter(Boolean))];
  const set = <K extends keyof WarehouseDocument>(key: K, value: WarehouseDocument[K]) => setDraft(current => ({ ...current, [key]: value }));
  const lineSet = (id: string, changes: Partial<WarehouseLine>) => setDraft(current => ({ ...current, lines: current.lines.map(line => line.id === id ? { ...line, ...changes } : line) }));
  const save = (post: boolean) => { try { onSave(draft, post); } catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not save this document.'); } };
  const generateCount = () => {
    try {
      const balances = warehouseLedger(store, draft.date).balances.filter(row => row.warehouseId === draft.warehouseId);
      set('lines', balances.map(row => ({ id: newWarehouseId(), itemId: row.itemId, quantity: row.quantity, unitPrice: row.unitCost, vatRate: 0, discount: 0 })));
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not calculate stock.'); }
  };
  const ledger = useMemo(() => {
    try { return warehouseLedger(store, draft.date); }
    catch { return { balances: [], movements: [], consigned: [] }; }
  }, [store, draft.date]);
  const balances = ledger.balances;
  return <div className="fixed inset-0 z-[250] flex items-center justify-center bg-[#10233A]/35 p-3 sm:p-6">
    <section role="dialog" aria-modal="true" aria-label={`${readOnly ? 'View' : 'Edit'} warehouse document`} className="flex max-h-[94dvh] w-full max-w-[1420px] flex-col overflow-hidden rounded-xl border border-[#D3E1EC] bg-white font-montserrat shadow-2xl">
      <header className="flex shrink-0 items-center justify-between gap-3 border-b border-[#E5EDF9] px-6 py-4">
        <div><h2 className="text-[20px] font-semibold text-[#10233A]">{readOnly ? 'View document' : store.documents.some(row => row.id === draft.id) ? 'Edit document' : 'New document'} · {draft.kind}</h2><p className="mt-1 text-[12px] text-[#7288A3]">{companyName} · {draft.number} · {draft.status}</p></div>
        <div className="flex items-center gap-2"><PageActionButton icon={<Printer size={15} />} onClick={() => { void warehousePdf(draft.number, ['Item', 'Quantity', stockOperation ? 'Unit cost' : 'Unit price', 'VAT %', 'Total EUR'], draft.lines.map(line => { const cost = stockOperation ? ledger.movements.find(row => row.documentId === draft.id && row.itemId === line.itemId)?.unitCost ?? balances.find(row => row.itemId === line.itemId && row.warehouseId === draft.warehouseId)?.unitCost ?? line.unitPrice : line.unitPrice; return [store.items.find(item => item.id === line.itemId)?.name ?? '—', line.quantity, Number(cost.toFixed(4)), stockOperation ? 0 : line.vatRate, stockOperation ? Number((line.quantity * cost).toFixed(2)) : lineTotals(line).total]; }), `${companyName} | ${draft.date} | ${draft.counterparty}`).catch(() => setError('The PDF could not be generated.')); }}>Print / PDF</PageActionButton><button type="button" aria-label="Close document" onClick={onClose} className="p-2 text-[#7288A3] hover:text-[#007EA7]"><X size={20} /></button></div>
      </header>
      {error && <p role="alert" className="mx-6 mt-3 rounded-lg bg-red-50 px-3 py-2 text-[12px] text-red-700">{error}</p>}
      <div className="grid min-h-0 flex-1 overflow-auto lg:grid-cols-[300px_minmax(0,1fr)]">
        <div className="flex flex-col gap-4 border-r border-[#E5EDF9] p-6">
          <h3 className="text-[13px] font-semibold text-[#10233A]">Document information</h3>
          <WarehouseField label="Document No. *"><input aria-label="Document No." className={warehouseInput} value={draft.number} disabled={readOnly} onChange={event => set('number', event.target.value)} /></WarehouseField>
          <div className="grid grid-cols-2 gap-3"><WarehouseField label="Date *"><input aria-label="Document date" type="date" className={warehouseInput} value={draft.date} disabled={readOnly} onChange={event => set('date', event.target.value)} /></WarehouseField><WarehouseField label="Due date"><input aria-label="Due date" type="date" className={warehouseInput} value={draft.dueDate} disabled={readOnly || stockOperation} onChange={event => set('dueDate', event.target.value)} /></WarehouseField></div>
          <WarehouseField label="Warehouse *"><SearchableSelect ariaLabel="Document warehouse" className={warehouseInput} value={draft.warehouseId} options={locationOptions} disabled={readOnly || isReturn} onChange={value => set('warehouseId', value)} /></WarehouseField>
          {draft.kind === 'Transfer' && <WarehouseField label="Destination warehouse *"><SearchableSelect ariaLabel="Destination warehouse" className={warehouseInput} value={draft.destinationId} options={locationOptions.filter(row => row.value !== draft.warehouseId)} disabled={readOnly} onChange={value => set('destinationId', value)} /></WarehouseField>}
          {!['Stocktake', 'Transfer', 'Write-off'].includes(draft.kind) && <div className="space-y-1.5"><WarehouseField label="Counterparty *">{newParty ? <input className={warehouseInput} aria-label="New counterparty name" disabled={readOnly} value={draft.counterparty} onChange={event => set('counterparty', event.target.value)} /> : <SearchableSelect ariaLabel="Document counterparty" className={warehouseInput} value={draft.counterparty} options={partyOptions} disabled={readOnly || isReturn} onChange={value => set('counterparty', value)} />}</WarehouseField>{!readOnly && !isReturn && <button type="button" className="text-[11px] text-[#007EA7] hover:underline" onClick={() => setNewParty(value => !value)}>{newParty ? 'Choose existing counterparty' : 'Enter another name'}</button>}</div>}
          {isReturn && <WarehouseField label="Original sale"><input className={warehouseInput} disabled value={store.documents.find(row => row.id === draft.referenceId)?.number ?? '—'} /></WarehouseField>}
          {draft.kind === 'Order' && <WarehouseField label="Channel"><input aria-label="Order channel" className={warehouseInput} value={draft.channel} disabled={readOnly} onChange={event => set('channel', event.target.value)} /></WarehouseField>}
          <WarehouseField label="Currency"><input className={warehouseInput} value="EUR" disabled /></WarehouseField>
          {draft.kind === 'Cash sale' && <div className="grid grid-cols-2 gap-3">{(['cashPaid', 'cardPaid'] as const).map(key => <WarehouseField key={key} label={key === 'cashPaid' ? 'Cash paid' : 'Card paid'}><input aria-label={key === 'cashPaid' ? 'Cash paid' : 'Card paid'} className={warehouseInput} type="number" min="0" step="0.01" value={draft[key]} disabled={readOnly} onChange={event => set(key, Number(event.target.value))} /></WarehouseField>)}</div>}
          <WarehouseField label="Notes"><textarea aria-label="Document notes" className={`${warehouseInput} h-20 py-2`} value={draft.notes} disabled={readOnly} onChange={event => set('notes', event.target.value)} /></WarehouseField>
          <div className="text-[11px] leading-5 text-[#7288A3]">Created by: {draft.createdBy}<br />{new Date(draft.createdAt).toLocaleString('en-GB')}</div>
        </div>
        <div className="flex min-w-0 flex-col gap-4 p-6">
          <div className="flex items-center justify-between gap-3"><h3 className="text-[13px] font-semibold text-[#10233A]">{count ? 'Stock count lines' : 'Items & services'}</h3><div className="flex gap-2">{!readOnly && count && <PageActionButton onClick={generateCount}>Generate balances</PageActionButton>}{!readOnly && !isReturn && <PageActionButton icon={<Plus size={14} />} onClick={() => set('lines', [...draft.lines, { id: newWarehouseId(), itemId: '', quantity: 1, unitPrice: 0, vatRate: stockOperation ? 0 : 21, discount: 0 }])}>Add item</PageActionButton>}</div></div>
          <div className="min-h-[240px] overflow-auto rounded-lg border border-[#D3E1EC]">
            <table className="w-full min-w-[690px] text-left text-[12px]"><thead className="sticky top-0 z-10 bg-[#F6F9FC] text-[#7288A3]"><tr>{['Item', ...(count ? ['Book quantity'] : []), count ? 'Actual quantity' : 'Quantity', stockOperation ? 'Unit cost' : 'Unit price', ...(stockOperation ? [count ? 'Difference' : 'Available'] : ['Discount %', 'VAT %']), 'Total EUR', ''].map((label, index) => <th key={index} className="px-2 py-3 font-medium">{label}</th>)}</tr></thead>
              <tbody>{draft.lines.map((line, index) => {
                const item = store.items.find(row => row.id === line.itemId);
                const stockBalance = balances.find(row => row.itemId === line.itemId && row.warehouseId === draft.warehouseId);
                const postedMovement = ledger.movements.find(row => row.documentId === draft.id && row.itemId === line.itemId);
                const balance = count && postedMovement ? postedMovement.balance - postedMovement.quantityIn + postedMovement.quantityOut : stockBalance?.quantity ?? 0;
                const consignedCost = draft.kind === 'Consignment return' ? ledger.consigned.find(row => row.itemId === line.itemId && row.warehouseId === draft.warehouseId && row.counterparty === draft.counterparty)?.unitCost : undefined;
                const unitCost = postedMovement?.unitCost ?? consignedCost ?? stockBalance?.unitCost ?? line.unitPrice;
                const displayPrice = stockOperation && !count ? unitCost : line.unitPrice;
                return <tr key={line.id} className="border-t border-[#E5EDF9]">
                  <td className="min-w-[240px] p-2">{readOnly || isReturn ? <span>{item ? `${item.code} · ${item.name}` : '—'}</span> : <SearchableSelect portalMenu ariaLabel={`Item ${index + 1}`} className={`${warehouseInput} h-9 text-[12px]`} value={line.itemId} options={itemOptions} onChange={value => { const chosen = store.items.find(row => row.id === value)!; const price = effectivePrice(store, value, draft.counterparty, draft.date); lineSet(line.id, { itemId: value, ...(['Sale', 'Order', 'Cash sale'].includes(draft.kind) ? price : { unitPrice: 0, discount: 0 }), vatRate: stockOperation ? 0 : chosen.vatRate }); }} />}</td>
                  {count && <td className="px-2 tabular-nums">{balance}</td>}
                  <td className="w-[85px] p-2"><input aria-label={`Quantity ${index + 1}`} type="number" min={count ? 0 : 0.000001} step="any" disabled={readOnly} className={`${warehouseInput} h-9 text-[12px]`} value={line.quantity} onChange={event => lineSet(line.id, { quantity: Number(event.target.value) })} /></td>
                  <td className="w-[100px] p-2"><input aria-label={`Unit price ${index + 1}`} type="number" min="0" step="0.01" disabled={readOnly || isReturn || ['Transfer', 'Consignment', 'Consignment return', 'Write-off'].includes(draft.kind)} className={`${warehouseInput} h-9 text-[12px]`} value={Number(displayPrice.toFixed(4))} onChange={event => lineSet(line.id, { unitPrice: Number(event.target.value) })} /></td>
                  {stockOperation ? <td className="px-2 tabular-nums">{count ? line.quantity - balance : item?.type === 'Service' ? '—' : balance}</td> : <>{(['discount', 'vatRate'] as const).map(key => <td key={key} className="w-[80px] p-2"><input aria-label={`${key === 'discount' ? 'Discount' : 'VAT'} ${index + 1}`} className={`${warehouseInput} h-9 text-[12px]`} type="number" min="0" max="100" step="0.01" disabled={readOnly || isReturn} value={line[key]} onChange={event => lineSet(line.id, { [key]: Number(event.target.value) })} /></td>)}</>}
                  <td className="px-2 font-medium tabular-nums">{(stockOperation ? line.quantity * displayPrice : lineTotals(line).total).toFixed(2)}</td>
                  <td className="p-2">{!readOnly && <button type="button" aria-label={`Remove item ${index + 1}`} className="text-[#7288A3] hover:text-red-600" onClick={() => set('lines', draft.lines.filter(row => row.id !== line.id))}><Trash2 size={15} /></button>}</td>
                </tr>;
              })}</tbody></table>
            {!draft.lines.length && <p className="p-8 text-center text-[12px] text-[#7288A3]">{count ? 'Generate balances or add items to count.' : 'Add items to this document.'}</p>}
          </div>
          {!stockOperation && <div className="ml-auto grid grid-cols-3 gap-8 text-[12px] text-[#7288A3]"><div>Net amount<p className="mt-1 text-[16px] font-semibold text-[#10233A]">{totals.net.toFixed(2)}</p></div><div>VAT<p className="mt-1 text-[16px] font-semibold text-[#10233A]">{totals.vat.toFixed(2)}</p></div><div>Total EUR<p className="mt-1 text-[16px] font-semibold text-[#007EA7]">{totals.total.toFixed(2)}</p></div></div>}
          {store.audit.filter(row => row.recordId === draft.id).length > 0 && <details className="text-[11px] text-[#7288A3]"><summary className="cursor-pointer">Document history</summary><div className="mt-2 space-y-1">{store.audit.filter(row => row.recordId === draft.id).map(row => <p key={row.id}>{new Date(row.date).toLocaleString('en-GB')} · {row.action} · {row.actor}</p>)}</div></details>}
        </div>
      </div>
      <footer className="flex shrink-0 justify-end gap-3 border-t border-[#E5EDF9] px-6 py-4"><CancelButton onClick={onClose}>{readOnly ? 'Close' : 'Cancel'}</CancelButton>{!readOnly && <><PageActionButton onClick={() => save(false)}>Save draft</PageActionButton><SaveButton onClick={() => save(true)}>{draft.kind === 'Order' ? 'Save order' : draft.kind === 'Transfer' ? 'Submit for approval' : 'Save & post'}</SaveButton></>}</footer>
    </section>
  </div>;
}
