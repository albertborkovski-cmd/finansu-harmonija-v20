import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Eye } from 'lucide-react';
import { supabase, type Company, type DbDocument } from '../lib/supabase';
import { canAccessIssueOrganization, canReviewDocumentIssues } from '../lib/documentIssueAccess';
import { mapRow } from './Documents';
import DocumentDetailPanel from './DocumentDetailPanel';
import DocumentIssueDialog, { DocumentIssueBadge } from './DocumentIssueDialog';
import OcrSearchField from './OcrSearchField';
import SearchableSelect from './SearchableSelect';
import RefreshAllButton from './RefreshAllButton';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';

export default function DocumentIssueQueue() {
  const [documents, setDocuments] = useState<DbDocument[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('Unresolved');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [review, setReview] = useState<{ documentId: string; companyId: string; issueId: string } | null>(null);
  const [editing, setEditing] = useState<DbDocument | null>(null);
  const tableRef = useRef<HTMLDivElement>(null);
  const allowed = canReviewDocumentIssues();
  const load = useCallback(async () => {
    if (!allowed) { setLoading(false); return; }
    setError('');
    const [docs, organizations] = await Promise.all([supabase.from('documents').select('*'), supabase.from('companies').select('*')]);
    if (docs.error || organizations.error) { setError(docs.error?.message || organizations.error?.message || 'Unable to load reports.'); setLoading(false); return; }
    const accessible = (organizations.data as unknown as Company[] ?? []).filter(company => canAccessIssueOrganization(company));
    setCompanies(accessible);
    setDocuments((docs.data as unknown as DbDocument[] ?? []).filter(document => accessible.some(company => company.id === document.company_id)));
    setLoading(false);
  }, [allowed]);
  useEffect(() => {
    void load();
    const refresh = (event: Event) => { if (event.type === 'storage' || (event as CustomEvent).detail?.table === 'documents') void load(); };
    window.addEventListener('finansu-harmonija:data-changed', refresh); window.addEventListener('storage', refresh);
    return () => { window.removeEventListener('finansu-harmonija:data-changed', refresh); window.removeEventListener('storage', refresh); };
  }, [load]);
  const rows = useMemo(() => documents.flatMap(document => (document.digitization_issues ?? []).map(issue => ({ document, issue, company: companies.find(company => company.id === document.company_id)?.name ?? '—' })))
    .filter(row => (status === 'All' || (status === 'Unresolved' ? row.issue.status !== 'Resolved' : row.issue.status === status)) &&
      [row.document.number, row.document.file_case, row.company, row.issue.message, row.issue.createdBy].join(' ').toLowerCase().includes(query.toLowerCase().trim()))
    .sort((a, b) => b.issue.createdAt.localeCompare(a.issue.createdAt)), [documents, companies, status, query]);
  if (!allowed) return null;
  return <section className="min-w-0 space-y-3 rounded-lg border border-[#D3E1EC] p-4 font-montserrat text-[12px] text-[#10233A]">
    <div className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-[14px] font-semibold">MESO Worker · Reported document issues <span className="ml-2 text-[#7288A3]">{rows.length}</span></h2><RefreshAllButton onRefresh={() => void load()} /></div>
    <div className="flex flex-wrap gap-3"><OcrSearchField ariaLabel="Search reported issues" value={query} onChange={setQuery} /><div className="w-[180px]"><SearchableSelect value={status} options={['Unresolved', 'Open', 'In progress', 'Resolved', 'All']} onChange={setStatus} ariaLabel="Issue status filter" className="h-7 rounded border border-[#D3E1EC] bg-white px-2 pr-8 text-[12px]" /></div></div>
    {error && <p role="alert" className="text-[#B42318]">{error}</p>}
    <div ref={tableRef} className="max-h-[380px] overflow-auto rounded border border-[#D3E1EC]"><table className="w-full min-w-[920px] border-collapse text-left"><thead className="sticky top-0 z-10 bg-[#F0F5FA] text-[#7288A3]"><tr>{['Document', 'Organization', 'Reported issue', 'Issue status', 'Reported by', 'Reported at'].map(label => <th key={label} className="px-3 py-3 font-medium">{label}</th>)}<th className="system-table-row-actions"><span className="sr-only">Actions</span></th></tr></thead><tbody>
      {rows.map(({ document, issue, company }) => <tr key={issue.id} className="border-t border-[#D3E1EC] hover:bg-[#F8FDFF]"><td className="px-3 py-3"><button className="text-[#007EA7] hover:underline" onClick={() => setReview({ documentId: document.id, companyId: document.company_id ?? '', issueId: issue.id })}>{document.number || document.file_case}</button></td><td className="px-3 py-3">{company}</td><td className="max-w-[300px] px-3 py-3"><span className="block truncate" title={issue.message}>{issue.message}</span></td><td className="px-3 py-3"><DocumentIssueBadge status={issue.status} /></td><td className="px-3 py-3">{issue.createdBy}</td><td className="whitespace-nowrap px-3 py-3">{new Date(issue.createdAt).toLocaleString()}</td><td className="system-table-row-actions px-3 py-3"><div className="flex justify-end"><button type="button" title="Review issue" aria-label={`Review issue for ${document.number || document.file_case}`} onClick={() => setReview({ documentId: document.id, companyId: document.company_id ?? '', issueId: issue.id })} className="flex h-7 w-7 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7]"><Eye size={14} /></button></div></td></tr>)}
      {!rows.length && <tr><td colSpan={7} className="px-4 py-6 text-center text-[#7288A3]">{loading ? 'Loading reported issues…' : 'No reported issues match the selected filters.'}</td></tr>}
    </tbody></table></div><HorizontalTableScrollbar scrollRef={tableRef} fixed={false} />
    {review && !editing && <DocumentIssueDialog key={review.issueId} {...review} initialIssueId={review.issueId} worker onClose={() => setReview(null)} onEditDocument={setEditing} />}
    {editing && <DocumentDetailPanel key={editing.id} doc={mapRow(editing)} companyName={companies.find(company => company.id === editing.company_id)?.name} onClose={() => { setEditing(null); void load(); }} onSaved={() => void load()} />}
  </section>;
}
