import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AlertTriangle, Eye, FileText, X, ChevronDown, ChevronRight, Download, ChevronsDownUp, ChevronsUpDown, BookCheck, Calculator, Check, Copy, Pencil, Plus, Printer, Trash2, Mail } from "lucide-react";
import { supabase, type Company, type DbDocument } from "../lib/supabase";
import { importMenuRecords } from "../lib/menuImport";
import { mapRow, type Document } from "./Documents";
import { loadCompanyGeneralLedgerAccountOptions, loadCompanyGeneralLedgerAccountHierarchy } from "./GeneralLedgerView";
import { loadOrganizationReferenceValues } from './OrganizationReferenceValuesView';
import { usePersistentState } from "../hooks/usePersistentState";
import ColumnSettingsPanel, { type ColConfig } from "./ColumnSettingsPanel";
import ColumnSortButton, { useMultiColumnSort } from "./ColumnSortButton";
import CompanyBreadcrumb from "./CompanyBreadcrumb";
import HorizontalTableScrollbar from "./HorizontalTableScrollbar";
import OcrSearchField from "./OcrSearchField";
import { PageHeader, PageActionButton } from "./PageHeader";
import RefreshAllButton from "./RefreshAllButton";
import { ColumnSettingsButton, ImportDataButton } from "./ScopedActionButtons";
import SystemAddFilters from "./SystemAddFilters";
import TablePagination from "./TablePagination";
import { TABLE_BATCH_SIZE } from "../lib/tablePaging";
import { ResizeHandle, useColumnResize } from "./useColumnResize";
import GlJournalDocumentView from './GlJournalDocumentView';
import GlJournalClosingDialog from './GlJournalClosingDialog';
import VatReconciliationCompanyDialog from './VatReconciliationCompanyDialog';
import GlJournalEntryEditor from './GlJournalEntryEditor';
import { RowDeleteButton } from './DeleteButtons';
import GlJournalDialog from './GlJournalDialog';
import GlJournalPrintView from './GlJournalPrintView';
import GlJournalRevaluationView from './GlJournalRevaluationView';
import { calculateRevaluation, journalRevaluationRates, revaluationDraft, SAMPLE_FX_ACCOUNTS, SAMPLE_MONETARY_TYPES, type RevaluationReport } from '../lib/glJournalRevaluation';
import { deactivateJournalDocument } from '../lib/glJournalLifecycle';
import { copyJournalDraft, editJournalDraft, newJournalDraft, mergeJournalRows, journalDraftStorageKey, loadJournalDrafts, nextJournalNumber, saveJournalDraft, updateJournalDraft, type JournalDraft, type JournalAccountOption } from '../lib/glJournalDrafts';
import { AUTH_SESSION_KEY, getCurrentUserName } from '../lib/currentUser';
import { canEditMenu, parseSession } from '../lib/accessControl';
import { canAccessAssignedOrganization } from '../lib/linkedSettingsData';
import { rememberReconciliationLedgerUsage } from '../lib/generalLedgerUsage';
import { JOURNAL_CLOSING_TITLES, type JournalClosingKind } from '../lib/glJournalClosing';
import { buildJournalGroups, buildJournalTableRows, createSampleJournalRows, journalCurrencyTotals, journalDate, journalWorkingRows, JOURNAL_GROUPINGS, JOURNAL_GROUP_LABELS, type JournalGroup, type JournalGroupKey, type JournalTableRow, type GlJournalRow } from '../lib/glJournal';

type JournalColumnKey =
  | "documentNumber"
  | "internalNumber"
  | "costCenter"
  | "object" | "department" | "employee" | "vehicle" | "createdBy" | "recordStatus"
  | "currency"
  | "operationDate"
  | "documentType"
  | "documentSubtype"
  | "counterparty"
  | "account"
  | "postingStatus"
  | "debit"
  | "credit"
  | "total";

type JournalRow = GlJournalRow;

const POSTED_STATUSES = new Set<Document["status"]>([
  "Approved",
  "Paid",
  "Transferred",
]);

const DEFAULT_COLUMNS: ColConfig[] = [
  { key: "operationDate", label: "Operation date", width: 140, visible: true },
  { key: "internalNumber", label: "Internal No.", width: 110, visible: true },
  { key: "counterparty", label: "Counterparty", width: 200, visible: true },
  { key: "documentNumber", label: "Document No.", width: 150, visible: true },
  { key: "account", label: "GL account", width: 210, visible: true },
  { key: "documentType", label: "Type", width: 110, visible: true },
  { key: "documentSubtype", label: "Subtype", width: 190, visible: false },
  { key: "costCenter", label: "Cost center", width: 120, visible: true },
  { key: "object", label: "Object", width: 155, visible: true },
  { key: "department", label: "Department", width: 145, visible: true },
  { key: "employee", label: "Employee", width: 165, visible: true },
  { key: "vehicle", label: "Vehicle", width: 175, visible: true },
  { key: "createdBy", label: "Created by", width: 165, visible: true },
  { key: "recordStatus", label: "Status", width: 100, visible: true },
  { key: "postingStatus", label: "Posting status", width: 150, visible: false },
  { key: "currency", label: "Currency", width: 80, visible: true },
  { key: "debit", label: "Debit", width: 100, visible: true },
  { key: "credit", label: "Credit", width: 100, visible: true },
  { key: "total", label: "Total", width: 150, visible: false },
];

function amount(value: string | number | undefined) {
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;
  const normalized = String(value ?? "")
    .replace(/[^0-9,.-]/g, "")
    .replace(/,(?=\d{1,2}$)/, ".");
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : 0;
}

function number(value: number) {
  return value.toLocaleString("en-GB", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

function money(value: number, currency: string) {
  return `${number(value)} ${currency || "EUR"}`;
}

function cellValue(row: JournalRow, key: JournalColumnKey) {
  return key === 'currency' ? row.document.currency : key === 'recordStatus' ? row.inactive ? 'Inactive' : 'Active' : row[key] || (typeof row[key] === 'number' ? 0 : '—');
}

function createJournalCandidates(document: Document, activeAccounts: Set<string>): JournalRow[] {
  const documentTotal = amount(document.totalAmount || document.amountWithoutVat);
  const isAccountingNote = /accounting[\s_-]*note/i.test(document.documentType);
  const posted = POSTED_STATUSES.has(document.status);
  const sourceLines = document.lineItems.length > 0
    ? document.lineItems
    : document.summaryLineItems;
  const lineAccounts = sourceLines
    .map((line, index) => ({
      id: line.id || `${document.id}-${index}`,
      account: line.expense?.trim() || "",
      value: amount(line.total || line.subtotal),
    }))
    .filter((line) => line.account);
  const accountLines = lineAccounts.length > 0
    ? lineAccounts
    : document.expenseAccount.trim()
      ? [{ id: document.id, account: document.expenseAccount.trim(), value: documentTotal }]
      : [];
  const fallbackLineValue = accountLines.length > 0
    ? documentTotal / accountLines.length
    : documentTotal;

  return accountLines.map((line) => {
    const total = line.value > 0 ? line.value : fallbackLineValue;
    const debit = isAccountingNote ? amount(document.debit) : total;
    const credit = isAccountingNote ? amount(document.credit) : total;
    const balanced = debit > 0 && credit > 0 && Math.abs(debit - credit) < 0.01;
    return {
      id: `${document.id}:${line.id}`,
      documentNumber: document.number || '—',
      internalNumber: document.id,
      costCenter: document.costCenter || '—',
      object: sourceLines.find(item => item.id === line.id)?.object || document.objectProject || '',
      department: sourceLines.find(item => item.id === line.id)?.department || document.departmentCode || '',
      employee: document.accountableResponsible || '',
      operationDate: document.operationDate || document.documentDate || "—",
      documentType: document.documentType || "—",
      documentSubtype: document.documentSubtype || "—",
      counterparty: document.clientCounterparty || "—",
      account: line.account,
      postingStatus: posted ? "Posted" : "Unposted",
      debit,
      credit,
      total: Math.max(debit, credit, total),
      accountActive: activeAccounts.has(line.account),
      posted,
      balanced,
      document,
    } satisfies JournalRow;
  });
}

export type GlJournalSection = 'journal' | 'revaluation';

export default function CompanyGlJournalView({ company, dataSource = 'test', section, onSectionChange }: { company: Company; dataSource?: 'company' | 'test'; section: GlJournalSection; onSectionChange: (section: GlJournalSection) => void }) {
  const [fixedPage0, setFixedPage0] = useState(1);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [printOpen, setPrintOpen] = useState(false);
  const [deactivation, setDeactivation] = useState<{ id: string; number: string; revision: number | null } | null>(null);
  const [expansion, setExpansion] = useState<Record<string, boolean>>({});
  const [closingKind, setClosingKind] = useState<JournalClosingKind | null>(null);
  const [vatEmailOpen, setVatEmailOpen] = useState(false);
  const [closingNotice, setClosingNotice] = useState('');
  const [refreshRevision, setRefreshRevision] = useState(0);
  const [openDocument, setOpenDocument] = useState<JournalRow | null>(null);
  const [selectedDocumentId, setSelectedDocumentId] = useState<string | null>(null);
  const [entryEditor, setEntryEditor] = useState<{ id: string; mode: 'new' | 'copy' | 'edit'; expectedRevision: number | null; draft: JournalDraft; sourceRow?: GlJournalRow } | null>(null);
  const [entryError, setEntryError] = useState('');
  const [showColumns, setShowColumns] = useState(false);
  const [columns, setColumns] = usePersistentState<ColConfig[]>(
    `finansu-harmonija:v19:gl-journal-column-layout:${company.id}`,
    DEFAULT_COLUMNS,
  );
  const [filterKeys, setFilterKeys] = useState<string[]>([]);
  const [filterValues, setFilterValues] = useState<Record<string, string[]>>({});
  const selectedMonth = filterKeys.includes('period') && filterValues.period?.length === 1 ? filterValues.period[0] : '';
  const period = /^\d{4}-\d{2}$/.test(selectedMonth) ? { from: `${selectedMonth}-01`, to: new Date(Date.UTC(Number(selectedMonth.slice(0, 4)), Number(selectedMonth.slice(5, 7)), 0)).toISOString().slice(0, 10) } : { from: '', to: '' };
  const accountFilter = filterKeys.includes('account') ? (filterValues.account || []).join(', ') : '';
  const tableScrollRef = useRef<HTMLDivElement>(null);
  const visibleColumns = columns.filter((column) => column.visible);

  useEffect(() => setFixedPage0(1), [company.id, filterKeys, filterValues, query, dataSource]);
  const { startResize } = useColumnResize(columns, setColumns);

  useEffect(() => {
    setColumns((current) => {
      const synchronized = current.map((column) => {
        const systemColumn = DEFAULT_COLUMNS.find(
          (candidate) => candidate.key === column.key,
        );
        return systemColumn
          ? { ...column, label: systemColumn.label }
          : column;
      });
      const missing = DEFAULT_COLUMNS.filter(
        (systemColumn) =>
          !synchronized.some((column) => column.key === systemColumn.key),
      );
      // Place newly introduced columns in the system order, keeping saved widths
      // and visibility of existing columns intact.
      missing.forEach(column => {
        const defaultIndex = DEFAULT_COLUMNS.findIndex(item => item.key === column.key);
        const nextKey = DEFAULT_COLUMNS.slice(defaultIndex + 1).find(item => synchronized.some(saved => saved.key === item.key))?.key;
        const insertAt = nextKey ? synchronized.findIndex(item => item.key === nextKey) : synchronized.length;
        synchronized.splice(insertAt, 0, column);
      });
      return synchronized;
    });
  }, [setColumns]);

  const loadDocuments = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("documents")
      .select("*")
      .eq("company_id", company.id)
      .order("created_at", { ascending: false });
    if (!error && data)
      setDocuments((data as unknown as DbDocument[]).map(mapRow));
    setLoading(false);
  }, [company.id]);

  useEffect(() => {
    void loadDocuments();
  }, [loadDocuments, refreshRevision]);

  useEffect(() => {
    const refreshChart = (event: Event) => {
      const changedCompany = (event as CustomEvent<{ companyId?: string }>).detail?.companyId;
      if (!changedCompany || changedCompany === company.id) setRefreshRevision(value => value + 1);
    };
    const refreshStoredChart = (event: StorageEvent) => {
      if (!event.key || event.key === `finansu-harmonija:v12:company-general-ledger:${company.id}`
        || event.key === 'finansu-harmonija:v7:general-ledger-templates') setRefreshRevision(value => value + 1);
    };
    window.addEventListener('company-general-ledger-updated', refreshChart);
    window.addEventListener('general-ledger-updated', refreshChart);
    window.addEventListener('storage', refreshStoredChart);
    return () => {
      window.removeEventListener('company-general-ledger-updated', refreshChart);
      window.removeEventListener('general-ledger-updated', refreshChart);
      window.removeEventListener('storage', refreshStoredChart);
    };
  }, [company.id]);

  const activeAccounts = useMemo(
    () => {
      void refreshRevision;
      return new Set(
        loadCompanyGeneralLedgerAccountOptions(
          company.id,
          company.general_ledger ?? "",
        ),
      );
    },
    [company.general_ledger, company.id, refreshRevision],
  );

  const companyCandidates = useMemo(
    () =>
      documents
        .flatMap((document) => createJournalCandidates(document, activeAccounts)),
    [activeAccounts, documents],
  );
  const sampleRows = useMemo(() => createSampleJournalRows(company.id), [company.id]);
  const baseCandidates = dataSource === 'test' ? sampleRows : companyCandidates;
  const loadEntryAccounts = useCallback(() => {
    const chart = loadCompanyGeneralLedgerAccountHierarchy(company.id, company.general_ledger ?? '');
    const accounts = new Map<string, JournalAccountOption>(chart.map(account => [account.code, { code: account.code, name: account.name, type: account.type, calculateExchangeDifferences: account.calculateExchangeDifferences }]));
    if (dataSource === 'test') {
      sampleRows.forEach(row => { if (row.accountActive && !accounts.has(row.account)) accounts.set(row.account, { code: row.account, name: row.accountName || row.account, type: SAMPLE_MONETARY_TYPES[row.account] }); });
      SAMPLE_FX_ACCOUNTS.forEach(account => { if (!accounts.has(account.code)) accounts.set(account.code, account); });
    }
    return [...accounts.values()].sort((a, b) => a.code.localeCompare(b.code, undefined, { numeric: true }));
  }, [company.id, company.general_ledger, dataSource, sampleRows]);
  const entryAccounts = useMemo(() => { void refreshRevision; return loadEntryAccounts(); }, [loadEntryAccounts, refreshRevision]);
  const entryCurrencies = useMemo(() => { void refreshRevision; return loadOrganizationReferenceValues('Base currency'); }, [refreshRevision]);
  const draftState = useMemo(() => {
    void refreshRevision;
    try { return { entries: loadJournalDrafts(window.localStorage, company.id, dataSource), error: '' }; }
    catch (error) { return { entries: [], error: error instanceof Error ? error.message : 'Saved journal entries are unavailable.' }; }
  }, [company.id, dataSource, refreshRevision]);
  const candidates = useMemo(() => mergeJournalRows(baseCandidates, draftState.entries, new Set(entryAccounts.map(account => account.code))), [baseCandidates, draftState.entries, entryAccounts]);
  const loadVatCompanyData = useCallback(async (selected: Company) => {
    const session = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
    if (!session || !canAccessAssignedOrganization(selected, session)) throw new Error('You do not have access to this company.');
    if (selected.id === company.id) return { rows: candidates, accounts: entryAccounts, testData: dataSource === 'test' };
    const result = await supabase.from('documents').select('*').eq('company_id', selected.id);
    if (result.error) throw new Error('Company GL entries could not be loaded.');
    const chart = loadCompanyGeneralLedgerAccountHierarchy(selected.id, selected.general_ledger || '');
    const accounts = chart.map(account => ({ code: account.code, name: account.name }));
    const codes = new Set(accounts.map(account => account.code));
    const source = (result.data as unknown as DbDocument[] || []).map(mapRow).flatMap(document => createJournalCandidates(document, codes));
    return { rows: mergeJournalRows(source, loadJournalDrafts(window.localStorage, selected.id, 'company'), codes), accounts, testData: false };
  }, [company.id, candidates, entryAccounts, dataSource]);
  const canCreateEntry = () => {
    const session = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
    return Boolean(session && canEditMenu(session, 'documents') && canAccessAssignedOrganization(company, session));
  };
  const mayCreateEntry = canCreateEntry();
  const saveRevaluation = (report: RevaluationReport) => {
    if (!canCreateEntry()) throw new Error('You do not have permission to create journal entries for this company.');
    const saved = loadJournalDrafts(window.localStorage, company.id, dataSource);
    const accounts = loadEntryAccounts();
    const source = mergeJournalRows(baseCandidates, saved, new Set(accounts.map(account => account.code)));
    const rates = journalRevaluationRates(window.localStorage, dataSource === 'test');
    const fresh = calculateRevaluation(source, accounts, rates, { ...report, baseCurrency: company.base_currency || 'EUR' });
    if (fresh.fingerprint !== report.fingerprint) throw new Error('GL entries or exchange rates changed. Run the calculation again.');
    const existing = saved.find(entry => !entry.inactive && entry.revaluation?.fingerprint === fresh.fingerprint);
    if (existing) {
      setRefreshRevision(value => value + 1);
      return existing.number;
    }
    if (saved.some(entry => !entry.inactive && entry.revaluation?.date === report.date && entry.revaluation.accountCodes.some(code => report.accountCodes.includes(code)))) throw new Error('A revaluation journal already exists for these accounts and this date. Review it in Journal entries.');
    const draft = revaluationDraft(fresh, nextJournalNumber(source, fresh.date));
    const entry = saveJournalDraft(window.localStorage, { companyId: company.id, mode: dataSource, id: crypto.randomUUID(), createdAt: new Date().toISOString(), createdBy: getCurrentUserName(), revaluation: fresh }, draft, accounts, source.map(row => row.documentNumber), savedEntry => rememberReconciliationLedgerUsage(savedEntry, company.id, company.general_ledger || ''));
    setRefreshRevision(value => value + 1);
    return entry.number;
  };
  const openEntryEditor = (documentId: string, mode: 'new' | 'copy' | 'edit' = 'copy', selectedRow?: GlJournalRow) => {
    setEntryError('');
    if (!canCreateEntry()) { setEntryError('You do not have permission to create journal entries for this company.'); return; }
    try {
      const today = new Date();
      const date = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      const saved = loadJournalDrafts(window.localStorage, company.id, dataSource);
      const source = mergeJournalRows(baseCandidates, saved, new Set(entryAccounts.map(account => account.code)));
      const existing = saved.find(entry => entry.id === documentId);
      if (mode === 'edit' && existing?.inactive) throw new Error('Inactive journal entries cannot be edited. Copy the entry to create a new one.');
      if (mode === 'edit' && !existing && !(dataSource === 'test' && baseCandidates.some(row => row.document.id === documentId && row.sample))) throw new Error('Edit this operation in its source document.');
      const documentNumber = nextJournalNumber(source, date);
      const draft = mode === 'new' ? newJournalDraft(documentNumber, date, entryCurrencies.includes('EUR') ? 'EUR' : entryCurrencies[0] || '') : mode === 'edit' ? editJournalDraft(source, documentId) : copyJournalDraft(source, documentId, documentNumber, date);
      setEntryEditor({ id: mode === 'edit' ? documentId : crypto.randomUUID(), mode, expectedRevision: existing ? existing.revision || 0 : null, draft, sourceRow: source.find(row => row.id === selectedRow?.id) || source.find(row => row.document.id === documentId) });
      setRefreshRevision(current => current + 1);
    } catch (error) { setEntryError(error instanceof Error ? error.message : 'The journal entry could not be opened.'); }
  };
  const saveEntry = (draft: JournalDraft) => {
    if (!entryEditor || !canCreateEntry()) throw new Error('You do not have permission to create journal entries for this company.');
    if (!loadOrganizationReferenceValues('Base currency').includes(draft.currency)) throw new Error('Select an active currency.');
    const entry = entryEditor.mode === 'edit'
      ? updateJournalDraft(window.localStorage, { companyId: company.id, mode: dataSource, id: entryEditor.id, expectedRevision: entryEditor.expectedRevision, changedAt: new Date().toISOString(), changedBy: getCurrentUserName() }, draft, loadEntryAccounts(), baseCandidates, (previous, saved) => { rememberReconciliationLedgerUsage(previous, company.id, company.general_ledger ?? ''); rememberReconciliationLedgerUsage(saved, company.id, company.general_ledger ?? ''); })
      : saveJournalDraft(window.localStorage, { companyId: company.id, mode: dataSource, id: entryEditor.id, createdAt: new Date().toISOString(), createdBy: getCurrentUserName() }, draft, loadEntryAccounts(), candidates.map(row => row.documentNumber), saved => rememberReconciliationLedgerUsage(saved, company.id, company.general_ledger ?? ''));
    setRefreshRevision(current => current + 1);
    setSelectedDocumentId(entry.id);
    setEntryEditor(null);
    setQuery(entry.number);
    setFilterKeys([]); setFilterValues({});
    setClosingNotice(`${entry.number} · ${entryEditor.mode === 'edit' ? 'Changes saved.' : 'Journal entry saved as Unposted.'}`);
  };
  const deactivateEntry = () => {
    if (!deactivation) return;
    try {
      if (!canCreateEntry()) throw new Error('You do not have permission to deactivate journal entries.');
      const latest = mergeJournalRows(baseCandidates, loadJournalDrafts(window.localStorage, company.id, dataSource), new Set(loadEntryAccounts().map(account => account.code)));
      const entry = deactivateJournalDocument(window.localStorage, { companyId: company.id, mode: dataSource, id: deactivation.id, expectedRevision: deactivation.revision, changedAt: new Date().toISOString(), changedBy: getCurrentUserName() }, latest);
      setDeactivation(null); setRefreshRevision(value => value + 1); setEntryError(''); setSelectedDocumentId(null);
      setClosingNotice(`${entry.number} · Inactive · Entry retained in the list and excluded from active totals.`);
    } catch (error) { setEntryError(error instanceof Error ? error.message : 'The entry could not be deactivated.'); }
  };
  useEffect(() => {
    setSelectedDocumentId(null); setEntryEditor(null); setEntryError(''); setDeactivation(null); setPrintOpen(false); setVatEmailOpen(false); setClosingKind(null);
  }, [company.id, dataSource]);
  useEffect(() => {
    const refreshDrafts = (event: StorageEvent) => { if (event.key === journalDraftStorageKey(company.id, dataSource)) setRefreshRevision(current => current + 1); };
    window.addEventListener('storage', refreshDrafts);
    return () => window.removeEventListener('storage', refreshDrafts);
  }, [company.id, dataSource]);
  const unbalancedCount = candidates.filter(
    (candidate) => !candidate.inactive && candidate.posted && !candidate.balanced,
  ).length;
  const rows = useMemo(() => journalWorkingRows(candidates), [candidates]);

  const filterColumns = DEFAULT_COLUMNS.map((column) => ({
    key: column.key,
    label: column.label,
    options: Array.from(
      new Set(
        rows.map((row) => {
          const key = column.key as JournalColumnKey;
          const value = cellValue(row, key);
          return typeof value === "number"
            ? money(value, row.document.currency)
            : String(value);
        }),
      ),
    ),
  }));

  filterColumns.push({ key: 'period', label: 'Period', options: [...new Set(rows.map(row => journalDate(row.operationDate).slice(0, 7)))].filter(value => /^\d{4}-\d{2}$/.test(value)).sort().reverse() });

  const filteredRows = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase();
    return rows.filter((row) => {
      if (
        normalized &&
        ![
          row.operationDate,
          row.documentType,
          row.documentSubtype,
          row.counterparty,
          row.account,
          row.accountName || '',
          row.description || '',
          row.document.number,
          row.internalNumber,
          row.costCenter,
          row.object || '', row.department || '', row.employee || '', row.vehicle || '', row.createdBy || '',
          row.document.currency,
        ].some((value) => value.toLocaleLowerCase().includes(normalized))
      )
        return false;
      return filterKeys.every((key) => {
        const selected = filterValues[key] ?? [];
        if (selected.length === 0) return true;
        const value = key === 'period' ? journalDate(row.operationDate).slice(0, 7) : cellValue(row, key as JournalColumnKey);
        const rendered =
          typeof value === "number"
            ? money(value, row.document.currency)
            : String(value);
        return selected.includes(rendered);
      });
    });
  }, [filterKeys, filterValues, query, rows]);

  const { sortedRows, changeSort, directionFor } = useMultiColumnSort<
    JournalRow,
    JournalColumnKey
  >(filteredRows, (row, key) => key === 'operationDate' ? journalDate(row.operationDate) : cellValue(row, key));

  const documentIds = useMemo(() => [...new Set(sortedRows.map(row => row.document.id))], [sortedRows]);
  const groupKeys = useMemo(() => JOURNAL_GROUPINGS[0].keys.filter(key => key !== 'account' && columns.some(column => column.key === key && column.visible)), [columns]);
  const loadedDocumentIds = useMemo(() => new Set(documentIds.slice(0, fixedPage0 * TABLE_BATCH_SIZE)), [documentIds, fixedPage0]);
  const groups = useMemo(() => buildJournalGroups(sortedRows, groupKeys), [sortedRows, groupKeys]);
  const totals = useMemo(() => journalCurrencyTotals(filteredRows.filter(row => !row.inactive)), [filteredRows]);
  const isGroupExpanded = useCallback((group: JournalGroup) => expansion[group.id] ?? true, [expansion]);
  const tableRows = useMemo(() => buildJournalTableRows(groups, sortedRows, isGroupExpanded, loadedDocumentIds), [groups, sortedRows, isGroupExpanded, loadedDocumentIds]);
  const allGroups = useMemo(() => {
    const result: JournalGroup[] = [];
    const visit = (nodes: JournalGroup[]) => nodes.forEach(group => { result.push(group); visit(group.children); });
    visit(groups);
    return result;
  }, [groups]);
  const toggleColumnGroups = (key: JournalGroupKey, expanded: boolean) => {
    const depth = groupKeys.indexOf(key);
    setExpansion(current => {
      const next = { ...current };
      allGroups.forEach(group => {
        if (group.key === key || (expanded && group.depth < depth)) next[group.id] = expanded;
      });
      return next;
    });
  };
  const exportJournal = () => {
    const values = [visibleColumns.map(column => column.label), ...sortedRows.map(row => visibleColumns.map(column => String(cellValue(row, column.key as JournalColumnKey) ?? '')))];
    const url = URL.createObjectURL(new Blob(['\uFEFF' + values.map(row => row.map(value => `"${value.replace(/"/g, '""')}"`).join(',')).join('\r\n')], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a'); link.href = url; link.download = `gl-journal-${dataSource === 'test' ? 'test-' : ''}${company.id}.csv`; link.click(); URL.revokeObjectURL(url);
  };

  const renderCell = (row: JournalRow, key: string) => {
    if (key === 'recordStatus') return <span data-no-strike className={`inline-flex rounded px-2 py-0.5 text-[11px] font-medium ${row.inactive ? 'bg-[#F1F3F5] text-[#7288A3]' : 'bg-[#E7F8F2] text-[#087A5B]'}`}>{row.inactive ? 'Inactive' : 'Active'}</span>;
    if (key === 'documentNumber') return <button onClick={() => setOpenDocument(row)} className="truncate text-[#007EA7] hover:underline">{row.documentNumber}</button>;
    if (key === "account") {
      return (
        <div className="flex min-w-0 items-center gap-2">
          <span className="min-w-0"><span className="block truncate leading-4">{row.account}</span>{row.accountName && <span className="block truncate text-[10px] leading-3 text-[#7288A3]">{row.accountName}</span>}</span>
          {!row.accountActive && row.account !== "—" && (
            <span className="flex-shrink-0 rounded bg-[#FFF2E8] px-1.5 py-0.5 text-[10px] font-semibold text-[#C45100]">
              Archived
            </span>
          )}
          {!row.balanced && (
            <span className="flex-shrink-0 rounded bg-[#FFF2E8] px-1.5 py-0.5 text-[10px] font-semibold text-[#C45100]">
              Unbalanced
            </span>
          )}
        </div>
      );
    }
    if (["debit", "credit", "total"].includes(key)) {
      const value = row[key as "debit" | "credit" | "total"];
      return visibleColumns.some(column => column.key === 'currency') ? number(value) : money(value, row.document.currency);
    }
    if (key === "postingStatus") {
      return (
        <span className={`inline-flex rounded px-2 py-0.5 text-[11px] font-semibold ${row.posted ? "bg-[#E7F8F2] text-[#087A5B]" : "bg-[#E5EDF9] text-[#7288A3]"}`}>
          {row.postingStatus}
        </span>
      );
    }
    return String(cellValue(row, key as JournalColumnKey) ?? "—");
  };

  const renderTableCell = (row: JournalTableRow, key: JournalColumnKey) => {
    if (row.entry) return renderCell(row.entry, key);
    if (key === 'debit' || key === 'credit') return visibleColumns.some(column => column.key === 'currency') ? number(row[key]) : money(row[key], row.currency);
    if (key === 'currency') return row.currency;
    if (key === 'total') return '—';
    const values = [...new Set(row.entries.map(entry => String(cellValue(entry, key))))];
    if (values.length === 1) return renderCell(row.entries[0], key);
    const noun = key === 'documentNumber' || key === 'internalNumber' ? 'documents' : key === 'account' ? 'accounts' : key === 'counterparty' ? 'counterparties' : key === 'documentType' ? 'types' : 'values';
    return <span className="text-[11px] font-normal text-[#7288A3]">{values.length} {noun}</span>;
  };

  const renderTableRows = () => tableRows.map(row => {
    const singleDocument = new Set(row.entries.map(entry => entry.document.id)).size === 1;
    const selected = singleDocument && selectedDocumentId === row.entries[0].document.id;
    return <tr key={row.id} data-journal-inactive={row.entries.every(entry => entry.inactive) || undefined} data-journal-entry={row.entry?.id} data-journal-summary={row.summary?.key} aria-selected={selected} tabIndex={singleDocument ? 0 : undefined}
      onClick={event => { if (singleDocument && !(event.target as HTMLElement).closest('button, input, a')) setSelectedDocumentId(row.entries[0].document.id); }}
      onKeyDown={event => { if (singleDocument && event.target === event.currentTarget && ['Enter', ' '].includes(event.key)) { event.preventDefault(); setSelectedDocumentId(row.entries[0].document.id); } }}
      className={`h-10 text-[12px] text-[#10233A] hover:bg-[#E7F4F9] focus-visible:outline focus-visible:outline-1 focus-visible:outline-[#007EA7] ${singleDocument ? 'cursor-pointer' : ''} ${selected ? 'bg-[#E5EDF9]' : row.summary ? 'bg-[#F2F7FC] font-medium' : 'odd:bg-[#F8FDFF] even:bg-white'}`}>
      {visibleColumns.map(column => {
        const key = column.key as JournalColumnKey;
        if (row.coveredCells.includes(key as JournalGroupKey)) return null;
        const cell = row.groupCells[key as JournalGroupKey];
        const numeric = ['debit', 'credit', 'total'].includes(key);
        if (cell) {
          const { group, expanded, rowSpan } = cell;
          const label = `${JOURNAL_GROUP_LABELS[group.key]} ${group.label}`;
          return <td key={key} rowSpan={rowSpan} data-record-inactive={group.rows.every(entry => entry.inactive) || undefined} data-journal-group={key} className={`border-b border-r border-[#E5EDF9] px-2 py-1.5 align-top ${selected && new Set(group.rows.map(entry => entry.document.id)).size === 1 ? 'bg-[#E5EDF9]' : 'bg-white'}`}>
            <div className="flex min-w-0 items-start gap-1.5">
              <button type="button" aria-expanded={expanded} aria-label={`${expanded ? 'Collapse' : 'Expand'} ${label}`} title={`${expanded ? 'Collapse' : 'Expand'} ${label}`} onClick={() => setExpansion(current => ({ ...current, [group.id]: !expanded }))} className="mt-px flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded border border-[#D3E1EC] bg-[#F8FDFF] text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7]">
                {expanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
              </button>
              <div className="min-w-0 flex-1 overflow-hidden font-medium" title={key === 'account' ? `${group.label} ${group.rows[0].accountName || ''}` : group.label}>
                {renderCell(group.rows[0], key)}
                {!expanded && <span className="mt-0.5 block truncate text-[10px] font-normal leading-[14px] text-[#7288A3]">{group.documentCount} doc{group.documentCount === 1 ? '' : 's'} · {group.rows.length} lines</span>}
              </div>
            </div>
          </td>;
        }
        return <td key={key} data-record-inactive={row.entries.every(entry => entry.inactive) || undefined} className={`overflow-hidden border-b border-r border-[#E5EDF9] px-3 py-1.5 align-middle ${numeric ? 'text-right tabular-nums' : ''}`}><div className="truncate">{renderTableCell(row, key)}</div></td>;
      })}
      <td className="system-table-row-actions border-b border-[#E5EDF9] px-3 text-right align-middle">
        {singleDocument && <div className="flex justify-end gap-2">
          <button type="button" title={dataSource === 'test' || draftState.entries.some(entry => entry.id === row.entries[0].document.id) ? 'Edit' : 'Edit in source document'} aria-label={`Edit ${row.entries[0].documentNumber} · ${row.entry?.account || 'summary'}`} disabled={row.entries[0].inactive || !mayCreateEntry || Boolean(draftState.error) || !(dataSource === 'test' || draftState.entries.some(entry => entry.id === row.entries[0].document.id))} onClick={() => { setSelectedDocumentId(row.entries[0].document.id); openEntryEditor(row.entries[0].document.id, 'edit', row.entry || row.entries[0]); }} className="flex h-6 w-6 items-center justify-center text-[#7288A3] hover:text-[#007EA7] disabled:opacity-40"><Pencil size={15} /></button>
          <button type="button" title="Copy journal entry" aria-label={`Copy ${row.entries[0].documentNumber} · ${row.entry?.account || 'summary'}`} disabled={!mayCreateEntry || Boolean(draftState.error)} onClick={() => { setSelectedDocumentId(row.entries[0].document.id); openEntryEditor(row.entries[0].document.id, 'copy', row.entry || row.entries[0]); }} className="flex h-6 w-6 items-center justify-center text-[#7288A3] hover:text-[#007EA7] disabled:opacity-40"><Copy size={15} /></button>
          <button type="button" title="View document" aria-label={`View ${row.entries[0].documentNumber} · ${row.entry?.account || 'summary'}`} onClick={() => setOpenDocument(row.entries[0])} className="flex h-6 w-6 items-center justify-center text-[#7288A3] hover:text-[#007EA7]"><Eye size={16} /></button>
          <RowDeleteButton deactivationIcon="trash" linked inactive={row.entries[0].inactive} variant="plain" className="!h-6 !w-6" label={`Delete ${row.entries[0].documentNumber}`} disabled={!mayCreateEntry || Boolean(draftState.error) || !(dataSource === 'test' || draftState.entries.some(entry => entry.id === row.entries[0].document.id))} onDelete={() => { const entry = draftState.entries.find(item => item.id === row.entries[0].document.id); setEntryError(''); setDeactivation({ id: row.entries[0].document.id, number: row.entries[0].documentNumber, revision: entry ? entry.revision || 0 : null }); }} />
        </div>}
      </td>
    </tr>;
  });

  if (section === 'revaluation') return <GlJournalRevaluationView key={`${company.id}:${dataSource}`} companyId={company.id} companyName={company.name} baseCurrency={company.base_currency || 'EUR'} rows={candidates} accounts={entryAccounts} savedEntries={draftState.entries} testData={dataSource === 'test'} mayCreate={mayCreateEntry && !draftState.error} onRefresh={() => setRefreshRevision(value => value + 1)} onSave={saveRevaluation} onOpenJournal={documentNumber => { setQuery(documentNumber); setFilterKeys([]); setFilterValues({}); onSectionChange('journal'); }} />;
  return (
    <div data-gl-journal-workspace className="flex h-screen min-w-0 flex-col gap-6 overflow-hidden bg-white py-14 font-montserrat" style={{ paddingLeft: 'clamp(24px, 5vw, 72px)', paddingRight: 'clamp(24px, 5vw, 72px)' }}>
      <PageHeader title="GL journal" actions={<PageActionButton icon={<Plus size={15} />} disabled={!mayCreateEntry || Boolean(draftState.error)} onClick={() => openEntryEditor('', 'new')}>New journal</PageActionButton>} />
      <CompanyBreadcrumb companyName={company.name} items={["GL journal"]} />

      <div className="flex shrink-0 flex-col gap-4">
        <div className="flex flex-wrap items-end gap-3 text-[12px] text-[#7288A3]">
          <div className="ml-auto flex min-h-[42px] flex-wrap items-center gap-2">
            <PageActionButton icon={<BookCheck size={15} />} onClick={() => { setClosingNotice(''); setClosingKind('classes56'); }}>Close classes 5 &amp; 6</PageActionButton>
            <PageActionButton icon={<Calculator size={15} />} onClick={() => { setClosingNotice(''); setClosingKind('vat'); }}>VAT closing</PageActionButton>
            <PageActionButton icon={<Mail size={15} />} onClick={() => { setClosingNotice(''); setVatEmailOpen(true); }}>Send VAT reconciliation</PageActionButton>
          </div>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex min-w-0 flex-1 flex-wrap items-center gap-1" data-native-system-filters="true">
          <OcrSearchField ariaLabel="Search GL journal" value={query} onChange={setQuery} />
          <SystemAddFilters
            columns={filterColumns}
            activeKeys={filterKeys}
            values={filterValues}
            onActiveKeysChange={setFilterKeys}
            onValuesChange={setFilterValues}
            persistenceKey={`finansu-harmonija:v12:gl-journal-filters:${company.id}`}
          />
        </div>
        <div data-table-workspace-tools className="ml-auto flex h-7 shrink-0 items-center gap-4">
          <ColumnSettingsButton onClick={() => setShowColumns(true)} />
          <button data-button-family="export" aria-label="EXPORT" title="EXPORT" onClick={exportJournal} className="text-[#7288A3]"><Download size={16} /></button>
          <button type="button" aria-label="Print GL journal" title="PRINT" disabled={!sortedRows.length} onClick={() => setPrintOpen(true)} className="text-[#7288A3] disabled:opacity-40"><Printer size={16} /></button>
          <ImportDataButton
            disabled={dataSource === 'test' || rows.length === 0}
            onClick={() => importMenuRecords(`company:${company.id}:gl-journal`, rows.map((row) => row.document.id))}
          />
          <RefreshAllButton onRefresh={() => setRefreshRevision((value) => value + 1)} />
        </div>
        </div>
      </div>

      {closingNotice && <div role="status" className="flex shrink-0 items-center gap-2 rounded-lg border border-[#D3E1EC] bg-[#F8FDFF] px-3 py-2 text-[12px] text-[#10233A]"><Check size={15} className="text-[#087A5B]" /><span>{closingNotice}</span><button type="button" aria-label="Dismiss closing period confirmation" onClick={() => setClosingNotice('')} className="ml-auto text-[#7288A3]"><X size={16} /></button></div>}
      {(entryError || draftState.error) && <p role="alert" className="text-[12px] text-[#C45100]">{entryError || draftState.error}</p>}

      {unbalancedCount > 0 && (
        <div className="flex items-start gap-3 rounded-lg border border-[#F3D19E] bg-[#FFF8EC] px-4 py-3 font-montserrat text-[12px] text-[#7A4B00]">
          <AlertTriangle size={17} className="mt-0.5 flex-shrink-0" />
          <span>
            {unbalancedCount} approved operation{unbalancedCount === 1 ? " is" : "s are"} excluded because debit and credit are not balanced.
          </span>
        </div>
      )}

      <div ref={tableScrollRef} className="min-h-0 flex-1 overflow-auto scrollbar-hide">
        <table aria-label="GL journal entries" className="gl-journal-table w-full table-fixed border-separate border-spacing-0" style={{ minWidth: visibleColumns.reduce((sum, column) => sum + column.width, 150) }}>
          <colgroup>{visibleColumns.map(column => <col key={column.key} style={{ width: column.width }} />)}<col /></colgroup>
          <thead className="bg-white"><tr className="h-10 text-[12px] font-medium text-[#10233A]">
            {visibleColumns.map((column) => {
              const key = column.key as JournalColumnKey;
              const realIndex = columns.findIndex((item) => item.key === column.key);
              const columnGroups = allGroups.filter(group => group.key === key);
              const allExpanded = columnGroups.length > 0 && columnGroups.every(isGroupExpanded);
              return (
                <th key={column.key} scope="col" className="relative border-b border-[#D3E1EC] bg-[#F8FDFF] py-2 pl-2 pr-5 text-left font-medium">
                  <div className={`flex min-w-0 items-center gap-1 ${['debit', 'credit', 'total'].includes(column.key) ? 'justify-end' : ''}`}>
                    {columnGroups.length > 0 && <button type="button" title={`${allExpanded ? 'Collapse' : 'Expand'} ${column.label} groups`} aria-label={`${allExpanded ? 'Collapse' : 'Expand'} ${column.label} groups`} onClick={() => toggleColumnGroups(key as JournalGroupKey, !allExpanded)} className="flex h-4 w-4 shrink-0 items-center justify-center text-[#7288A3] hover:text-[#007EA7]">{allExpanded ? <ChevronsDownUp size={12} /> : <ChevronsUpDown size={12} />}</button>}
                    <span className="min-w-0 truncate" title={column.label}>{column.label}</span>
                    <ColumnSortButton columnLabel={column.label} direction={directionFor(key)} onDirectionChange={(direction) => changeSort(key, direction)} />
                  </div>
                  <ResizeHandle onMouseDown={(event) => startResize(realIndex, event)} />
                </th>
              );
            })}
            <th aria-label="Row actions" className="border-b border-[#D3E1EC] bg-[#F8FDFF]" />
          </tr></thead>

          <tbody>
            {renderTableRows()}
            {dataSource === 'company' && loading && <tr><td colSpan={visibleColumns.length + 1} className="py-12 text-center text-[12px] text-[#7288A3]" role="status">Loading journal…</td></tr>}
            {!(dataSource === 'company' && loading) && sortedRows.length === 0 && (
              <tr><td colSpan={visibleColumns.length + 1}><div className="flex min-h-[260px] flex-col items-center justify-center gap-3 font-montserrat text-[#7288A3]">
                <FileText size={30} />
                <span className="text-[14px] font-semibold">No matching journal entries</span>
                <span className="max-w-[520px] text-center text-[12px] leading-5">Check the period and filters.</span>
              </div></td></tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="flex shrink-0 flex-wrap items-center gap-x-5 gap-y-1 border-t border-[#D3E1EC] pt-2 text-[11px] text-[#7288A3]" aria-label="Filtered journal totals">
        <span>{dataSource === 'test' ? 'Test records · ' : ''}{documentIds.length} documents · {filteredRows.length} GL lines</span>
        <span>Totals</span>
        {selectedDocumentId && candidates.some(row => row.document.id === selectedDocumentId) && <span className="text-[#007EA7]">Selected: {candidates.find(row => row.document.id === selectedDocumentId)?.documentNumber}</span>}
        {totals.map(total => <span key={total.currency} className="whitespace-nowrap tabular-nums"><strong className="font-medium text-[#10233A]">{total.currency}</strong> · Debit {number(total.debit)} · Credit {number(total.credit)}</span>)}
      </div>
      <HorizontalTableScrollbar scrollRef={tableScrollRef} />
      <TablePagination scrollRef={tableScrollRef} currentPage={fixedPage0} totalPages={Math.max(1, Math.ceil(documentIds.length / TABLE_BATCH_SIZE))} itemCount={documentIds.length} itemsPerPage={TABLE_BATCH_SIZE} onPageChange={setFixedPage0} />

      {showColumns && (
        <ColumnSettingsPanel columns={columns} defaultColumns={DEFAULT_COLUMNS} onSave={(next) => { setColumns(next); setShowColumns(false); }} onClose={() => setShowColumns(false)} />
      )}

      {openDocument && (
        <GlJournalDocumentView selected={openDocument} source={candidates} companyName={company.name} onSelect={setOpenDocument} onClose={() => setOpenDocument(null)} />
      )}
      {closingKind && <GlJournalClosingDialog key={`${company.id}:${closingKind}`} companyId={company.id} companyName={company.name} initialRecipient={company.email} kind={closingKind} initialPeriod={period} rows={candidates} accounts={entryAccounts} onClose={() => setClosingKind(null)} onSaved={saved => { setClosingNotice(`${JOURNAL_CLOSING_TITLES[closingKind]} · Period saved: ${saved.from} — ${saved.to}`); setClosingKind(null); }} />}
      {vatEmailOpen && <VatReconciliationCompanyDialog company={company} initialPeriod={period} loadCompanyData={loadVatCompanyData} onClose={() => setVatEmailOpen(false)} />}
      {entryEditor && <GlJournalEntryEditor key={`${entryEditor.mode}:${entryEditor.id}`} initialDraft={entryEditor.draft} sourceRow={entryEditor.sourceRow} mode={entryEditor.mode} companyName={company.name} createdBy={entryEditor.mode === 'edit' ? candidates.find(row => row.document.id === entryEditor.id)?.createdBy || '—' : getCurrentUserName()} accounts={entryAccounts} currencies={entryCurrencies} existingNumbers={candidates.filter(row => entryEditor.mode !== 'edit' || row.document.id !== entryEditor.id).map(row => row.documentNumber)} onSave={saveEntry} onClose={() => setEntryEditor(null)} />}
      {printOpen && <GlJournalPrintView companyName={company.name} rows={sortedRows} columns={visibleColumns} value={(row, key) => { const value = cellValue(row, key as JournalColumnKey); return typeof value === 'number' ? number(value) : String(value); }} period={period} account={accountFilter} onClose={() => setPrintOpen(false)} />}
      {deactivation && <GlJournalDialog title="Deactivate journal entry" subtitle={deactivation.number} onClose={() => setDeactivation(null)} footer={<><PageActionButton onClick={() => setDeactivation(null)}>Cancel</PageActionButton><PageActionButton icon={<Trash2 size={15} />} onClick={deactivateEntry}>Deactivate</PageActionButton></>}><p className="text-[13px] leading-6">This entry will remain visible, crossed out and marked Inactive. It will be excluded from active totals. Its document number, amounts, creator and history will be retained.</p>{entryError && <p role="alert" className="mt-3 text-[12px] text-[#C45100]">{entryError}</p>}</GlJournalDialog>}
    </div>
  );
}
