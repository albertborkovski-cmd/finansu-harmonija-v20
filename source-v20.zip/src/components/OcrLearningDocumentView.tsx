import { useEffect, useState } from 'react';
import { WorkspaceDocumentEditor } from './WorkspaceView';
import { LEARNING_FIELDS, type LearningEvidence } from '../lib/ocrLearning';
import { loadLearningStore } from '../lib/ocrLearningStore';
import { exampleLearningDocument, learningDocumentQueue } from '../lib/ocrLearningDocuments';
import { loadSavedReviewDocumentTask, reviewDocumentPosition } from '../lib/ocrReviewDocuments';
import { loadOcrDocumentSource } from '../lib/ocrDocumentSource';

export default function OcrLearningDocumentView({ evidence, onBack }: {
  evidence: LearningEvidence; onBack: () => void;
}) {
  const [store] = useState(loadLearningStore);
  const [savedTask] = useState(() => {
    if (evidence.sample) return exampleLearningDocument(evidence, store);
    return loadSavedReviewDocumentTask({ id: evidence.documentId, companyId: evidence.companyId }, localStorage);
  });
  const [file, setFile] = useState<{ position: number; total: number } | null>(() => {
    if (!evidence.sample) return null;
    const queue = learningDocumentQueue(evidence, store);
    return { position: Math.max(1, queue.findIndex(item => item.documentId === evidence.documentId) + 1), total: queue.length || 1 };
  });
  useEffect(() => {
    if (evidence.sample) return;
    let cancelled = false;
    void loadOcrDocumentSource().then(({ documents }) => {
      if (!cancelled) setFile(reviewDocumentPosition({ id: evidence.documentId, companyId: evidence.companyId }, documents));
    }).catch(() => { if (!cancelled) setFile({ position: 1, total: 1 }); });
    return () => { cancelled = true; };
  }, [evidence.companyId, evidence.documentId, evidence.sample]);
  if (!file) return <div role="status" className="px-6 py-8 font-montserrat text-[13px] text-[#7288A3] lg:px-10">Opening saved document…</div>;
  return <WorkspaceDocumentEditor
    documentId={evidence.sample ? undefined : evidence.documentId}
    documentName={evidence.documentName}
    companyId={evidence.companyId}
    savedTask={savedTask}
    readOnly
    viewNotice={`${LEARNING_FIELDS[evidence.field]}: ${evidence.value} · Confirmed by ${evidence.confirmedBy.name} · ${new Date(evidence.confirmedAt).toLocaleString('en-GB')}${evidence.sample ? ' · Example document' : ''}`}
    filePosition={file.position}
    fileTotal={file.total}
    onBack={onBack}
  />;
}
