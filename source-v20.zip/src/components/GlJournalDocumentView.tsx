import { useMemo } from 'react';
import { LockKeyhole } from 'lucide-react';
import { journalDate, journalDocumentDetails, journalEntrySide, type GlJournalRow } from '../lib/glJournal';
import SearchableSelect from './SearchableSelect';
import GlJournalDocumentLayout, { JournalCorrespondenceTable, JournalDocumentFields, JournalDocumentTotals, JournalEntryHeader, journalDocumentFieldClass } from './GlJournalDocumentLayout';

const formatAmount = (amount: number) => amount.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export default function GlJournalDocumentView({ selected, source, companyName, onSelect, onClose }: {
  selected: GlJournalRow; source: GlJournalRow[]; companyName: string;
  onSelect: (row: GlJournalRow) => void; onClose: () => void;
}) {
  const { entries, side, correspondingEntries, totals } = useMemo(() => journalDocumentDetails(selected, source), [selected, source]);
  const opposite = side === 'Debit' ? 'Credit' : side === 'Credit' ? 'Debit' : 'Corresponding entries';
  const currency = selected.document.currency || 'EUR';
  const selectedAmount = side === 'Debit' ? selected.debit : side === 'Credit' ? selected.credit : selected.total;
  const index = entries.findIndex(row => row.id === selected.id);

  return <GlJournalDocumentLayout title="View document" number={selected.documentNumber} companyName={companyName} fileUrl={selected.document.imageUrl} onClose={onClose}
    details={<>
      <JournalEntryHeader side={side} status={selected.postingStatus} index={index} count={entries.length} onPrevious={() => onSelect(entries[index - 1])} onNext={() => onSelect(entries[index + 1])} />
      <JournalDocumentFields values={{
        counterparty: selected.counterparty, counterpartyCode: selected.document.counterpartyCode, internalNumber: selected.internalNumber,
        number: selected.documentNumber, documentDate: journalDate(selected.document.documentDate || selected.operationDate), operationDate: journalDate(selected.operationDate), dueDate: selected.document.dueEndDate ? journalDate(selected.document.dueEndDate) : '',
        documentType: selected.documentType, operationType: side, currency, exchangeRate: currency === 'EUR' ? '1.000000' : '',
        amount: formatAmount(selectedAmount), amountEur: currency === 'EUR' ? formatAmount(selectedAmount) : '', costCenter: selected.costCenter,
        object: selected.object, department: selected.department, employee: selected.employee, vehicle: selected.vehicle,
        createdBy: selected.createdBy, status: selected.inactive ? 'Inactive' : 'Active', comment: selected.description || selected.document.note,
      }} controls={{ account: <SearchableSelect portalMenu className={journalDocumentFieldClass + ' pr-9'} ariaLabel="View GL entry" value={selected.id} options={entries.map(row => ({ value: row.id, label: `${row.account}${row.accountName ? ` · ${row.accountName}` : ''} · ${journalEntrySide(row)} · ${formatAmount(Math.max(row.debit, row.credit))} ${row.document.currency || 'EUR'}` }))} onChange={id => { const row = entries.find(entry => entry.id === id); if (row) onSelect(row); }} /> }} />
    </>}
    correspondence={<>
      <JournalCorrespondenceTable title={opposite} count={correspondingEntries.length}>
        {correspondingEntries.map(row => {
          const amount = side === 'Debit' ? row.credit : side === 'Credit' ? row.debit : row.total;
          return <tr key={row.id} className="align-top odd:bg-white even:bg-[#F8FDFF] hover:bg-[#E7F4F9]">
            <td className="border-b border-[#E5EDF9] px-3 py-3"><button type="button" onClick={() => onSelect(row)} title={`View ${row.account} · ${journalEntrySide(row)}`} className="text-[#007EA7] hover:underline">{row.account}</button><span className="mt-0.5 block text-[10px] text-[#7288A3]">{row.accountName || '—'}</span></td>
            <td className="whitespace-nowrap border-b border-[#E5EDF9] px-3 py-3 text-right tabular-nums">{formatAmount(amount)}<span className="mt-0.5 block text-[10px] text-[#7288A3]">{row.document.currency || 'EUR'}</span></td>
            <td className="border-b border-[#E5EDF9] px-3 py-3">{row.counterparty}</td>
            <td className="border-b border-[#E5EDF9] px-3 py-3 text-right tabular-nums">{(row.document.currency || 'EUR') === 'EUR' ? formatAmount(amount) : '—'}</td>
            <td className="border-b border-[#E5EDF9] px-3 py-3 text-[#7288A3]">—</td>
            <td className="border-b border-[#E5EDF9] px-3 py-3">{row.description || row.document.note || '—'}</td>
          </tr>;
        })}
      </JournalCorrespondenceTable>
      <JournalDocumentTotals totals={totals} />
      <div className="flex items-start gap-2 text-[11px] leading-5 text-[#7288A3]"><LockKeyhole size={14} className="mt-0.5 shrink-0" /><span>{selected.sample ? 'Test document · Read-only preview.' : 'Historical journal entries are read-only.'} All corresponding entries from this document are shown.</span></div>
    </>} />;
}
