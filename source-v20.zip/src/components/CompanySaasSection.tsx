import { useEffect, useId, useMemo, useState, type ReactNode } from 'react';
import { Building2, Layers3, RefreshCw, Save } from 'lucide-react';
import { recordAdministrativeAction, supabase, type Company } from '../lib/supabase';
import {
  companySaasUsage, parseCompanySaasPlan, SAAS_MODULES, SAAS_OVERAGE, SAAS_PERIODS, SAAS_PRICING, SAAS_PRODUCTS,
  validateCompanySaasPlan, type CompanySaasPlan, type SaasUsageDocument,
} from '../lib/companySaas';
import SearchableSelect from './SearchableSelect';
import MultiSelectField from './MultiSelectField';
import { PageActionButton } from './PageHeader';

const numberFormat = new Intl.NumberFormat('en-GB', { maximumFractionDigits: 1 });
const priceFormat = new Intl.NumberFormat('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 6 });
const fieldClass = 'h-[42px] w-full min-w-0 rounded-lg border border-[#D3E1EC] bg-white px-[14px] font-montserrat text-[14px] font-medium leading-5 text-[#10233A] outline-none focus:border-[#007EA7] focus:ring-1 focus:ring-[#007EA7]/20';

function PlanField({ label, children }: { label: string; children: ReactNode }) {
  return <div className="flex min-w-0 flex-col gap-2"><span className="font-montserrat text-[14px] font-semibold leading-5 text-[#10233A]">{label}</span>{children}</div>;
}

export default function CompanySaasSection({ company, onCompanyUpdated }: {
  company: Company;
  onCompanyUpdated?: (company: Company) => void;
}) {
  const headingId = useId();
  const [savedPlan, setSavedPlan] = useState(() => parseCompanySaasPlan(company.saas_settings));
  const [plan, setPlan] = useState(() => parseCompanySaasPlan(company.saas_settings));
  const [configured, setConfigured] = useState(Boolean(company.saas_settings));
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [saveError, setSaveError] = useState('');
  const [documents, setDocuments] = useState<SaasUsageDocument[]>([]);
  const [usageLoading, setUsageLoading] = useState(true);
  const [usageError, setUsageError] = useState('');
  const [refresh, setRefresh] = useState(0);
  const [asOf, setAsOf] = useState(() => new Date());

  useEffect(() => {
    let current = true;
    let request = 0;
    const load = async () => {
      const version = ++request;
      setUsageLoading(true);
      setUsageError('');
      try {
        const { data, error } = await supabase.from('documents').select('id, company_id, receive_date, created_at').eq('company_id', company.id);
        if (error) throw new Error(error.message);
        if (current && version === request) { setDocuments(data || []); setAsOf(new Date()); }
      } catch {
        if (current && version === request) setUsageError('Document usage could not be loaded. Please refresh.');
      } finally { if (current && version === request) setUsageLoading(false); }
    };
    const onDataChanged = (event: Event) => {
      if ((event as CustomEvent<{ table?: string }>).detail?.table === 'documents') void load();
    };
    const onFocus = () => { void load(); };
    void load();
    window.addEventListener('finansu-harmonija:data-changed', onDataChanged);
    window.addEventListener('focus', onFocus);
    return () => {
      current = false;
      window.removeEventListener('finansu-harmonija:data-changed', onDataChanged);
      window.removeEventListener('focus', onFocus);
    };
  }, [company.id, refresh]);

  const usage = useMemo(() => companySaasUsage(company.id, documents, plan, asOf), [company.id, documents, plan, asOf]);
  const changed = JSON.stringify(plan) !== JSON.stringify(savedPlan);
  const validationError = validateCompanySaasPlan(plan);
  const updatePlan = (patch: Partial<CompanySaasPlan>) => { setPlan(current => ({ ...current, ...patch })); setFeedback(''); setSaveError(''); };
  const save = async () => {
    if (saving || validationError) return;
    setSaving(true);
    setSaveError('');
    setFeedback('');
    try {
      const serialized = JSON.stringify(parseCompanySaasPlan(plan));
      const { data, error } = await supabase.from('companies').update({ saas_settings: serialized }).eq('id', company.id);
      if (error) throw new Error(error.message);
      const updated = data?.find(row => row.id === company.id);
      if (!updated) throw new Error('Company was not found. Reopen the company and try again.');
      const saved = parseCompanySaasPlan(serialized);
      setSavedPlan(saved);
      setPlan(saved);
      setConfigured(true);
      onCompanyUpdated?.(updated as unknown as Company);
      await recordAdministrativeAction(company.id, 'SaaS', 'Updated', 'Updated the company SaaS product, pricing, document limit and modules.');
      setFeedback('SaaS settings saved.');
    } catch (error) { setSaveError(error instanceof Error ? error.message : 'Unable to save SaaS settings.'); }
    finally { setSaving(false); }
  };
  const periodLabel = plan.periodas === 'month' ? 'Monthly' : 'Yearly';
  const priceLabel = plan.kainodara === 'docs' ? 'Price per document (EUR)' : plan.kainodara === 'users' ? 'Price per active user (EUR)' : 'Company fee per period (EUR)';
  const priceSummaryLabel = plan.kainodara === 'docs' ? 'Per document' : plan.kainodara === 'users' ? 'Per active user' : 'Per company / period';
  const usageAvailable = !usageLoading && !usageError;

  return (
    <section aria-labelledby={headingId} className="rounded-lg border border-[#D3E1EC] p-5 font-montserrat text-[#10233A]">
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <h3 id={headingId} className="flex items-center gap-2 text-[16px] font-semibold leading-6"><Layers3 size={18} className="text-[#007EA7]" />SaaS</h3>
      </div>

      <div className="grid min-w-0 grid-cols-1 items-start gap-6 xl:grid-cols-[minmax(0,1.25fr)_minmax(320px,1fr)]">
        <fieldset disabled={saving} className="grid min-w-0 grid-cols-1 gap-4 sm:grid-cols-2">
          <legend className="sr-only">SaaS plan settings</legend>
          <PlanField label="Product"><SearchableSelect ariaLabel="SaaS product" value={plan.produktas} options={SAAS_PRODUCTS} onChange={value => updatePlan({ produktas: value as CompanySaasPlan['produktas'] })} /></PlanField>
          <PlanField label="Pricing model"><SearchableSelect ariaLabel="SaaS pricing model" value={plan.kainodara} options={SAAS_PRICING} onChange={value => updatePlan({ kainodara: value as CompanySaasPlan['kainodara'] })} /></PlanField>
          <label className="flex min-w-0 flex-col gap-2 text-[14px] font-semibold leading-5">Document limit<input aria-label="SaaS document limit" inputMode="numeric" value={plan.kiekis} onChange={event => updatePlan({ kiekis: event.target.value.trim() })} className={fieldClass} /></label>
          <label className="flex min-w-0 flex-col gap-2 text-[14px] font-semibold leading-5">{priceLabel}<input aria-label="SaaS price (EUR)" inputMode="decimal" value={plan.kaina} onChange={event => updatePlan({ kaina: event.target.value.replace(',', '.').trim() })} className={fieldClass} /></label>
          <PlanField label="Period"><SearchableSelect ariaLabel="SaaS period" value={plan.periodas} options={SAAS_PERIODS} onChange={value => updatePlan({ periodas: value as CompanySaasPlan['periodas'] })} /></PlanField>
          <PlanField label="Overage policy"><SearchableSelect ariaLabel="SaaS overage policy" value={plan.virsijimas} options={SAAS_OVERAGE} onChange={value => updatePlan({ virsijimas: value as CompanySaasPlan['virsijimas'] })} /></PlanField>
          <div className="sm:col-span-2"><MultiSelectField label="Modules" options={SAAS_MODULES.map(module => module.label)} value={SAAS_MODULES.filter(module => plan.moduliai.includes(module.value)).map(module => module.label)} onChange={values => updatePlan({ moduliai: SAAS_MODULES.filter(module => values.includes(module.label)).map(module => module.value) })} /></div>
        </fieldset>

        <div className="min-w-0 rounded-lg border border-[#D3E1EC] bg-[#F8FAFC] p-5">
          <div className="mb-4 flex items-center gap-2 border-b border-[#E3ECF3] pb-4"><Building2 size={18} className="shrink-0 text-[#7288A3]" /><h4 className="truncate text-[14px] font-semibold" title={company.name}>{company.name}</h4></div>
          <dl className="grid grid-cols-2 gap-x-4 gap-y-4">
            <div className="min-w-0"><dt className="text-[12px] leading-[18px] text-[#7288A3]">Product</dt><dd className="mt-1 text-[16px] font-semibold leading-6">{SAAS_PRODUCTS.find(option => option.value === plan.produktas)?.label}</dd></div>
            <div className="min-w-0"><dt className="text-[12px] leading-[18px] text-[#7288A3]">Pricing model</dt><dd className="mt-1 text-[14px] font-semibold leading-6">{SAAS_PRICING.find(option => option.value === plan.kainodara)?.label}</dd></div>
            <div className="min-w-0"><dt className="text-[12px] leading-[18px] text-[#7288A3]">{periodLabel} limit</dt><dd className="mt-1 text-[18px] font-semibold leading-6">{usage.remaining === null ? '—' : numberFormat.format(Number(plan.kiekis))}<span className="ml-1 text-[12px] font-normal text-[#7288A3]">documents</span></dd></div>
            <div className="min-w-0"><dt className="text-[12px] leading-[18px] text-[#7288A3]">{priceSummaryLabel}</dt><dd className="mt-1 text-[16px] font-semibold leading-6">{plan.kaina !== '' && Number.isFinite(Number(plan.kaina)) && Number(plan.kaina) >= 0 ? `${priceFormat.format(Number(plan.kaina))} EUR` : '—'}</dd></div>
          </dl>
          <div className="mt-5 border-t border-[#E3ECF3] pt-4" aria-busy={usageLoading}>
            <div className="mb-1 flex items-center justify-between gap-3"><h4 className="text-[13px] font-semibold">Document usage</h4><PageActionButton ariaLabel="Refresh SaaS usage" disabled={usageLoading} icon={<RefreshCw size={16} className={`shrink-0 ${usageLoading ? 'animate-spin' : ''}`} />} onClick={() => setRefresh(current => current + 1)}>Refresh</PageActionButton></div>
            <p className="text-[12px] leading-[18px] text-[#7288A3]">{usage.from} – {usage.to}</p>
            <div role="progressbar" aria-label="SaaS document usage" aria-valuemin={0} aria-valuemax={100} aria-valuenow={usageAvailable && usage.percentage !== null ? usage.progress : undefined} aria-valuetext={usageAvailable ? `${usage.used} documents received, ${usage.percentage ?? 0}% of the limit` : 'Usage unavailable'} className="mt-4 h-2 overflow-hidden rounded-full bg-[#E3ECF3]">
              <div className={`h-full rounded-full ${usage.exceeded > 0 ? 'bg-[#D08A1D]' : 'bg-[#007EA7]'}`} style={{ width: `${usageAvailable ? usage.progress : 0}%` }} />
            </div>
            <div className="mt-2 flex items-center justify-between gap-3 text-[12px] leading-[18px]"><span className="text-[#7288A3]">{usageAvailable ? `${numberFormat.format(usage.used)} used` : usageLoading ? 'Loading usage…' : 'Usage unavailable'}</span><span className="font-semibold">{usageAvailable && usage.percentage !== null ? `${numberFormat.format(usage.percentage)}%` : '—'}</span></div>
            <div className="mt-4 grid grid-cols-2 gap-4 border-t border-[#E3ECF3] pt-3 text-[12px]"><div className="text-[#7288A3]">Remaining<strong className="mt-1 block text-[16px] font-semibold text-[#10233A]">{usageAvailable && usage.remaining !== null ? numberFormat.format(usage.remaining) : '—'}</strong></div><div className="text-[#7288A3]">Over the limit<strong className={`mt-1 block text-[16px] font-semibold ${usage.exceeded > 0 ? 'text-[#9A6700]' : 'text-[#10233A]'}`}>{usageAvailable ? numberFormat.format(usage.exceeded) : '—'}</strong></div></div>
            <p className="mt-3 text-[11px] leading-4 text-[#7288A3]">Based on this company’s documents received during the current period.</p>
            {usageError && <p role="alert" className="mt-2 text-[12px] text-[#D92D20]">{usageError}</p>}
          </div>
        </div>
      </div>
      <div className="mt-5 flex flex-wrap items-center justify-end gap-3 border-t border-[#E5EDF4] pt-4">
        {(saveError || validationError) && <p role="alert" className="mr-auto text-[12px] text-[#D92D20]">{saveError || validationError}</p>}
        {feedback && <p role="status" className="mr-auto text-[12px] text-[#087A55]">{feedback}</p>}
        <PageActionButton disabled={!changed || saving} onClick={() => { setPlan(parseCompanySaasPlan(savedPlan)); setFeedback(''); setSaveError(''); }}>Reset changes</PageActionButton>
        <PageActionButton disabled={saving || Boolean(validationError) || (configured && !changed)} icon={<Save size={14} />} onClick={save}>{saving ? 'Saving…' : 'Save SaaS settings'}</PageActionButton>
      </div>
    </section>
  );
}
