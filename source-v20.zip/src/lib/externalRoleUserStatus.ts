import { isInactiveRecord } from './recordLifecycle';

export type ExternalDirectoryRow = { id: string; [key: string]: string };
export const EXTERNAL_USERS_STORAGE_KEY = 'finansu-harmonija:v7:settings:external:users';
// Retain the storage key so accounts disabled by the former Roles action can be restored.
const previousStatusKey = 'statusBeforeRoleDeactivation';
const normalize = (value: string) => value.trim().toLowerCase();

/** Resolve current memberships by explicit role IDs, counting each user once. */
export function usersAssignedToRoles(
  roles: ExternalDirectoryRow[], users: ExternalDirectoryRow[], selectedRoleIds: ReadonlySet<string>,
): ExternalDirectoryRow[] {
  const names = new Set(roles.filter(role => selectedRoleIds.has(role.id))
    .map(role => normalize(role.name || '')).filter(Boolean));
  return users.filter(user => (user.roles || '').split(',').some(role => names.has(normalize(role))));
}

export function assignedUsersStatusAction(users: ExternalDirectoryRow[]): 'activate' | 'deactivate' | null {
  if (!users.length) return null;
  return users.every(isInactiveRecord) ? 'activate' : 'deactivate';
}

/** Only the supplied external directory changes; permissions and memberships are retained. */
export function toggleExternalUsers(
  users: ExternalDirectoryRow[], selectedUserIds: ReadonlySet<string>,
  actor: string, updatedAt: string,
) {
  const selected = users.filter(user => selectedUserIds.has(user.id));
  const action = assignedUsersStatusAction(selected);
  const ids = new Set(selected.map(user => user.id));
  const changedIds: string[] = [];
  const nextUsers = users.map(user => {
    if (!action || !ids.has(user.id) || (action === 'deactivate' && isInactiveRecord(user))) return user;
    changedIds.push(user.id);
    const next: ExternalDirectoryRow = { ...user, updatedBy: actor, lastUpdate: updatedAt };
    if (action === 'deactivate') {
      next[previousStatusKey] = user.status || 'Unactivated';
      next.status = 'Inactive';
      next.inactive = 'true';
      next.active = 'false';
      if ('enabled' in user) next.enabled = 'false';
    } else {
      // Re-enabling is not account activation and must not remove a separate block.
      const previous = normalize(user[previousStatusKey] || 'Active');
      next.status = ['active', 'enabled'].includes(previous) ? 'Active'
        : ['blocked', 'disabled'].includes(previous) ? 'Blocked' : 'Unactivated';
      next.inactive = 'false';
      next.active = 'true';
      if ('enabled' in user) next.enabled = 'true';
      delete next[previousStatusKey];
    }
    return next;
  });
  return { users: nextUsers, action, changedIds, selectedCount: selected.length };
}

/** Existing sessions must observe external-account deactivation, not only the next login. */
export function isExternalUserInactive(email: string, storage: Pick<Storage, 'getItem'>): boolean {
  try {
    const users: ExternalDirectoryRow[] = JSON.parse(storage.getItem(EXTERNAL_USERS_STORAGE_KEY) || '[]');
    return Array.isArray(users) && users.some(user => normalize(user.email || '') === normalize(email) && isInactiveRecord(user));
  } catch { return false; }
}
