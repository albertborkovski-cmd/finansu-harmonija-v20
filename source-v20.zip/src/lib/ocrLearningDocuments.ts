import type { WorkspaceTask } from '../components/WorkspaceView';
import type { LearningEvidence, LearningStore } from './ocrLearning';

export const OCR_DOCUMENT_TASK_KEYS = [
  'finansu-harmonija:v7:ml-document-tasks',
  'finansu-harmonija:v12:workspace:review-document-tasks',
  'finansu-harmonija:v18:ocr:team-lead-review',
] as const;

export function findLearningDocumentTask(item: LearningEvidence, collections: Record<string, WorkspaceTask>[]): WorkspaceTask | undefined {
  // Names alone are not unique across companies or document sets.
  return collections.flatMap(collection => Object.values(collection)).find(task =>
    task && task.accounting?.documentId === item.documentId && task.accounting.companyId === item.companyId);
}

export function learningDocumentQueue(item: LearningEvidence, store: LearningStore): LearningEvidence[] {
  const documents = new Map<string, LearningEvidence>();
  store.evidence.filter(source => source.companyId === item.companyId && source.supplierKey === item.supplierKey
    && source.field === item.field && source.vatRate === item.vatRate && Boolean(source.sample) === Boolean(item.sample))
    .sort((a, b) => b.confirmedAt.localeCompare(a.confirmedAt))
    .forEach(source => { if (!documents.has(source.documentId)) documents.set(source.documentId, source); });
  return [...documents.values()];
}

/** Examples contain teaching evidence, not an uploaded original invoice. */
export function exampleLearningDocument(item: LearningEvidence, store: LearningStore): WorkspaceTask {
  const values = store.evidence.filter(source => source.sample && source.active && source.companyId === item.companyId
    && source.documentId === item.documentId).sort((a, b) => b.confirmedAt.localeCompare(a.confirmedAt));
  return {
    id: `document-set-${item.documentId}`, name: item.documentName, priority: 0, description: 'Example teaching document',
    status: 'Completed', createdBy: item.confirmedBy.name, creationDate: item.confirmedAt,
    documentType: 'Invoice', sourceRunId: 'LEARNING-EXAMPLE', trainingStatus: 'Confirmed', trainingConfirmedAt: item.confirmedAt,
    fields: { invoiceNumber: item.documentName.replace(/\.pdf$/i, ''), invoiceDate: '', dueDate: '', companyName: item.supplierName,
      streetAddress: '', city: '', zipCode: '', phoneNumber: '', email: '', taxRate: item.vatRate,
      discountRate: '', totalDiscount: '', totalAmount: '' },
    products: [], comments: [],
    accounting: { companyId: item.companyId, companyName: item.companyName, supplierKey: item.supplierKey, supplierName: item.supplierName,
      vatRate: item.vatRate, documentId: item.documentId, documentName: item.documentName,
      expenseAccount: values.find(source => source.field === 'expense_account')?.value ?? '',
      vatClassifier: values.find(source => source.field === 'vat_classifier')?.value ?? '' },
  };
}
