/** Company-scoped warehouse domain. Money is rounded at line boundaries; stock uses six decimals. */
export const WAREHOUSE_SECTIONS = [
  { id: 'sales', label: 'Sales' }, { id: 'prices', label: 'Customer prices' },
  { id: 'recurring', label: 'Recurring invoices' }, { id: 'purchases', label: 'Purchases' },
  { id: 'returns', label: 'Sales returns' }, { id: 'stock', label: 'Stock & services' },
  { id: 'movements', label: 'Item movement' }, { id: 'consignment', label: 'Consignment' },
  { id: 'inventory', label: 'Stocktaking' }, { id: 'revaluation', label: 'Price revaluation' },
  { id: 'transfers', label: 'Internal transfers' }, { id: 'orders', label: 'E-commerce orders' },
  { id: 'cash', label: 'Cash sales' },
] as const;
// Sales and purchases still feed stock history, but are not Warehouse navigation entries.
export const WAREHOUSE_MENU_SECTIONS = WAREHOUSE_SECTIONS.filter(section => section.id !== 'sales' && section.id !== 'purchases');
export type WarehouseSection = typeof WAREHOUSE_SECTIONS[number]['id'];
export type WarehouseKind = 'Purchase' | 'Sale' | 'Sales return' | 'Transfer' | 'Consignment' | 'Consignment return' | 'Stocktake' | 'Write-off' | 'Order' | 'Cash sale';
export type WarehouseStatus = 'Draft' | 'Pending approval' | 'Posted' | 'Converted' | 'Inactive';
export type StockItem = { id: string; companyId: string; code: string; name: string; barcode: string; group: string; unit: string; type: 'Product' | 'Service'; salePrice: number; vatRate: number; minimumStock: number; stockAccount: string; salesAccount: string; costAccount: string; inactive: boolean };
export type StockLocation = { id: string; companyId: string; code: string; name: string; address: string; inactive: boolean };
export type WarehouseLine = { id: string; itemId: string; quantity: number; unitPrice: number; vatRate: number; discount: number };
export type WarehouseDocument = { id: string; companyId: string; kind: WarehouseKind; number: string; date: string; dueDate: string; warehouseId: string; destinationId: string; counterparty: string; referenceId: string; sourceId: string; currency: 'EUR'; status: WarehouseStatus; lines: WarehouseLine[]; notes: string; createdAt: string; createdBy: string; updatedAt: string; postedAt?: string; channel: string; cashPaid: number; cardPaid: number; inactive: boolean };
export type CustomerPrice = { id: string; companyId: string; counterparty: string; itemId: string; unitPrice: number; discount: number; validFrom: string; validTo: string; inactive: boolean };
export type RecurringContract = { id: string; companyId: string; number: string; counterparty: string; warehouseId: string; itemId: string; quantity: number; unitPrice: number; startDate: string; endDate: string; nextDate: string; frequency: 'Monthly' | 'Quarterly' | 'Yearly'; inactive: boolean };
export type WarehouseAudit = { id: string; date: string; actor: string; action: string; recordId: string; details: string };
export type PriceRevaluation = { id: string; date: string; itemId: string; oldPrice: number; newPrice: number; method: string; createdBy: string };
export type WarehouseStore = { version: 1; companyId: string; items: StockItem[]; locations: StockLocation[]; documents: WarehouseDocument[]; prices: CustomerPrice[]; contracts: RecurringContract[]; revaluations: PriceRevaluation[]; audit: WarehouseAudit[] };
export type StockMovement = { id: string; documentId: string; number: string; date: string; kind: WarehouseKind; itemId: string; warehouseId: string; counterparty: string; quantityIn: number; quantityOut: number; unitCost: number; value: number; balance: number; balanceValue: number; createdBy: string };
export type StockBalance = { itemId: string; warehouseId: string; quantity: number; value: number; unitCost: number };
const qty = (value: number) => Math.round((value + Number.EPSILON) * 1e6) / 1e6;
export const money = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;
function fail(message: string): never { throw new Error(message); }
const validDate = (value: string) => /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value;
export const newWarehouseId = () => crypto.randomUUID();
export const stockKey = (itemId: string, warehouseId: string) => `${warehouseId}:${itemId}`;
export function emptyWarehouse(companyId: string): WarehouseStore {
  return { version: 1, companyId, items: [], locations: [], documents: [], prices: [], contracts: [], revaluations: [], audit: [] };
}
export function lineTotals(line: WarehouseLine) {
  const net = money(line.quantity * line.unitPrice * (1 - line.discount / 100));
  const vat = money(net * line.vatRate / 100);
  return { net, vat, total: money(net + vat) };
}
export function documentTotals(document: Pick<WarehouseDocument, 'lines'>) {
  return document.lines.reduce((total, line) => { const next = lineTotals(line); return { net: money(total.net + next.net), vat: money(total.vat + next.vat), total: money(total.total + next.total) }; }, { net: 0, vat: 0, total: 0 });
}
function log(store: WarehouseStore, actor: string, action: string, recordId: string, details = ''): WarehouseStore {
  return { ...store, audit: [...store.audit, { id: newWarehouseId(), date: new Date().toISOString(), actor, action, recordId, details }] };
}
export function nextWarehouseNumber(store: WarehouseStore, kind: WarehouseKind, date: string) {
  const prefix = ({ Purchase: 'PUR', Sale: 'SAL', 'Sales return': 'RET', Transfer: 'TRF', Consignment: 'CON', 'Consignment return': 'CNR', Stocktake: 'CNT', 'Write-off': 'WOF', Order: 'ORD', 'Cash sale': 'POS' } as const)[kind];
  let number = 1;
  const root = `${prefix}-${date.slice(0, 4)}-`;
  while (store.documents.some(row => row.number === `${root}${String(number).padStart(4, '0')}`)) number++;
  return `${root}${String(number).padStart(4, '0')}`;
}
export function blankWarehouseDocument(store: WarehouseStore, kind: WarehouseKind, actor: string, date = new Date().toISOString().slice(0, 10)): WarehouseDocument {
  const now = new Date().toISOString();
  return { id: newWarehouseId(), companyId: store.companyId, kind, number: nextWarehouseNumber(store, kind, date), date, dueDate: '', warehouseId: store.locations.find(row => !row.inactive)?.id ?? '', destinationId: '', counterparty: '', referenceId: '', sourceId: '', currency: 'EUR', status: 'Draft', lines: [], notes: '', createdAt: now, createdBy: actor, updatedAt: now, channel: kind === 'Order' ? 'Manual' : '', cashPaid: 0, cardPaid: 0, inactive: false };
}
function assertScope(store: WarehouseStore, companyId: string) {
  if (!companyId || store.companyId !== companyId) fail('This record belongs to another company.');
}
export function validateWarehouseDocument(store: WarehouseStore, document: WarehouseDocument) {
  assertScope(store, document.companyId);
  if (!document.number.trim()) fail('Document number is required.');
  if (store.documents.some(row => row.id !== document.id && row.number.toLowerCase() === document.number.trim().toLowerCase())) fail('Document number already exists.');
  if (!validDate(document.date)) fail('Select a valid document date.');
  if (document.dueDate && (!validDate(document.dueDate) || document.dueDate < document.date)) fail('Due date must be on or after the document date.');
  if (!store.locations.some(row => row.id === document.warehouseId && !row.inactive)) fail('Select an active warehouse.');
  if (document.kind === 'Transfer' && (document.destinationId === document.warehouseId || !store.locations.some(row => row.id === document.destinationId && !row.inactive))) fail('Select a different active destination warehouse.');
  if (['Purchase', 'Sale', 'Sales return', 'Consignment', 'Consignment return', 'Order'].includes(document.kind) && !document.counterparty.trim()) fail('Counterparty is required.');
  if (!document.lines.length) fail('Add at least one item.');
  if (new Set(document.lines.map(line => line.itemId)).size !== document.lines.length) fail('An item can appear only once. Adjust its quantity instead.');
  for (const line of document.lines) {
    const item = store.items.find(row => row.id === line.itemId && !row.inactive);
    if (!item) fail('Select an active item for every line.');
    if (!Number.isFinite(line.quantity) || line.quantity < 0 || (document.kind !== 'Stocktake' && line.quantity === 0)) fail('Quantities must be positive (a stock count may be zero).');
    if (![line.unitPrice, line.vatRate, line.discount].every(Number.isFinite) || line.unitPrice < 0 || line.vatRate < 0 || line.vatRate > 100 || line.discount < 0 || line.discount > 100) fail('Enter valid prices, VAT rates and discounts.');
    if (['Stocktake', 'Transfer', 'Write-off', 'Consignment', 'Consignment return'].includes(document.kind) && item.type === 'Service') fail('Services cannot be included in stock operations.');
  }
  if (document.currency !== 'EUR') fail('Warehouse amounts use the company base currency EUR.');
  if (document.kind === 'Cash sale' && (![document.cashPaid, document.cardPaid].every(value => Number.isFinite(value) && value >= 0) || Math.abs(money(document.cashPaid + document.cardPaid) - documentTotals(document).total) > 0.001)) fail('Cash and card payments must equal the document total.');
  if (document.kind === 'Sales return') {
    const sale = store.documents.find(row => row.id === document.referenceId && ['Sale', 'Cash sale'].includes(row.kind) && row.status === 'Posted' && !row.inactive);
    if (!sale) fail('Select the original posted sale.');
    if (sale.counterparty !== document.counterparty || sale.warehouseId !== document.warehouseId || sale.date > document.date) fail('Return must match the original sale counterparty, warehouse and date.');
    for (const line of document.lines) {
      const sold = sale.lines.find(row => row.itemId === line.itemId);
      const returned = store.documents.filter(row => row.id !== document.id && row.kind === 'Sales return' && row.referenceId === sale.id && row.status === 'Posted' && !row.inactive).flatMap(row => row.lines).filter(row => row.itemId === line.itemId).reduce((sum, row) => sum + row.quantity, 0);
      if (!sold || qty(line.quantity + returned) > sold.quantity) fail('Return quantity exceeds the quantity still available to return.');
      if (line.unitPrice !== sold.unitPrice || line.discount !== sold.discount || line.vatRate !== sold.vatRate) fail('Return prices and VAT must match the original sale.');
    }
  }
}

/** Replays postings in date order. Drafts never change stock. Moving weighted average is used. */
export function warehouseLedger(store: WarehouseStore, through = '9999-12-31') {
  const balances = new Map<string, StockBalance>();
  const consigned = new Map<string, StockBalance & { counterparty: string }>();
  const movements: StockMovement[] = [];
  // Stable insertion order breaks equal timestamp ties; random IDs must never reorder postings.
  const posted = store.documents.filter(row => row.status === 'Posted' && !row.inactive && row.date <= through).sort((a, b) => a.date.localeCompare(b.date) || (a.postedAt ?? a.createdAt).localeCompare(b.postedAt ?? b.createdAt));
  const adjust = (document: WarehouseDocument, line: WarehouseLine, location: string, change: number, cost: number, suffix: string) => {
    const key = stockKey(line.itemId, location);
    const previous = balances.get(key) ?? { itemId: line.itemId, warehouseId: location, quantity: 0, value: 0, unitCost: 0 };
    const quantity = qty(previous.quantity + change);
    if (quantity < -0.000001) fail(`Insufficient stock for ${store.items.find(row => row.id === line.itemId)?.name ?? line.itemId} in ${document.number}.`);
    const value = quantity <= 0 ? 0 : qty(previous.value + change * cost);
    const next = { ...previous, quantity, value, unitCost: quantity > 0 ? value / quantity : 0 };
    balances.set(key, next);
    movements.push({ id: `${document.id}:${line.id}:${suffix}`, documentId: document.id, number: document.number, date: document.date, kind: document.kind, itemId: line.itemId, warehouseId: location, counterparty: document.counterparty, quantityIn: change > 0 ? change : 0, quantityOut: change < 0 ? -change : 0, unitCost: cost, value: qty(change * cost), balance: quantity, balanceValue: value, createdBy: document.createdBy });
  };
  for (const document of posted) {
    for (const line of document.lines) {
      const item = store.items.find(row => row.id === line.itemId);
      if (!item) fail(`An item referenced by ${document.number} is missing.`);
      if (item.type === 'Service' || document.kind === 'Order') continue;
      const current = balances.get(stockKey(item.id, document.warehouseId)) ?? { quantity: 0, value: 0, unitCost: 0 };
      const cost = current.unitCost;
      if (document.kind === 'Purchase') adjust(document, line, document.warehouseId, line.quantity, line.quantity ? lineTotals(line).net / line.quantity : 0, 'in');
      else if (document.kind === 'Stocktake') adjust(document, line, document.warehouseId, qty(line.quantity - current.quantity), current.quantity ? cost : line.unitPrice, 'count');
      else if (document.kind === 'Sales return') {
        const original = movements.find(row => row.documentId === document.referenceId && row.itemId === item.id && row.quantityOut > 0);
        if (!original) fail(`Original stock movement is missing for return ${document.number}.`);
        adjust(document, line, document.warehouseId, line.quantity, original.unitCost, 'return');
      } else if (document.kind === 'Consignment return') {
        const key = `${document.counterparty}:${stockKey(item.id, document.warehouseId)}`;
        const previous = consigned.get(key);
        if (!previous || qty(previous.quantity - line.quantity) < 0) fail('Consignment return exceeds the counterparty balance.');
        adjust(document, line, document.warehouseId, line.quantity, previous.unitCost, 'consignment-return');
        const quantity = qty(previous.quantity - line.quantity);
        consigned.set(key, { ...previous, quantity, value: qty(quantity * previous.unitCost) });
      } else {
        adjust(document, line, document.warehouseId, -line.quantity, cost, 'out');
        if (document.kind === 'Transfer') adjust(document, line, document.destinationId, line.quantity, cost, 'in');
        if (document.kind === 'Consignment') {
          const key = `${document.counterparty}:${stockKey(item.id, document.warehouseId)}`;
          const previous = consigned.get(key) ?? { itemId: item.id, warehouseId: document.warehouseId, counterparty: document.counterparty, quantity: 0, value: 0, unitCost: 0 };
          const quantity = qty(previous.quantity + line.quantity), value = qty(previous.value + line.quantity * cost);
          consigned.set(key, { ...previous, quantity, value, unitCost: value / quantity });
        }
      }
    }
  }
  return { balances: [...balances.values()], consigned: [...consigned.values()].filter(row => row.quantity > 0), movements };
}
export function saveWarehouseDocument(store: WarehouseStore, document: WarehouseDocument, actor: string): WarehouseStore {
  const previous = store.documents.find(row => row.id === document.id);
  if (previous && previous.status !== 'Draft') fail('Only draft documents can be edited. Copy the document to create a new draft.');
  validateWarehouseDocument(store, document);
  const saved = { ...document, number: document.number.trim(), status: 'Draft' as const, inactive: false, updatedAt: new Date().toISOString(), createdBy: previous?.createdBy ?? actor, createdAt: previous?.createdAt ?? document.createdAt };
  return log({ ...store, documents: previous ? store.documents.map(row => row.id === saved.id ? saved : row) : [...store.documents, saved] }, actor, previous ? 'Document updated' : 'Document created', saved.id, saved.number);
}
export function postWarehouseDocument(store: WarehouseStore, id: string, actor: string): WarehouseStore {
  const document = store.documents.find(row => row.id === id) ?? fail('Document not found.');
  if (document.status !== 'Draft' && document.status !== 'Pending approval') fail('This document cannot be posted again.');
  if (document.kind === 'Order') fail('Convert the order to a sale first.');
  if (document.kind === 'Transfer' && document.status !== 'Pending approval') fail('Submit this transfer for approval first.');
  validateWarehouseDocument(store, document);
  const next = { ...store, documents: store.documents.map(row => row.id === id ? { ...row, status: 'Posted' as const, postedAt: new Date().toISOString() } : row) };
  warehouseLedger(next);
  return log(next, actor, 'Document posted', id, document.number);
}
export function submitWarehouseTransfer(store: WarehouseStore, id: string, actor: string) {
  const document = store.documents.find(row => row.id === id) ?? fail('Document not found.');
  if (document.kind !== 'Transfer' || document.status !== 'Draft') fail('Only a draft transfer can be submitted.');
  validateWarehouseDocument(store, document);
  return log({ ...store, documents: store.documents.map(row => row.id === id ? { ...row, status: 'Pending approval' as const } : row) }, actor, 'Transfer submitted', id);
}
export function warehouseDocumentLinked(store: WarehouseStore, id: string) {
  const row = store.documents.find(document => document.id === id);
  return Boolean(row && (row.status !== 'Draft' || store.documents.some(document => document.referenceId === id || document.sourceId === id)));
}
export function removeWarehouseDocument(store: WarehouseStore, id: string, actor: string, externallyLinked = false): WarehouseStore {
  const document = store.documents.find(row => row.id === id) ?? fail('Document not found.');
  if (document.inactive) fail('This document is already inactive.');
  if (store.documents.some(row => !row.inactive && (row.referenceId === id || row.sourceId === id))) fail('Deactivate the linked return or generated document first.');
  const linked = externallyLinked || warehouseDocumentLinked(store, id);
  const next = { ...store, documents: linked ? store.documents.map(row => row.id === id ? { ...row, inactive: true, status: 'Inactive' as const } : row) : store.documents.filter(row => row.id !== id) };
  warehouseLedger(next); // Refuse a reversal that would leave later stock movements invalid.
  return log(next, actor, linked ? 'Document deactivated' : 'Unused draft deleted', id, document.number);
}
export function copyWarehouseDocument(store: WarehouseStore, source: WarehouseDocument, actor: string, date = new Date().toISOString().slice(0, 10)): WarehouseDocument {
  const blank = blankWarehouseDocument(store, source.kind, actor, date);
  return { ...blank, warehouseId: source.warehouseId, destinationId: source.destinationId, counterparty: source.counterparty, referenceId: source.referenceId, notes: source.notes, channel: source.channel, cashPaid: source.cashPaid, cardPaid: source.cardPaid, lines: source.lines.map(line => ({ ...line, id: newWarehouseId() })) };
}
export function createReturnDraft(store: WarehouseStore, sale: WarehouseDocument, actor: string) {
  if (!['Sale', 'Cash sale'].includes(sale.kind) || sale.status !== 'Posted' || sale.inactive) fail('Select a posted sale.');
  const previous = store.documents.filter(row => row.kind === 'Sales return' && row.referenceId === sale.id && row.status === 'Posted' && !row.inactive).flatMap(row => row.lines);
  return { ...blankWarehouseDocument(store, 'Sales return', actor), warehouseId: sale.warehouseId, counterparty: sale.counterparty, referenceId: sale.id, lines: sale.lines.map(line => ({ ...line, id: newWarehouseId(), quantity: qty(line.quantity - previous.filter(row => row.itemId === line.itemId).reduce((sum, row) => sum + row.quantity, 0)) })).filter(line => line.quantity > 0) };
}
export function effectivePrice(store: WarehouseStore, itemId: string, counterparty: string, date: string) {
  const price = store.prices.filter(row => !row.inactive && row.itemId === itemId && row.counterparty === counterparty && row.validFrom <= date && (!row.validTo || row.validTo >= date)).sort((a, b) => b.validFrom.localeCompare(a.validFrom))[0];
  return { unitPrice: price?.unitPrice ?? store.items.find(item => item.id === itemId)?.salePrice ?? 0, discount: price?.discount ?? 0 };
}
export function convertWarehouseOrder(store: WarehouseStore, id: string, actor: string) {
  const order = store.documents.find(row => row.id === id && row.kind === 'Order' && !row.inactive) ?? fail('Order not found.');
  if (order.status !== 'Draft' || store.documents.some(row => row.sourceId === id)) fail('This order has already been converted.');
  const draft = { ...copyWarehouseDocument(store, order, actor), kind: 'Sale' as const, number: nextWarehouseNumber(store, 'Sale', new Date().toISOString().slice(0, 10)), sourceId: order.id };
  const next = saveWarehouseDocument(store, draft, actor);
  return { ...next, documents: next.documents.map(row => row.id === order.id ? { ...row, status: 'Converted' as const } : row) };
}
function advanceDate(date: string, months: number, anchorDay: number) {
  const source = new Date(`${date}T12:00:00Z`);
  const end = new Date(Date.UTC(source.getUTCFullYear(), source.getUTCMonth() + months + 1, 0));
  return new Date(Date.UTC(end.getUTCFullYear(), end.getUTCMonth(), Math.min(anchorDay, end.getUTCDate()), 12)).toISOString().slice(0, 10);
}
export function generateRecurringInvoices(store: WarehouseStore, ids: string[], through: string, actor: string) {
  if (!validDate(through)) fail('Select a valid invoice date.');
  let next = store, generated = 0;
  for (const id of ids) {
    let contract = next.contracts.find(row => row.id === id && !row.inactive) ?? fail('Contract not found or inactive.');
    if (!validDate(contract.nextDate) || !validDate(contract.startDate)) fail('Contract dates are invalid.');
    while (contract.nextDate <= through && (!contract.endDate || contract.nextDate <= contract.endDate)) {
      if (generated >= 240) fail('Generate a shorter period (maximum 240 invoices at once).');
      const sourceId = `${contract.id}:${contract.nextDate}`;
      if (!next.documents.some(row => row.sourceId === sourceId)) {
        const item = next.items.find(row => row.id === contract.itemId && !row.inactive) ?? fail('Contract item is missing or inactive.');
        const document = { ...blankWarehouseDocument(next, 'Sale', actor, contract.nextDate), warehouseId: contract.warehouseId, counterparty: contract.counterparty, sourceId, notes: `Contract ${contract.number}`, lines: [{ id: newWarehouseId(), itemId: item.id, quantity: contract.quantity, unitPrice: contract.unitPrice, vatRate: item.vatRate, discount: 0 }] };
        next = saveWarehouseDocument(next, document, actor); generated++;
      }
      contract = { ...contract, nextDate: advanceDate(contract.nextDate, contract.frequency === 'Yearly' ? 12 : contract.frequency === 'Quarterly' ? 3 : 1, Number(contract.startDate.slice(-2))) };
    }
    next = { ...next, contracts: next.contracts.map(row => row.id === id ? contract : row) };
  }
  if (!generated) fail('No selected contracts are due for this period.');
  return log(next, actor, 'Recurring invoices generated', ids.join(','), `${generated} draft invoices through ${through}`);
}
export function revalueWarehousePrices(store: WarehouseStore, ids: string[], method: 'Fixed price' | 'Markup on cost' | 'Adjust base price', value: number, date: string, actor: string) {
  if (!ids.length) fail('Select at least one item.');
  if (!validDate(date) || !Number.isFinite(value)) fail('Enter a valid date and value.');
  if (date > new Date().toISOString().slice(0, 10)) fail('Future price changes cannot be applied before their effective date.');
  if (store.revaluations.some(row => ids.includes(row.itemId) && row.date > date)) fail('A later price revaluation already exists for a selected item.');
  const balances = warehouseLedger(store, date).balances;
  const changes: PriceRevaluation[] = [];
  const items = store.items.map(item => {
    if (!ids.includes(item.id) || item.inactive) return item;
    const stock = balances.filter(row => row.itemId === item.id);
    const quantity = stock.reduce((sum, row) => sum + row.quantity, 0);
    if (method === 'Markup on cost' && !quantity) fail(`${item.name} has no stock cost for this date.`);
    const cost = quantity ? stock.reduce((sum, row) => sum + row.value, 0) / quantity : 0;
    const price = money(method === 'Fixed price' ? value : method === 'Markup on cost' ? cost * (1 + value / 100) : item.salePrice + value);
    if (price < 0) fail('A revalued price cannot be negative.');
    changes.push({ id: newWarehouseId(), date, itemId: item.id, oldPrice: item.salePrice, newPrice: price, method, createdBy: actor });
    return { ...item, salePrice: price };
  });
  if (!changes.length) fail('No active items were selected.');
  return log({ ...store, items, revaluations: [...store.revaluations, ...changes] }, actor, 'Sale prices revalued', changes.map(row => row.itemId).join(','), `${method}: ${value}`);
}
export function saveWarehouseMaster<T extends 'items' | 'locations' | 'prices' | 'contracts'>(store: WarehouseStore, collection: T, record: WarehouseStore[T][number], actor: string): WarehouseStore {
  assertScope(store, record.companyId);
  if (collection === 'items') {
    const item = record as StockItem;
    if (!item.code.trim() || !item.name.trim() || !item.unit.trim()) fail('Code, name and unit are required.');
    if (store.items.some(row => row.id !== item.id && row.code.toLowerCase() === item.code.toLowerCase())) fail('Item code already exists.');
    if (![item.salePrice, item.minimumStock, item.vatRate].every(value => Number.isFinite(value) && value >= 0) || item.vatRate > 100) fail('Enter valid prices, minimum stock and VAT rate.');
    if (store.documents.some(row => row.lines.some(line => line.itemId === item.id)) && store.items.find(row => row.id === item.id)?.type !== item.type) fail('The type of a used item cannot be changed.');
  } else if (collection === 'locations') {
    const location = record as StockLocation;
    if (!location.code.trim() || !location.name.trim()) fail('Warehouse code and name are required.');
    if (store.locations.some(row => row.id !== location.id && row.code.toLowerCase() === location.code.toLowerCase())) fail('Warehouse code already exists.');
  } else {
    const row = record as CustomerPrice | RecurringContract;
    if (!row.counterparty.trim() || !store.items.some(item => item.id === row.itemId && !item.inactive)) fail('Select a counterparty and an active item.');
    if (!Number.isFinite(row.unitPrice) || row.unitPrice < 0) fail('Enter a valid unit price.');
    if (collection === 'prices') {
      const price = row as CustomerPrice;
      if (!validDate(price.validFrom) || (price.validTo && (!validDate(price.validTo) || price.validTo < price.validFrom)) || !Number.isFinite(price.discount) || price.discount < 0 || price.discount > 100) fail('Enter a valid validity period and discount.');
    } else {
      const contract = row as RecurringContract;
      if (store.contracts.some(existing => existing.id !== contract.id && existing.number.toLowerCase() === contract.number.trim().toLowerCase())) fail('Contract number already exists.');
      if (!contract.number.trim() || !validDate(contract.startDate) || !validDate(contract.nextDate) || contract.nextDate < contract.startDate || (contract.endDate && (!validDate(contract.endDate) || contract.endDate < contract.startDate)) || !Number.isFinite(contract.quantity) || contract.quantity <= 0) fail('Enter a contract number, valid dates and positive quantity.');
      if (!store.locations.some(location => location.id === contract.warehouseId && !location.inactive)) fail('Select an active warehouse.');
    }
  }
  const rows = store[collection] as typeof record[];
  const previous = rows.find(row => row.id === record.id);
  const saved = { ...record, inactive: previous?.inactive ?? false };
  return log({ ...store, [collection]: previous ? rows.map(row => row.id === saved.id ? saved : row) : [...rows, saved] }, actor, 'Master record saved', record.id, collection);
}
export function warehouseMasterLinked(store: WarehouseStore, collection: 'items' | 'locations' | 'prices' | 'contracts', id: string) {
  return collection === 'items' ? store.documents.some(row => row.lines.some(line => line.itemId === id)) || store.prices.some(row => row.itemId === id) || store.contracts.some(row => row.itemId === id) || store.revaluations.some(row => row.itemId === id)
    : collection === 'locations' ? store.documents.some(row => row.warehouseId === id || row.destinationId === id) || store.contracts.some(row => row.warehouseId === id)
      : collection === 'contracts' ? store.documents.some(row => row.sourceId.startsWith(`${id}:`)) : true;
}
export function removeWarehouseMaster(store: WarehouseStore, collection: 'items' | 'locations' | 'prices' | 'contracts', id: string, actor: string, externallyLinked = false) {
  const linked = externallyLinked || warehouseMasterLinked(store, collection, id);
  return log({ ...store, [collection]: linked ? store[collection].map(row => row.id === id ? { ...row, inactive: true } : row) : store[collection].filter(row => row.id !== id) }, actor, linked ? 'Master record deactivated' : 'Unused master record deleted', id, collection);
}

/** Fictional examples, scoped by company. No B1 customer or transaction data is copied. */
export function createWarehouseExamples(companyId: string): WarehouseStore {
  const store = emptyWarehouse(companyId);
  const scope = (id: string) => `${companyId}:warehouse:${id}`;
  store.locations = [['MAIN', 'Vilnius warehouse'], ['KNS', 'Kaunas warehouse'], ['SHOP', 'Retail store']].map(([code, name]) => ({ id: scope(code), companyId, code, name, address: '', inactive: false }));
  const names = ['Office chair', 'Standing desk', 'Monitor 27 inch', 'Wireless keyboard', 'USB-C dock', 'Desk lamp', 'Storage cabinet', 'Printer paper A4', 'Packaging box', 'Shipping labels', 'Network router', 'Laptop stand', 'Web camera', 'Headset', 'Desk organiser', 'Display adapter', 'Meeting table', 'Filing cabinet', 'Label printer', 'Whiteboard', 'Installation service', 'Monthly support'];
  store.items = names.map((name, index) => ({ id: scope(`item-${index + 1}`), companyId, code: `${index < 20 ? 'PRD' : 'SRV'}-${String(index + 1).padStart(3, '0')}`, name, barcode: index < 20 ? `200000${String(index + 1).padStart(7, '0')}` : '', group: index >= 20 ? 'Services' : index % 3 === 0 ? 'Furniture' : index % 3 === 1 ? 'Office supplies' : 'Electronics', unit: index >= 20 ? 'hour' : 'pcs', type: index >= 20 ? 'Service' : 'Product', salePrice: money(12 + index * 8.5), vatRate: 21, minimumStock: 8, stockAccount: '2010', salesAccount: '5000', costAccount: '6000', inactive: false }));
  const actor = 'Demo accountant';
  const make = (kind: WarehouseKind, index: number, date: string, item: StockItem, quantity: number, price: number, warehouseId = store.locations[0].id) => ({ ...blankWarehouseDocument(store, kind, actor, date), id: scope(`${kind}-${index}`), number: `${kind === 'Purchase' ? 'PUR' : kind === 'Sale' ? 'SAL' : kind === 'Cash sale' ? 'POS' : kind === 'Order' ? 'ORD' : 'WH'}-2026-${String(index).padStart(4, '0')}`, warehouseId, createdAt: `${date}T08:${String(index % 60).padStart(2, '0')}:00Z`, counterparty: kind === 'Purchase' ? ['Northwind Supply', 'Amber Office', 'Baltic Technology'][index % 3] : ['River Services', 'Greenfield Studio', 'Oak Retail'][index % 3], lines: [{ id: scope(`line-${kind}-${index}`), itemId: item.id, quantity, unitPrice: price, vatRate: 21, discount: 0 }] });
  for (let index = 0; index < 20; index++) {
    const item = store.items[index];
    const purchase = { ...make('Purchase', index + 1, '2026-10-01', item, 60 + index * 3, money(item.salePrice * 0.6)), status: 'Posted' as const };
    store.documents.push(purchase);
    const sale = { ...make('Sale', index + 1, `2026-10-${String(5 + index % 20).padStart(2, '0')}`, item, 4 + index % 9, item.salePrice), status: index % 5 === 0 ? 'Draft' as const : 'Posted' as const };
    store.documents.push(sale);
  }
  for (let index = 0; index < 4; index++) {
    const item = store.items[index];
    const transfer = { ...make('Transfer', 100 + index, '2026-10-12', item, 10, 0), destinationId: store.locations[1].id, status: index < 2 ? 'Posted' as const : 'Pending approval' as const };
    store.documents.push(transfer);
    const order = { ...make('Order', index + 1, '2026-10-25', item, 2, item.salePrice), channel: index % 2 ? 'Shopify (example)' : 'WooCommerce (example)' };
    store.documents.push(order);
    const cash = make('Cash sale', index + 1, '2026-10-24', item, 1, item.salePrice);
    store.documents.push({ ...cash, cashPaid: index % 2 ? 0 : documentTotals(cash).total, cardPaid: index % 2 ? documentTotals(cash).total : 0, status: 'Posted' });
  }
  const consignment = { ...make('Consignment', 201, '2026-10-20', store.items[4], 8, 0), status: 'Posted' as const };
  store.documents.push(consignment);
  const sale = store.documents.find(row => row.kind === 'Sale' && row.status === 'Posted')!;
  store.documents.push({ ...createReturnDraft(store, sale, actor), id: scope('return-1'), number: 'RET-2026-0001', date: '2026-10-26', lines: sale.lines.map(line => ({ ...line, id: scope('return-line'), quantity: 1 })), status: 'Posted' });
  const count = make('Stocktake', 301, '2026-10-28', store.items[0], 44, money(store.items[0].salePrice * 0.6));
  store.documents.push(count);
  store.prices = store.items.slice(0, 5).map((item, index) => ({ id: scope(`price-${index}`), companyId, counterparty: 'River Services', itemId: item.id, unitPrice: money(item.salePrice * 0.95), discount: 2, validFrom: '2026-10-01', validTo: '2026-12-31', inactive: false }));
  store.contracts = ['River Services', 'Greenfield Studio', 'Oak Retail'].map((counterparty, index) => ({ id: scope(`contract-${index}`), companyId, number: `CTR-2026-${String(index + 1).padStart(3, '0')}`, counterparty, warehouseId: store.locations[0].id, itemId: store.items[21].id, quantity: 2 + index, unitPrice: 65, startDate: '2026-10-01', endDate: '2027-12-31', nextDate: '2026-10-01', frequency: 'Monthly', inactive: false }));
  warehouseLedger(store);
  return store;
}
