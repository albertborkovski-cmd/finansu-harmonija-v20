/** View-only journal examples. Never persisted as company accounting records. */
export interface GlJournalRow {
  id: string;
  documentNumber: string;
  internalNumber: string;
  operationDate: string;
  counterparty: string;
  account: string;
  accountName?: string;
  description?: string;
  documentType: string;
  documentSubtype: string;
  costCenter: string;
  object?: string;
  department?: string;
  employee?: string;
  vehicle?: string;
  createdBy?: string;
  createdAt?: string;
  inactive?: boolean;
  postingStatus: 'Posted' | 'Unposted';
  debit: number;
  credit: number;
  total: number;
  accountActive: boolean;
  posted: boolean;
  balanced: boolean;
  sample?: boolean;
  /** Booked functional-currency amounts, including any posted FX adjustments. */
  baseCurrency?: string;
  baseDebit?: number;
  baseCredit?: number;
  document: {
    id: string;
    number: string;
    currency: string;
    status: string;
    documentType: string;
    source: string;
    counterpartyCode?: string;
    documentDate?: string;
    dueEndDate?: string;
    note?: string;
    imageUrl?: string | null;
  };
}

export function journalEntrySide(row: GlJournalRow): 'Debit' | 'Credit' | 'Debit / Credit' {
  if (row.debit > 0 && row.credit === 0) return 'Debit';
  if (row.credit > 0 && row.debit === 0) return 'Credit';
  return 'Debit / Credit';
}

/** Use the complete source, never filtered/paginated rows, for document details. */
export function journalDocumentDetails(selected: GlJournalRow, source: GlJournalRow[]) {
  const entries = source.filter(row => row.document.id === selected.document.id);
  const side = journalEntrySide(selected);
  const correspondingEntries = entries.filter(row => row.id !== selected.id && (
    side === 'Debit' ? row.credit > 0 : side === 'Credit' ? row.debit > 0 : true
  ));
  return { entries, side, correspondingEntries, totals: journalCurrencyTotals(entries) };
}

export type JournalGroupKey = 'operationDate' | 'internalNumber' | 'counterparty' | 'documentNumber' | 'account' | 'documentType' | 'costCenter';
export const JOURNAL_GROUP_LABELS: Record<JournalGroupKey, string> = {
  operationDate: 'Date', internalNumber: 'Internal No.', counterparty: 'Counterparty',
  documentNumber: 'Document', account: 'GL account', documentType: 'Type', costCenter: 'Cost center',
};

export const JOURNAL_GROUPINGS: { value: string; label: string; keys: JournalGroupKey[] }[] = [
  { value: 'date', label: 'Date → Counterparty → Internal No. → Document → GL account', keys: ['operationDate', 'counterparty', 'internalNumber', 'documentNumber', 'account'] },
  { value: 'counterparty', label: 'Counterparty → Date → Document → GL account', keys: ['counterparty', 'operationDate', 'documentNumber', 'account'] },
  { value: 'account', label: 'GL account → Date → Counterparty → Document', keys: ['account', 'operationDate', 'counterparty', 'documentNumber'] },
  { value: 'costCenter', label: 'Cost center → Date → Counterparty → Document → GL account', keys: ['costCenter', 'operationDate', 'counterparty', 'documentNumber', 'account'] },
  { value: 'detailed', label: 'Date → Internal No. → Counterparty → Document → GL account → Type', keys: ['operationDate', 'internalNumber', 'counterparty', 'documentNumber', 'account', 'documentType'] },
  { value: 'none', label: 'No grouping', keys: [] },
];

export function journalDate(value: string) {
  return /^\d{4}-\d{2}-\d{2}/.test(value)
    ? value.slice(0, 10)
    : value.replace(/^(\d{2})[./](\d{2})[./](\d{4})$/, '$3-$2-$1');
}

export function journalMatchesPeriod(row: GlJournalRow, period: { from: string; to: string }, account = '') {
  const date = journalDate(row.operationDate);
  return (!account || row.account === account)
    && (!(period.from || period.to) || /^\d{4}-\d{2}-\d{2}$/.test(date))
    && (!period.from || date >= period.from) && (!period.to || date <= period.to);
}

/** Retain inactive entries as visible history; active totals filter them separately. */
export function journalWorkingRows(rows: GlJournalRow[]) {
  return rows.filter(row => !row.posted || row.balanced);
}

export function journalCurrencyTotals(rows: GlJournalRow[]) {
  const totals = new Map<string, { debit: number; credit: number }>();
  rows.forEach(row => {
    const currency = row.document.currency || 'EUR';
    const total = totals.get(currency) ?? { debit: 0, credit: 0 };
    // Sum in minor units so repeated decimal amounts do not accumulate drift.
    total.debit += Math.round(row.debit * 100);
    total.credit += Math.round(row.credit * 100);
    totals.set(currency, total);
  });
  return Array.from(totals, ([currency, total]) => ({ currency, debit: total.debit / 100, credit: total.credit / 100 }));
}

export interface JournalGroup {
  id: string;
  key: JournalGroupKey;
  label: string;
  depth: number;
  rows: GlJournalRow[];
  documentCount: number;
  totals: ReturnType<typeof journalCurrencyTotals>;
  children: JournalGroup[];
}

export function buildJournalGroups(rows: GlJournalRow[], keys: JournalGroupKey[], path: string[] = [], depth = 0): JournalGroup[] {
  const key = keys[depth];
  if (!key) return [];
  const groups = new Map<string, GlJournalRow[]>();
  rows.forEach(row => {
    // Identical document numbers can belong to different source documents.
    const identity = key === 'documentNumber' || key === 'internalNumber'
      ? row.document.id
      : key === 'operationDate' ? journalDate(row[key]) : row[key];
    const entries = groups.get(identity) ?? [];
    entries.push(row);
    groups.set(identity, entries);
  });
  return Array.from(groups, ([identity, entries]) => {
    const nextPath = [...path, key, identity];
    return {
      id: JSON.stringify(nextPath), key, label: key === 'operationDate' ? journalDate(entries[0][key]) : entries[0][key], depth,
      rows: entries, documentCount: new Set(entries.map(row => row.document.id)).size,
      totals: journalCurrencyTotals(entries), children: buildJournalGroups(entries, keys, nextPath, depth + 1),
    };
  });
}

export interface JournalTableRow {
  id: string;
  entries: GlJournalRow[];
  entry?: GlJournalRow;
  summary?: JournalGroup;
  currency: string;
  debit: number;
  credit: number;
  groupCells: Partial<Record<JournalGroupKey, { group: JournalGroup; rowSpan: number; expanded: boolean }>>;
  coveredCells: JournalGroupKey[];
}

/** A real table matrix: grouped values span their children in their own columns. */
export function buildJournalTableRows(
  groups: JournalGroup[],
  rows: GlJournalRow[],
  isExpanded: (group: JournalGroup) => boolean,
  loadedDocumentIds?: Set<string>,
): JournalTableRow[] {
  const isLoaded = (row: GlJournalRow) => !loadedDocumentIds || loadedDocumentIds.has(row.document.id);
  const leaf = (entry: GlJournalRow): JournalTableRow => ({
    id: entry.id, entries: [entry], entry, currency: entry.document.currency || 'EUR',
    debit: entry.debit, credit: entry.credit, groupCells: {}, coveredCells: [],
  });
  const walk = (nodes: JournalGroup[]): JournalTableRow[] => nodes.flatMap(group => {
    if (!group.rows.some(isLoaded)) return [];
    const expanded = isExpanded(group);
    const children: JournalTableRow[] = expanded
      ? group.children.length ? walk(group.children) : group.rows.filter(isLoaded).map(leaf)
      : group.totals.map(total => ({
        id: `${group.id}:${total.currency}`, entries: group.rows.filter(row => (row.document.currency || 'EUR') === total.currency),
        summary: group, ...total, groupCells: {}, coveredCells: [],
      }));
    if (!children.length) return [];
    children[0].groupCells[group.key] = { group, rowSpan: children.length, expanded };
    children.slice(1).forEach(row => row.coveredCells.push(group.key));
    return children;
  });
  return groups.length ? walk(groups) : rows.filter(isLoaded).map(leaf);
}

const SAMPLE_ACCOUNT_NAMES: Record<string, string> = {
  '2410': 'Trade receivables', '2441': 'Input VAT', '2710': 'Bank account',
  '2910': 'Prepaid expenses', '4430': 'Trade payables', '4431': 'Other payables to suppliers', '4484': 'Output VAT',
  '5000': 'Service revenue', '5001': 'Sales revenue', '6300': 'Office expenses',
  '6301': 'Software subscriptions', '6302': 'Accrued operating expenses',
};

export function createSampleJournalRows(companyId: string): GlJournalRow[] {
  const parties = ['UAB Baltijos tiekimas', 'UAB Šiaurės projektai', 'UAB Rytų prekyba', 'UAB Aukštaitijos paslaugos', 'Nordic Systems OÜ', 'Brightline Consulting Ltd'];
  const rows: GlJournalRow[] = [];
  let sequence = 0;
  for (const month of [8, 9, 10]) {
    for (const day of [3, 10, 18, 27]) {
      for (let partyIndex = 0; partyIndex < 2; partyIndex++) {
        for (const kind of ['Purchase', 'Sale', 'Bank', 'Accounting note']) {
          sequence++;
          const id = `gl-test:${companyId}:${sequence}`;
          const date = `2026-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
          const currency = sequence % 5 === 0 ? 'USD' : 'EUR';
          // Fictional historical rates for the existing test journal only (USD per EUR).
          const historicalRate = currency === 'USD' ? ({ 8: 1.08, 9: 1.10, 10: 1.12 }[month] ?? 1) : 1;
          const net = 12500 + sequence * 1379;
          const vat = Math.round(net * 0.21);
          const gross = net + vat;
          const invoice = kind === 'Purchase' || kind === 'Sale';
          const split = sequence % 3 === 0;
          const expense1 = split ? Math.round(net * 0.6) : net;
          const expense2 = net - expense1;
          const supplierAccount = partyIndex === 1 ? '4431' : '4430';
          const postings: [string, number, number][] = kind === 'Purchase'
            ? [['6300', expense1, 0], ...(split ? [['6301', expense2, 0] as [string, number, number]] : []), ['2441', vat, 0], [supplierAccount, 0, gross]]
            : kind === 'Sale'
              ? [['2410', gross, 0], ['5000', 0, expense1], ...(split ? [['5001', 0, expense2] as [string, number, number]] : []), ['4484', 0, vat]]
              : kind === 'Bank'
                ? sequence % 8 === 3 ? [['2710', gross, 0], ['2410', 0, gross]] : [[supplierAccount, gross, 0], ['2710', 0, gross]]
                : [['6302', net, 0], ['2910', 0, net]];
          const prefix = kind === 'Purchase' ? 'PIR' : kind === 'Sale' ? 'SF' : kind === 'Bank' ? 'BNK' : 'BP';
          const number = `${prefix}26-${String(month).padStart(2, '0')}${String(sequence).padStart(3, '0')}`;
          const posted = sequence % 7 !== 0;
          const document = {
            id, number, currency, status: posted ? 'Approved' : 'Draft', documentType: kind, source: 'Test data',
            counterpartyCode: String(305120001 + (month + day + partyIndex) % parties.length),
            documentDate: date,
            dueEndDate: invoice ? new Date(Date.UTC(2026, month - 1, day + 30)).toISOString().slice(0, 10) : '',
          };
          postings.forEach(([account, debit, credit], index) => rows.push({
            id: `${id}:${index}`, documentNumber: number, internalNumber: String(260000 + sequence),
            operationDate: date, counterparty: parties[(month + day + partyIndex) % parties.length],
            account, accountName: SAMPLE_ACCOUNT_NAMES[account], documentType: kind,
            description: kind === 'Purchase' ? 'Office supplies and software services' : kind === 'Sale' ? 'Monthly accounting and advisory services' : kind === 'Bank' ? `Invoice payment · ${number}` : 'Monthly expense accrual',
            documentSubtype: invoice ? 'Invoice' : kind === 'Bank' ? (debit > 0 && account === '2710' || credit > 0 && account === '2410' ? 'Receipt' : 'Payment') : 'Accrual',
            costCenter: ['Administration', 'Operations', 'Sales'][(partyIndex + month + day) % 3],
            object: ['Office Vilnius', 'Warehouse Kaunas', 'Client projects'][partyIndex % 3],
            department: ['Accounting', 'Operations', 'Sales'][(month + partyIndex) % 3],
            employee: ['Aurika Z.', 'Albert Borkovski', 'Milda Petrauskė'][sequence % 3],
            vehicle: kind === 'Bank' ? ['Toyota Corolla · MEO 101', 'VW Passat · MEO 202'][partyIndex] : '',
            createdBy: ['Albert Borkovski', 'Aurika Z.', 'Milda Petrauskė'][sequence % 3],
            createdAt: `${date}T08:00:00Z`,
            postingStatus: posted ? 'Posted' : 'Unposted', debit: debit / 100, credit: credit / 100,
            total: Math.max(debit, credit) / 100, accountActive: true, posted, balanced: true, sample: true, document,
            baseCurrency: 'EUR', baseDebit: Math.round(debit / historicalRate) / 100, baseCredit: Math.round(credit / historicalRate) / 100,
          }));
        }
      }
    }
  }
  return rows;
}
