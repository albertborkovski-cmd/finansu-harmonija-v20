import type { GlJournalRow } from './glJournal';

/** An immutable posting supplied by the posting/import boundary, never inferred
 * from document totals or from the journal's illustrative combined D/K rows. */
export type PostedDocumentLine = {
  id: string; account: string; accountName: string; currency: string;
  debitMinor: number; creditMinor: number; baseDebitMinor: number; baseCreditMinor: number;
  counterparty?: string; costCenter?: string; department?: string; object?: string;
  employee?: string; vehicle?: string; description?: string; originalLineId?: string;
};
export type PostedDocumentOperation = {
  id: string; number: string; companyId: string; documentId: string;
  status: 'Posted'; date: string; postedAt: string; postedBy: string; baseCurrency: string;
  integration: { destination: 'Local' | 'External'; status: 'Not sent' | 'Pending' | 'Transferred' | 'Failed' | 'Unknown'; externalId?: string };
  lines: PostedDocumentLine[];
};
export type DocumentStorno = PostedDocumentOperation & {
  originalOperationId: string; originalOperationNumber: string; reason: string;
  history: { id: string; at: string; actor: string; action: string; details: string }[];
};
export type StornoDocument = {
  id: string; company_id?: string; status?: string; accounting_posting?: PostedDocumentOperation;
  accounting_storno?: DocumentStorno;
  [key: string]: unknown;
};
export type StornoCommand = { expectedPosting: string; date: string; reason: string };
export type StornoPeriodPolicy = { enabled: boolean; cutoffDay: number; closedThrough?: string };
export type StornoContext = { allowed: boolean; actor: string; now: string; today: string; period: StornoPeriodPolicy };
const nonEmptyText = (value: unknown): value is string => typeof value === 'string' && Boolean(value.trim());

export function validAccountingDate(value: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T12:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
export function accountingToday(now = new Date()) {
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}
export function postedOperationError(posting: PostedDocumentOperation, document: Pick<StornoDocument, 'id' | 'company_id'>): string {
  if (!posting || posting.status !== 'Posted') return 'A confirmed GL operation is required.';
  if (!nonEmptyText(posting.id) || !nonEmptyText(posting.number) || posting.documentId !== document.id || posting.companyId !== document.company_id)
    return 'The GL operation is not linked to this document and company.';
  if (!validAccountingDate(posting.date) || !nonEmptyText(posting.postedAt) || !Number.isFinite(Date.parse(posting.postedAt)) || !nonEmptyText(posting.postedBy) || !/^[A-Z]{3}$/.test(posting.baseCurrency))
    return 'The original posting metadata is incomplete. Correct the posting source first.';
  if (!Array.isArray(posting.lines) || posting.lines.length < 2) return 'The confirmed GL operation must contain complete debit and credit lines.';
  const totals = new Map<string, { debit: number; credit: number }>();
  let baseDebit = 0, baseCredit = 0;
  const ids = new Set<string>();
  for (const line of posting.lines) {
    if (!line || !nonEmptyText(line.id) || ids.has(line.id) || !nonEmptyText(line.account) || typeof line.accountName !== 'string' || !/^[A-Z]{3}$/.test(line.currency)
      || ![line.debitMinor, line.creditMinor, line.baseDebitMinor, line.baseCreditMinor].every(value => Number.isSafeInteger(value) && value >= 0)
      || (line.debitMinor > 0) === (line.creditMinor > 0)
      || (line.debitMinor === 0 && line.baseDebitMinor !== 0) || (line.creditMinor === 0 && line.baseCreditMinor !== 0))
      return 'The original GL lines are invalid. Storno requires exact, separate debit and credit amounts.';
    ids.add(line.id);
    const total = totals.get(line.currency) ?? { debit: 0, credit: 0 };
    total.debit += line.debitMinor; total.credit += line.creditMinor; totals.set(line.currency, total);
    baseDebit += line.baseDebitMinor; baseCredit += line.baseCreditMinor;
  }
  if (![baseDebit, baseCredit, ...[...totals.values()].flatMap(value => [value.debit, value.credit])].every(Number.isSafeInteger)
    || baseDebit !== baseCredit || baseDebit <= 0)
    return 'The confirmed GL operation is not balanced. Correct the posting source first.';
  return '';
}
export function documentStornoBlocker(document: StornoDocument, allowed: boolean): string {
  if (!allowed) return 'You need View, Edit and Create access to Documents and access to this company.';
  if (document.accounting_storno) return `This operation has already been reversed (${document.accounting_storno.number}).`;
  if (!document.accounting_posting) return 'No confirmed GL posting is linked to this document. A document status or a calculated GL preview is not a posting.';
  const error = postedOperationError(document.accounting_posting, document);
  if (error) return error;
  const integration = document.accounting_posting.integration;
  if (!integration || integration.destination !== 'Local' || integration.status !== 'Not sent' || integration.externalId
    || /^(transferred|exported)$/i.test(String(document.status))
    || Object.entries(document).some(([key, value]) => /^(exported|transferred|external_posting|external_document)(_|$)/i.test(key) && Boolean(value)))
    return 'External accounting control: this posting is sent, pending, or not verified as local. Reverse it through the connected accounting system and synchronize the confirmed result. No local-only reversal is allowed.';
  return '';
}
export function stornoPeriodError(date: string, originalDate: string, today: string, policy: StornoPeriodPolicy): string {
  if (!validAccountingDate(date)) return 'Select a valid reversal date.';
  if (date < originalDate) return 'The reversal date cannot be earlier than the original posting date.';
  if (date > today) return 'The reversal date cannot be in the future.';
  if (policy.closedThrough && date <= policy.closedThrough) return `The accounting period is locked through ${policy.closedThrough}. Select an open period.`;
  if (policy.enabled) {
    const current = new Date(`${today}T12:00:00Z`);
    const firstOpen = new Date(Date.UTC(current.getUTCFullYear(), current.getUTCMonth() - (current.getUTCDate() <= policy.cutoffDay ? 1 : 0), 1)).toISOString().slice(0, 10);
    if (date < firstOpen) return `This period is closed by the company monthly cutoff. Select ${firstOpen} or later.`;
  }
  return '';
}
export function reversePostedLines(posting: PostedDocumentOperation, id: string): PostedDocumentLine[] {
  return posting.lines.map((line, index) => ({ ...line, id: `${id}:${index + 1}`, originalLineId: line.id,
    debitMinor: line.creditMinor, creditMinor: line.debitMinor,
    baseDebitMinor: line.baseCreditMinor, baseCreditMinor: line.baseDebitMinor }));
}
export function savedDocumentStornoError(document: StornoDocument): string {
  const reversal = document.accounting_storno;
  if (!reversal) return '';
  const posting = document.accounting_posting;
  const error = 'The saved Storno does not match the original posting. Its integrity must be checked before continuing.';
  if (!posting || postedOperationError(posting, document) || postedOperationError(reversal, document)
    || reversal.originalOperationId !== posting.id || reversal.originalOperationNumber !== posting.number
    || reversal.baseCurrency !== posting.baseCurrency || reversal.date < posting.date || !nonEmptyText(reversal.reason)
    || !Array.isArray(reversal.history) || !reversal.history.length
    || reversal.history.some(event => !event || !nonEmptyText(event.id) || !nonEmptyText(event.actor) || !nonEmptyText(event.action) || !nonEmptyText(event.details) || !Number.isFinite(Date.parse(event.at)))
    || reversal.lines.length !== posting.lines.length) return error;
  const expected = reversePostedLines(posting, reversal.id);
  return expected.some((line, index) => Object.entries(line).some(([key, value]) => (reversal.lines[index] as unknown as Record<string, unknown>)[key] !== value)) ? error : '';
}
export function createDocumentStorno(document: StornoDocument, command: StornoCommand, context: StornoContext): StornoDocument {
  const blocked = documentStornoBlocker(document, context.allowed);
  if (blocked) throw new Error(blocked);
  const posting = document.accounting_posting!;
  if (JSON.stringify(posting) !== command.expectedPosting) throw new Error('The original posting has changed. Close and reopen Storno before continuing.');
  const periodError = stornoPeriodError(command.date, posting.date, context.today, context.period);
  if (periodError) throw new Error(periodError);
  const reason = command.reason.trim();
  if (!reason || reason.length > 2000) throw new Error('Enter a reversal reason (1–2,000 characters).');
  if (!context.actor || !Number.isFinite(Date.parse(context.now))) throw new Error('The action author and timestamp are required.');
  const id = `storno:${posting.id}`;
  const number = `ST-${posting.number}`;
  const reversal: DocumentStorno = {
    id, number, companyId: posting.companyId, documentId: document.id, status: 'Posted', date: command.date,
    postedAt: context.now, postedBy: context.actor, baseCurrency: posting.baseCurrency,
    integration: { destination: 'Local', status: 'Not sent' },
    originalOperationId: posting.id, originalOperationNumber: posting.number, reason,
    lines: reversePostedLines(posting, id),
    history: [{ id: `${id}:created`, at: context.now, actor: context.actor, action: 'Storno posted',
      details: `${number} reverses ${posting.number} (${posting.id}) on ${command.date}. Reason: ${reason}. Original GL entries retained unchanged.` }],
  };
  return { ...document, accounting_storno: reversal };
}

/** Ordinary edits/imports cannot create, replace, erase or bypass posting history. */
export function guardPostedDocumentMutation(previous: Record<string, unknown>, patch: Record<string, unknown>) {
  for (const key of ['accounting_posting', 'accounting_storno']) {
    if (key in patch && JSON.stringify(patch[key]) !== JSON.stringify(previous[key]))
      throw new Error('Confirmed accounting operations can only be changed through the posting / Storno workflow.');
  }
  if (!previous.accounting_posting) return;
  const accountingFields = new Set(['id', 'company_id', 'status', 'accounting_note_status', 'number', 'series', 'type', 'document_type', 'document_subtype', 'currency', 'operation_date', 'document_date', 'invoice_contract_date', 'total_amount', 'amount_without_vat', 'vat', 'vat_percent', 'expense_account', 'vat_classifier', 'debit', 'credit', 'line_items', 'summary_line_items', 'counterparty_id', 'client_counterparty', 'department_code', 'object_project', 'accountable_responsible', 'cost_center', 'inactive', 'is_active', 'active']);
  if (Object.keys(patch).some(key => (accountingFields.has(key) || /^(exported|transferred|external_posting|external_document)(_|$)/i.test(key)) && JSON.stringify(previous[key]) !== JSON.stringify(patch[key])))
    throw new Error('The confirmed accounting operation is immutable. Use Storno to reverse its effect; the original document and posting remain in history.');
}

/** Show original and reversal as independent, posted entries, including base amounts. */
export function documentPostingRows(document: StornoDocument, activeAccounts: Set<string>): GlJournalRow[] {
  const posting = document.accounting_posting;
  if (!posting || postedOperationError(posting, document)) return [];
  const operations: (PostedDocumentOperation | DocumentStorno)[] = [posting];
  if (document.accounting_storno && !savedDocumentStornoError(document)) operations.push(document.accounting_storno);
  return operations.flatMap(operation => operation.lines.map(line => ({
    id: line.id, documentNumber: operation.number, internalNumber: operation.id, operationDate: operation.date,
    counterparty: line.counterparty || '—', account: line.account, accountName: line.accountName,
    description: line.description, documentType: 'Accounting note', documentSubtype: 'originalOperationId' in operation ? 'Storno' : 'Confirmed posting',
    costCenter: line.costCenter || '—', object: line.object, department: line.department, employee: line.employee, vehicle: line.vehicle,
    createdBy: operation.postedBy, createdAt: operation.postedAt, postingStatus: 'Posted', posted: true, balanced: true,
    debit: line.debitMinor / 100, credit: line.creditMinor / 100, total: Math.max(line.debitMinor, line.creditMinor) / 100,
    baseCurrency: operation.baseCurrency, baseDebit: line.baseDebitMinor / 100, baseCredit: line.baseCreditMinor / 100,
    accountActive: activeAccounts.has(line.account),
    document: { id: operation.id, number: operation.number, currency: line.currency, status: 'Approved', documentType: 'Accounting note',
      source: 'Confirmed document GL posting', documentDate: operation.date,
      note: 'originalOperationId' in operation ? `Storno of ${operation.originalOperationNumber} (${operation.originalOperationId}). ${operation.reason}` : `Source document: ${String(document.number || document.id)}` },
  })));
}
