import { canEditMenu, canViewMenu, parseSession } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import { canAccessAssignedOrganization, loadLinkedDirectoryUsers, loadOrganizationUserIds, organizationAssignmentStorageKey, type SettingsAudience } from './linkedSettingsData';
import { isInactiveRecord } from './recordLifecycle';

function canAccessCompanyDocuments(company: { id: string; name: string; assigned_accountant?: string } | undefined, edit: boolean) {
  try {
    const session = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
    if (!company || !session || !canViewMenu(session, 'documents') || (edit && !canEditMenu(session, 'documents')) || !canAccessAssignedOrganization(company, session)) return false;
    for (const audience of ['Internal users', 'External users'] as SettingsAudience[]) {
      const user = loadLinkedDirectoryUsers(audience).find(candidate => candidate.email?.trim().toLowerCase() === session.email.trim().toLowerCase());
      if (!user) continue;
      if (isInactiveRecord(user) || (user.status && !['enabled', 'active'].includes(user.status.trim().toLowerCase()))) return false;
      if (session.roleNames.some(role => ['administrator', 'administration', 'meso accountant'].includes(role.toLowerCase()))) return true;
      if (window.localStorage.getItem(organizationAssignmentStorageKey(company.id, audience)) !== null)
        return loadOrganizationUserIds(company.id, audience).includes(user.id);
      const organizations = (user.organizations ?? '').split(',').map(value => value.trim().toLowerCase());
      return organizations.some(value => ['all organizations', company.id.toLowerCase(), company.name.toLowerCase()].includes(value));
    }
    return false;
  } catch { return false; }
}

export const canEditCompanyDocuments = (company: { id: string; name: string; assigned_accountant?: string } | undefined) => canAccessCompanyDocuments(company, true);
export const canViewCompanyDocuments = (company: { id: string; name: string; assigned_accountant?: string } | undefined) => canAccessCompanyDocuments(company, false);
