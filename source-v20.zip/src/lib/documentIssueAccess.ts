import { canEditMenu, canViewMenu, parseSession } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import { canAccessAssignedOrganization, loadLinkedDirectoryUsers } from './linkedSettingsData';

export function documentIssueSession() {
  return parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
}
export function canReviewDocumentIssues() {
  const session = documentIssueSession();
  if (!session || !canEditMenu(session, 'ocr-review-approve-documents')) return false;
  const external = loadLinkedDirectoryUsers('External users').some(user => user.email?.toLowerCase() === session.email.toLowerCase());
  return !external && !session.roleNames.includes('External demo user');
}
export function canAccessIssueOrganization(organization: { id: string; name: string; assigned_accountant?: string }, edit = false) {
  const session = documentIssueSession();
  return Boolean(session && canAccessAssignedOrganization(organization, session) &&
    (canReviewDocumentIssues() || (edit ? canEditMenu(session, 'documents') : canViewMenu(session, 'documents'))));
}
