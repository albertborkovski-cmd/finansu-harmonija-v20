export const DOCUMENT_HEADER_FIELDS = {
  note: 'notes', documentPurpose: 'document_purpose', orderNo: 'order_no', series: 'series',
  accountableResponsible: 'accountable_responsible', type: 'type',
  documentType: 'document_type',
} as const;
export const DOCUMENT_ALLOCATION_FIELDS = {
  expenseAccount: ['expense_account', 'expense'], vatClassifier: ['vat_classifier', 'vatClass'],
  departmentCode: ['department_code', 'department'], objectProject: ['object_project', 'object'],
  costCenter: ['cost_center', 'center'], productGroup: ['product_group', 'productGroup'],
} as const;
export type InlineDocumentField = keyof typeof DOCUMENT_HEADER_FIELDS | keyof typeof DOCUMENT_ALLOCATION_FIELDS;
export type InlineDocumentSource = { id: string; status?: string; accounting_note_status?: string; summary_line_items?: unknown; [key: string]: unknown };
const isAllocationField = (key: string): key is keyof typeof DOCUMENT_ALLOCATION_FIELDS => Object.hasOwn(DOCUMENT_ALLOCATION_FIELDS, key);
export function isInlineDocumentField(key: string): key is InlineDocumentField {
  return Object.hasOwn(DOCUMENT_HEADER_FIELDS, key) || isAllocationField(key);
}
/** Summary rows are accounting distributions; Quantity rows are OCR/product data.
 * A legacy document without Summary rows has one document-level allocation. */
export function documentAllocationCount(document: InlineDocumentSource) {
  const rows = document.summary_line_items;
  if (rows == null || (Array.isArray(rows) && rows.length === 0)) return 1;
  if (!Array.isArray(rows) || rows.some(row => !row || typeof row !== 'object' || Array.isArray(row))) return 0;
  return rows.length;
}
export function documentEditStateError(document: InlineDocumentSource): string {
  if (document.inactive || document.active === false || document.is_active === false) return 'Inactive documents cannot be edited.';
  if (document.accounting_posting || document.accounting_storno) return 'Confirmed GL operations are read-only. Use the Storno workflow.';
  const states = [document.status, document.accounting_note_status].map(value => String(value ?? '').trim().toLowerCase());
  if (states.some(value => ['approved', 'confirmed', 'posted', 'transferred', 'exported', 'processing'].includes(value))
    || Object.entries(document).some(([key, value]) => /^(exported|transferred|external_posting|external_document)(_|$)/i.test(key) && Boolean(value)))
    return 'This document is confirmed, processing or transferred. Return it to an editable state through the permitted workflow.';
  if (!['', 'draft', 'new', 'pending', 'manual', 'correcting', 'provide additional', 'exception', 'rejected', 'duplicate', 'not documented', 'paid', 'overdue'].includes(states[0]))
    return 'The document state does not allow direct editing.';
  return '';
}
export function documentInlineEditError(document: InlineDocumentSource, field: string, allowed: boolean): string {
  if (!allowed) return 'You need View and Edit access to Documents and access to this company.';
  if (!isInlineDocumentField(field)) return 'This field must be edited in the document card.';
  const stateError = documentEditStateError(document);
  if (stateError) return stateError;
  if (isAllocationField(field) && documentAllocationCount(document) !== 1)
    return 'Multiple or unavailable accounting allocations. Edit this field in the document card.';
  return '';
}
export function documentInlineValue(document: InlineDocumentSource, field: InlineDocumentField): string {
  if (!isAllocationField(field)) return String(document[DOCUMENT_HEADER_FIELDS[field as keyof typeof DOCUMENT_HEADER_FIELDS]] ?? '');
  const [db, lineKey] = DOCUMENT_ALLOCATION_FIELDS[field];
  const rows = document.summary_line_items;
  if (!Array.isArray(rows) || !rows.length) return String(document[db] ?? '');
  const values = rows.map(row => String(row?.[lineKey] ?? '').trim());
  return values.every(value => value === values[0]) ? values[0] : '';
}
export function documentInlineSnapshot(document: InlineDocumentSource) {
  return JSON.stringify({
    fields: Object.fromEntries([...Object.keys(DOCUMENT_HEADER_FIELDS), ...Object.keys(DOCUMENT_ALLOCATION_FIELDS)].map(key => [key, documentInlineValue(document, key as InlineDocumentField)])),
    allocations: document.summary_line_items ?? null,
    documentSubtype: document.document_subtype ?? '',
  });
}
export function documentInlinePatch(document: InlineDocumentSource, field: InlineDocumentField, value: string, expectedSnapshot: string, allowed: boolean): Record<string, unknown> {
  const error = documentInlineEditError(document, field, allowed);
  if (error) throw new Error(error);
  if (documentInlineSnapshot(document) !== expectedSnapshot) throw new Error('The document or its allocations changed. Refresh before saving.');
  if (typeof value !== 'string' || value.length > (field === 'note' ? 5000 : 1000)) throw new Error('The field value is too long.');
  if (field === 'documentType') {
    if (!value.trim()) throw new Error('Document type is required.');
    return { document_type: value, ...(value !== document.document_type ? { document_subtype: '' } : {}) };
  }
  if (!isAllocationField(field)) return { [DOCUMENT_HEADER_FIELDS[field as keyof typeof DOCUMENT_HEADER_FIELDS]]: value };
  const [db, lineKey] = DOCUMENT_ALLOCATION_FIELDS[field];
  const rows = document.summary_line_items;
  return { [db]: value, ...(Array.isArray(rows) && rows.length === 1 ? { summary_line_items: [{ ...rows[0], [lineKey]: value }] } : {}) };
}
