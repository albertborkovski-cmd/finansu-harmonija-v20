import type { ReconciliationItem, ReconciliationProposal } from './reconciliation';

type CombinedEntry =
  | { id: string; itemIds: string[]; proposal: ReconciliationProposal; item?: never }
  | { id: string; itemIds: string[]; item: ReconciliationItem; proposal?: never };

/** A proposal remains one group; documents outside proposals remain individual open rows. */
export function reconciliationCombinedEntries(items: ReconciliationItem[], proposals: ReconciliationProposal[]): CombinedEntry[] {
  const openIds = new Set(items.map(item => item.id));
  const represented = new Set<string>();
  const entries: CombinedEntry[] = [];
  for (const proposal of proposals) {
    const itemIds = [...new Set([proposal.fundingId, ...proposal.allocations.map(allocation => allocation.invoiceId)])];
    if (!itemIds.every(id => openIds.has(id))) continue;
    itemIds.forEach(id => represented.add(id));
    entries.push({ id: proposal.id, itemIds, proposal });
  }
  for (const item of items) {
    if (!represented.has(item.id)) entries.push({ id: item.id, itemIds: [item.id], item });
  }
  return entries;
}

export function expandReconciliationRowSelection(ids: string[], entries: CombinedEntry[]): string[] {
  const selected = new Set(ids);
  return [...new Set(entries.filter(entry => selected.has(entry.id)).flatMap(entry => entry.itemIds))];
}
