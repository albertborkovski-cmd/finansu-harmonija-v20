export function dropdownPosition(
  anchor: { left: number; top: number; bottom: number; width: number },
  viewport: { width: number; height: number },
  preferredWidth = 280,
  preferredHeight = 360,
) {
  const edge = 8, gap = 4;
  const width = Math.max(0, Math.min(Math.max(anchor.width, preferredWidth), viewport.width - edge * 2));
  const available = Math.max(0, viewport.height - edge * 2);
  const below = Math.max(0, Math.min(available, viewport.height - anchor.bottom - gap - edge));
  const above = Math.max(0, Math.min(available, anchor.top - gap - edge));
  const openAbove = below < Math.min(preferredHeight, 180) && above > below;
  return {
    left: Math.max(edge, Math.min(anchor.left, viewport.width - width - edge)),
    width,
    maxHeight: Math.min(preferredHeight, openAbove ? above : below),
    ...(openAbove ? { bottom: Math.max(edge, viewport.height - anchor.top + gap) } : { top: Math.max(edge, anchor.bottom + gap) }),
  };
}
