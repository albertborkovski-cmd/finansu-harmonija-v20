export const DOCUMENT_PROCESSING_STATUSES = [
  'Draft', 'Pending', 'Paid', 'Processing', 'Rejected', 'Provide Additional',
  'Exception', 'Transferred', 'Duplicate', 'Not Documented',
] as const;

/** Legacy payment lateness is not evidence of a document processing state.
 * Keep the stored value/history intact; show an unspecified processing state. */
export function documentProcessingStatus(value: unknown): string {
  const status = typeof value === 'string' ? value.trim() : '';
  return status.toLowerCase() === 'overdue' ? '' : status;
}
