export type DocumentExportFormat = 'csv' | 'xlsx' | 'json';
export type ExportColumn = { key: string; label: string };
export type ExportRow = { id: string; companyId: string; [key: string]: unknown };

/** Explicit selection only: clearing a filter must never export additional records. */
export function selectedDocumentRecords<T extends { id: string; company_id?: string }>(rows: T[], ids: string[], companyId = ''): T[] {
  const uniqueIds = [...new Set(ids)];
  if (!uniqueIds.length) throw new Error('Select at least one document.');
  const byId = new Map(rows.map(row => [row.id, row]));
  return uniqueIds.map(id => {
    const row = byId.get(id);
    if (!row || (companyId && row.company_id !== companyId)) throw new Error('A selected document is no longer available in this company. Refresh the list and select it again.');
    return row;
  });
}

const defaultDestinations = [{ id: 'rivile', name: 'Rivilė' }, { id: 'rivile-api', name: 'Rivilė API' }, { id: 'agnum', name: 'Agnum' }];
export function documentDeliveryDestinations(settings = ''): Array<{ value: string; label: string }> {
  try {
    const parsed = JSON.parse(settings || '{}');
    const integrations = Array.isArray(parsed.exportIntegrations) ? parsed.exportIntegrations : defaultDestinations;
    const seen = new Set<string>();
    return integrations.flatMap((item: { id?: unknown; name?: unknown; active?: boolean; inactive?: boolean }) => {
      if (!item || item.active === false || item.inactive === true) return [];
      const value = String(item.id ?? '').trim(), label = String(item.name ?? '').trim();
      if (!value || !label || seen.has(value)) return [];
      seen.add(value);
      // Never expose endpoint credentials or other integration settings in the UI/export.
      return [{ value, label }];
    });
  } catch { return []; }
}

function exportText(value: unknown): string {
  return typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean' ? String(value) : '';
}
function csvCell(value: string): string {
  let start = 0;
  while (start < value.length && (value.charCodeAt(start) <= 32 || /\s/.test(value[start]))) start++;
  const safe = /^[=+@-]/.test(value.slice(start)) ? `'${value}` : value;
  return `"${safe.replace(/"/g, '""')}"`;
}
export async function buildDocumentExport(rows: ExportRow[], columns: ExportColumn[], format: DocumentExportFormat, companyName = 'Documents') {
  if (!rows.length) throw new Error('Select at least one document.');
  if (!columns.length) throw new Error('Choose at least one visible column in Column settings.');
  const name = companyName.replace(/[^\p{L}\p{N} _-]/gu, '').trim().replace(/\s+/g, '-') || 'Documents';
  const filename = `${name}-documents-${new Date().toISOString().slice(0, 10)}.${format}`;
  const values = rows.map(row => columns.map(column => exportText(row[column.key])));
  const headers = columns.map(column => column.label);
  if (format === 'csv') return { filename, mime: 'text/csv;charset=utf-8', content: '\uFEFF' + [headers, ...values].map(row => row.map(csvCell).join(',')).join('\r\n') };
  if (format === 'json') return { filename, mime: 'application/json;charset=utf-8', content: JSON.stringify({ columns, documents: rows.map((row, index) => ({ id: row.id, companyId: row.companyId, values: Object.fromEntries(columns.map((column, columnIndex) => [column.key, values[index][columnIndex]])) })) }, null, 2) };
  if (format === 'xlsx') {
    const XLSX = await import('xlsx');
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.aoa_to_sheet([headers, ...values]), 'Documents');
    return { filename, mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', content: XLSX.write(workbook, { bookType: 'xlsx', type: 'array' }) as ArrayBuffer };
  }
  throw new Error('Choose a supported export format.');
}

export function downloadDocumentExport(file: { filename: string; mime: string; content: string | ArrayBuffer }) {
  const url = URL.createObjectURL(new Blob([file.content], { type: file.mime }));
  const link = document.createElement('a');
  link.href = url; link.download = file.filename;
  document.body.appendChild(link); link.click(); link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
