/** PDF dependencies are loaded only when a user requests an export. */
export async function warehousePdf(title: string, columns: string[], rows: (string | number)[][], subtitle = '') {
  const [{ jsPDF }, { default: autoTable }] = await Promise.all([import('jspdf'), import('jspdf-autotable')]);
  const pdf = new jsPDF({ orientation: columns.length > 6 ? 'landscape' : 'portrait' });
  pdf.setFontSize(16);
  pdf.text(title, 14, 18);
  pdf.setFontSize(10);
  pdf.text(subtitle, 14, 25);
  autoTable(pdf, { startY: 32, head: [columns], body: rows, styles: { fontSize: 8 }, headStyles: { fillColor: [0, 126, 167] } });
  pdf.save(`${title.replace(/[^a-z0-9 -]/gi, '')}.pdf`);
}
