export type DocumentIssueStatus = 'Open' | 'In progress' | 'Resolved';
export type DocumentIssueEvent = { id: string; at: string; actor: string; action: string; details: string; changes?: Array<{ field: string; before: unknown; after: unknown }> };
export type DocumentIssue = {
  id: string;
  message: string;
  status: DocumentIssueStatus;
  organizationId: string;
  documentLabel: string;
  blocksApproval: boolean;
  createdAt: string;
  createdBy: string;
  resolvedAt?: string;
  resolution?: string;
  events: DocumentIssueEvent[];
};
export type IssueDocument = { id?: unknown; company_id?: unknown; status?: unknown; digitization_issues?: DocumentIssue[] };
export type DocumentIssueCommand =
  | { type: 'report'; message: string }
  | { type: 'start'; issueId: string }
  | { type: 'organization'; issueId: string; organizationId: string; note: string }
  | { type: 'request-ocr'; issueId: string; note: string }
  | { type: 'resolve'; issueId: string; note: string };

const APPROVED = new Set(['approved', 'accepted', 'completed', 'processed', 'transferred', 'exported', 'posted', 'paid']);
export function isApprovedDocumentStatus(status: unknown) {
  return APPROVED.has(String(status ?? '').trim().toLowerCase());
}
export function documentIssueStatus(document: IssueDocument): DocumentIssueStatus | '' {
  const issues = document.digitization_issues ?? [];
  if (issues.some(issue => issue.status === 'Open')) return 'Open';
  if (issues.some(issue => issue.status === 'In progress')) return 'In progress';
  return issues.length ? 'Resolved' : '';
}
export function hasBlockingDocumentIssue(document: IssueDocument) {
  return (document.digitization_issues ?? []).some(issue => issue.status !== 'Resolved' && (issue.blocksApproval || !isApprovedDocumentStatus(document.status)));
}
export function documentIssueEvent(actor: string, action: string, details: string): DocumentIssueEvent {
  return { id: crypto.randomUUID(), at: new Date().toISOString(), actor, action, details };
}

/** Shared write guard: UI controls alone cannot protect bulk and stale writes. */
export function guardDocumentMutation(previous: Record<string, unknown>, patch: Record<string, unknown>, actor: string) {
  if ('company_id' in patch && previous.company_id && patch.company_id !== previous.company_id)
    throw new Error('Report an issue to change an assigned organization. Only MESO Worker may correct it during issue review.');
  const issues = (previous.digitization_issues ?? []) as DocumentIssue[];
  if ('digitization_issues' in patch && JSON.stringify(patch.digitization_issues) !== JSON.stringify(issues))
    throw new Error('Issue history has changed. Refresh the document; issue status can only be changed through Report issue / MESO Worker review.');
  if (hasBlockingDocumentIssue(previous) && (
    ('status' in patch && isApprovedDocumentStatus(patch.status)) ||
    ('accounting_note_status' in patch && isApprovedDocumentStatus(patch.accounting_note_status)) ||
    Object.entries(patch).some(([key, value]) => /^(exported|transferred|posted|approved|accepted)(_|$)/i.test(key) && Boolean(value))
  )) throw new Error('Resolve the reported digitization issue before approving or transferring this document to accounting.');
  // A previously approved document must also become blocked if returned to a draft.
  const nextStatus = 'status' in patch ? patch.status : previous.status;
  const changes = Object.keys(patch).filter(key => !['digitization_issues', 'updated_at'].includes(key) && JSON.stringify(previous[key]) !== JSON.stringify(patch[key]));
  const changeEvent = documentIssueEvent(actor, 'Document updated', `Updated fields: ${changes.map(key => key.replaceAll('_', ' ')).join(', ')}.`);
  changeEvent.changes = changes.map(field => ({ field, before: previous[field] ?? null, after: patch[field] ?? null }));
  return {
    ...previous, ...patch,
    ...(issues.length ? { digitization_issues: issues.map(issue => issue.status === 'Resolved' || !changes.length ? issue : {
      ...issue, blocksApproval: issue.blocksApproval || !isApprovedDocumentStatus(nextStatus), events: [...issue.events, changeEvent],
    }) } : {}),
  };
}

export function transitionDocumentIssue(document: Record<string, unknown>, command: DocumentIssueCommand, actor: string) {
  const issues = (document.digitization_issues ?? []) as DocumentIssue[];
  if (command.type === 'report') {
    const message = command.message.trim();
    if (!message || message.length > 5000) throw new Error('Describe the issue (1–5,000 characters).');
    const event = documentIssueEvent(actor, 'Reported to MESO Worker', message);
    const issue: DocumentIssue = { id: crypto.randomUUID(), message, status: 'Open', organizationId: String(document.company_id ?? ''), documentLabel: String(document.number || document.file_case || document.id), blocksApproval: !isApprovedDocumentStatus(document.status), createdAt: event.at, createdBy: actor, events: [event] };
    return { ...document, digitization_issues: [...issues, issue] };
  }
  const issue = issues.find(item => item.id === command.issueId);
  if (!issue || issue.status === 'Resolved') throw new Error('This issue is no longer open. Refresh the document.');
  if (command.type !== 'start' && (!command.note.trim() || command.note.length > 5000)) throw new Error('Enter a correction / resolution note (1–5,000 characters).');
  const next = { ...issue, events: [...issue.events] };
  let patch: Record<string, unknown> = {};
  if (command.type === 'start') {
    if (issue.status === 'In progress') return document;
    next.status = 'In progress';
    next.events.push(documentIssueEvent(actor, 'Review started', 'MESO Worker is reviewing the reported issue.'));
  } else if (command.type === 'organization') {
    if (!command.organizationId || command.organizationId === document.company_id) throw new Error('Select a different organization.');
    if (['transferred', 'exported', 'posted', 'paid'].includes(String(document.status).toLowerCase())) throw new Error('Reverse the accounting transfer through the normal accounting process before changing this organization.');
    // Company-specific accounting references must be validated again for the new organization.
    const clearLines = (lines: unknown) => Array.isArray(lines) ? lines.map(line => ({ ...line, expense: '', vatClass: '', department: '', object: '', center: '' })) : lines;
    patch = { company_id: command.organizationId, status: 'Correcting', expense_account: '', vat_classifier: '', department_code: '', object_project: '', cost_center: '', accountable_responsible: '', line_items: clearLines(document.line_items), summary_line_items: clearLines(document.summary_line_items) };
    next.status = 'In progress';
    next.blocksApproval = true;
    next.events.push(documentIssueEvent(actor, 'Organization corrected', `${document.company_id} → ${command.organizationId}. ${command.note.trim()} Company-specific accounting references require validation.`));
  } else if (command.type === 'request-ocr') {
    patch = { ocr_rerun_request: { id: crypto.randomUUID(), requestedAt: new Date().toISOString(), requestedBy: actor, issueId: issue.id, status: 'Pending integration' } };
    next.events.push(documentIssueEvent(actor, 'OCR rerun requested', command.note.trim()));
  } else {
    next.status = 'Resolved'; next.resolution = command.note.trim(); next.resolvedAt = new Date().toISOString();
    next.events.push(documentIssueEvent(actor, 'Resolved', next.resolution));
  }
  return { ...document, ...patch, digitization_issues: issues.map(item => item.id === issue.id ? next : item) };
}
