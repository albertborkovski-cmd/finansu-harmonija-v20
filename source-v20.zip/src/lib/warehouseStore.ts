import { canEditMenu, canViewMenu, parseSession } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import { canAccessAssignedOrganization } from './linkedSettingsData';
import type { Company } from './supabase';
import { createWarehouseExamples, type WarehouseStore } from './warehouse';

export const WAREHOUSE_CHANGED = 'finansu-harmonija:warehouse-changed';
export const warehouseStorageKey = (companyId: string) => `finansu-harmonija:v20:warehouse:${companyId}`;
export function warehousePermissions(company: Company) {
  const session = parseSession(localStorage.getItem(AUTH_SESSION_KEY));
  const accessible = Boolean(session && canAccessAssignedOrganization(company, session));
  return { view: Boolean(accessible && session && canViewMenu(session, 'documents')), edit: Boolean(accessible && session && canEditMenu(session, 'documents')) };
}
export function loadWarehouse(companyId: string): WarehouseStore {
  const raw = localStorage.getItem(warehouseStorageKey(companyId));
  if (raw === null) return createWarehouseExamples(companyId);
  const value = JSON.parse(raw) as WarehouseStore;
  if (value.version !== 1 || value.companyId !== companyId || !['items', 'locations', 'documents', 'prices', 'contracts', 'revaluations', 'audit'].every(key => Array.isArray(value[key as keyof WarehouseStore]))) throw new Error('Warehouse data could not be read. Existing data has not been overwritten.');
  if ([...value.items, ...value.locations, ...value.documents, ...value.prices, ...value.contracts].some(row => row.companyId !== companyId)) throw new Error('Warehouse data contains a different company scope.');
  return value;
}
/** Reads the latest saved version at action time; never silently replaces damaged history. */
export function updateWarehouse(company: Company, change: (store: WarehouseStore) => WarehouseStore) {
  if (!warehousePermissions(company).edit) throw new Error('You do not have permission to change this company’s warehouse.');
  const next = change(loadWarehouse(company.id));
  if (next.companyId !== company.id) throw new Error('Company scope cannot be changed.');
  localStorage.setItem(warehouseStorageKey(company.id), JSON.stringify(next));
  window.dispatchEvent(new CustomEvent(WAREHOUSE_CHANGED, { detail: { companyId: company.id } }));
  return next;
}

