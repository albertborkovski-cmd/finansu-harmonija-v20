import type { OrganizationEmailTemplate } from './organizationEmail';

export const VAT_TEMPLATE_TOKENS = ['company', 'recipient', 'periodFrom', 'periodTo', 'vatSummary', 'message'] as const;
export const VAT_EMAIL_TEMPLATES: OrganizationEmailTemplate[] = [
  { id: 'vat-confirmation-en', name: 'VAT reconciliation · Request confirmation', language: 'EN', active: true,
    subject: 'VAT reconciliation · {{company}} · {{periodFrom}} — {{periodTo}}',
    body: 'Hello {{recipient}},\n\nPlease review the VAT summary for {{company}} for {{periodFrom}} — {{periodTo}} and reply to confirm agreement or explain any differences.\n\n{{vatSummary}}\n\n{{message}}\n\nThank you.' },
  { id: 'vat-information-en', name: 'VAT reconciliation · Inform client', language: 'EN', active: true,
    subject: 'VAT information · {{company}} · {{periodFrom}} — {{periodTo}}',
    body: 'Hello {{recipient}},\n\nPlease find the VAT summary for {{company}} for {{periodFrom}} — {{periodTo}}. Please reply if corrections or missing documents are required.\n\n{{vatSummary}}\n\n{{message}}\n\nThank you.' },
];

export function renderVatTemplate(value: string, data: Record<typeof VAT_TEMPLATE_TOKENS[number], string>) {
  return value.replace(/\{\{(\w+)\}\}/g, (token, name: string) => name in data ? data[name as keyof typeof data] : token);
}

export function validateVatTemplate(template: Pick<OrganizationEmailTemplate, 'name' | 'subject' | 'body'>) {
  if (!template.name.trim() || !template.subject.trim() || !template.body.trim()) return 'Template name, subject and message are required.';
  const unknown = `${template.subject}\n${template.body}`.match(/\{\{\w+\}\}/g)?.find(token => !VAT_TEMPLATE_TOKENS.includes(token.slice(2, -2) as typeof VAT_TEMPLATE_TOKENS[number]));
  return unknown ? `Unsupported placeholder: ${unknown}` : '';
}
