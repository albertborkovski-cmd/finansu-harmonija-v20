export const LEARNING_MIN_DOCUMENTS = 2;
export const LEARNING_MIN_CONSISTENCY = 0.9;
export const LEARNING_FIELDS = { expense_account: 'Expense account', vat_classifier: 'VAT classifier' } as const;
export type LearningField = keyof typeof LEARNING_FIELDS;
export type LearningActor = { name: string; email: string };
export type LearningContext = { companyId: string; companyName: string; supplierKey: string; supplierName: string; vatRate: string };
export type LearningEvidence = LearningContext & {
  id: string; documentId: string; documentName: string; field: LearningField; value: string;
  confirmedAt: string; confirmedBy: LearningActor; active: boolean; sample?: boolean;
  retiredAt?: string; retiredBy?: LearningActor; retirementReason?: 'Corrected' | 'Forgotten';
};
export type LearningControl = { paused: boolean; changedAt: string; changedBy: LearningActor };
export type LearningAudit = { id: string; action: 'Confirmed' | 'Paused' | 'Resumed' | 'Forgotten'; pairKey: string; evidenceId?: string; at: string; actor: LearningActor };
export type LearningStore = { version: 1; evidence: LearningEvidence[]; controls: Record<string, LearningControl>; audit: LearningAudit[] };
export type LearnedRow = LearningContext & {
  id: string; field: LearningField; value: string; count: number; total: number; consistency: number;
  lastSeen: string; status: 'Used automatically' | 'Needs review' | 'Paused' | 'Inactive';
  candidates: { value: string; count: number }[]; evidence: LearningEvidence[]; control?: LearningControl; sample: boolean;
};

export const emptyLearningStore = (): LearningStore => ({ version: 1, evidence: [], controls: {}, audit: [] });
export const normalizeVatRate = (value: string) => {
  const trimmed = value.trim().replace('%', '').replace(',', '.');
  const number = Number(trimmed);
  return trimmed !== '' && Number.isFinite(number) ? String(number) : trimmed;
};
const supplier = (value: string) => value.trim().toLocaleLowerCase();
export const learningPairKey = (context: Pick<LearningContext, 'companyId' | 'supplierKey'>, field: LearningField) =>
  JSON.stringify([context.companyId, supplier(context.supplierKey), field]);
export const learningGroupKey = (context: LearningContext, field: LearningField, sample = false) =>
  JSON.stringify([context.companyId, supplier(context.supplierKey), field, normalizeVatRate(context.vatRate), sample]);

export function learnedRows(store: LearningStore): LearnedRow[] {
  const groups = new Map<string, LearningEvidence[]>();
  for (const item of store.evidence) {
    const key = learningGroupKey(item, item.field, Boolean(item.sample));
    groups.set(key, [...(groups.get(key) ?? []), item]);
  }
  return [...groups].map(([id, history]) => {
    const evidence = [...history].sort((a, b) => b.confirmedAt.localeCompare(a.confirmedAt) || b.id.localeCompare(a.id));
    // A reviewed document contributes once, even after repeated confirmation.
    const documents = new Map<string, LearningEvidence>();
    for (const item of evidence) if (item.active && !documents.has(item.documentId)) documents.set(item.documentId, item);
    const counts = new Map<string, number>();
    for (const item of documents.values()) counts.set(item.value, (counts.get(item.value) ?? 0) + 1);
    const candidates = [...counts].map(([value, count]) => ({ value, count })).sort((a, b) => b.count - a.count || a.value.localeCompare(b.value));
    const first = evidence[0];
    const count = candidates[0]?.count ?? 0;
    const total = documents.size;
    const consistency = total ? count / total : 0;
    const control = store.controls[learningPairKey(first, first.field)];
    const status = control?.paused ? 'Paused' : total === 0 ? 'Inactive'
      : total >= LEARNING_MIN_DOCUMENTS && consistency >= LEARNING_MIN_CONSISTENCY ? 'Used automatically' : 'Needs review';
    return { ...first, id, value: candidates[0]?.value ?? '', count, total, consistency, lastSeen: first.confirmedAt, status,
      candidates, evidence, control, sample: Boolean(first.sample) } as LearnedRow;
  }).sort((a, b) => b.lastSeen.localeCompare(a.lastSeen) || a.id.localeCompare(b.id));
}

export function confirmLearning(store: LearningStore, input: Omit<LearningEvidence, 'id' | 'active' | 'retiredAt' | 'retiredBy' | 'retirementReason'>): LearningStore {
  const value = input.value.trim();
  if (!input.companyId || !input.supplierKey.trim() || !input.documentId || !value) return store;
  const sameDocument = (item: LearningEvidence) => item.companyId === input.companyId && item.documentId === input.documentId && item.field === input.field && Boolean(item.sample) === Boolean(input.sample);
  const previous = store.evidence.find(item => item.active && sameDocument(item));
  if (previous && previous.value === value && learningGroupKey(previous, previous.field) === learningGroupKey(input, input.field)) return store;
  const id = `${input.documentId}:${input.field}:${input.confirmedAt}:${store.evidence.length}`;
  const item: LearningEvidence = { ...input, supplierKey: input.supplierKey.trim(), vatRate: normalizeVatRate(input.vatRate), value, id, active: true };
  return { ...store,
    evidence: [...store.evidence.map(old => old.active && sameDocument(old) ? { ...old, active: false, retiredAt: input.confirmedAt, retiredBy: input.confirmedBy, retirementReason: 'Corrected' as const } : old), item],
    audit: [...store.audit, { id: `confirm:${id}`, action: 'Confirmed', pairKey: learningPairKey(item, item.field), evidenceId: id, at: item.confirmedAt, actor: item.confirmedBy }],
  };
}

export function setLearningPaused(store: LearningStore, row: Pick<LearnedRow, 'companyId' | 'supplierKey' | 'field'>, paused: boolean, actor: LearningActor, at: string): LearningStore {
  const pairKey = learningPairKey(row, row.field);
  return { ...store, controls: { ...store.controls, [pairKey]: { paused, changedAt: at, changedBy: actor } },
    audit: [...store.audit, { id: `pause:${at}:${store.audit.length}`, action: paused ? 'Paused' : 'Resumed', pairKey, at, actor }] };
}

/** Forget removes evidence from learning, not the linked document or its history. */
export function forgetLatestLearning(store: LearningStore, rowId: string, actor: LearningActor, at: string, administrator: boolean): LearningStore {
  if (!administrator) return store;
  const row = learnedRows(store).find(item => item.id === rowId);
  const latest = row?.evidence.find(item => item.active);
  if (!latest) return store;
  return { ...store, evidence: store.evidence.map(item => item.id === latest.id ? { ...item, active: false, retiredAt: at, retiredBy: actor, retirementReason: 'Forgotten' } : item),
    audit: [...store.audit, { id: `forget:${at}:${store.audit.length}`, action: 'Forgotten', pairKey: learningPairKey(latest, latest.field), evidenceId: latest.id, at, actor }] };
}

export function automaticLearningValue(store: LearningStore, context: LearningContext, field: LearningField): LearnedRow | undefined {
  if (!context.companyId || !context.supplierKey.trim()) return undefined;
  return learnedRows(store).find(row => !row.sample && row.id === learningGroupKey(context, field) && row.status === 'Used automatically');
}

export function createLearningExamples(): LearningStore {
  let store = emptyLearningStore();
  const examples = [
    { supplierKey: '134678891', supplierName: 'Northwind Supplies', vatRate: '0', values: ['6202', '6202'], vat: ['PVM1', 'PVM1'] },
    { supplierKey: '305123456', supplierName: 'Baltic Office', vatRate: '21', values: ['6300', '6300', '6300', '6202', '6202'], vat: [] },
    { supplierKey: '302987654', supplierName: 'River Tech', vatRate: '21', values: ['6110'], vat: [] },
    { supplierKey: '301112233', supplierName: 'Amber Services', vatRate: '21', values: Array.from({ length: 10 }, (_, i) => i === 9 ? '6202' : '6300'), vat: [] },
  ];
  for (const example of examples) {
    for (const [field, values] of [['expense_account', example.values], ['vat_classifier', example.vat]] as const) {
      values.forEach((value, i) => {
        store = confirmLearning(store, { companyId: 'sample-learning-company', companyName: 'Sample company', supplierKey: example.supplierKey,
          supplierName: example.supplierName, vatRate: example.vatRate, field, value, sample: true,
          documentId: `sample-${example.supplierKey}-${i + 1}`, documentName: `INV-${example.supplierKey.slice(-3)}-${String(i + 1).padStart(3, '0')}.pdf`,
          confirmedAt: `2026-10-${String(20 + i % 8).padStart(2, '0')}T11:${String(10 + i).padStart(2, '0')}:00.000Z`,
          confirmedBy: { name: i % 2 ? 'Jonas' : 'Aurika', email: '' } });
      });
    }
  }
  return store;
}
