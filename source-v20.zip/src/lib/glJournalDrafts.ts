import type { GlJournalRow } from './glJournal';
import type { RevaluationReport } from './glJournalRevaluation';

export type JournalSourceMode = 'test' | 'company';
export type JournalAnalytics = { object?: string; department?: string; employee?: string; vehicle?: string };
export const JOURNAL_ANALYTICS_KEYS = ['object', 'department', 'employee', 'vehicle'] as const;
export type JournalDraftLine = JournalAnalytics & { id: string; account: string; counterparty: string; costCenter: string; debit: string; credit: string; comment: string };
export type JournalDraft = { number: string; date: string; currency: string; note: string; copiedFromId?: string; documentAnalytics?: JournalAnalytics; lines: JournalDraftLine[] };
export type SavedJournalEntry = {
  id: string; companyId: string; sourceMode: JournalSourceMode; number: string; date: string; currency: string; note: string;
  copiedFromId?: string; createdAt: string; createdBy: string; status: 'Draft';
  documentAnalytics?: JournalAnalytics;
  sourceDocumentId?: string; revision?: number; updatedAt?: string; updatedBy?: string;
  inactive?: boolean; deactivatedAt?: string; deactivatedBy?: string;
  history?: { changedAt: string; changedBy: string; before: JournalDraft }[];
  revaluation?: RevaluationReport;
  lines: (JournalAnalytics & { id: string; account: string; accountName: string; counterparty: string; costCenter: string; debitMinor: number; creditMinor: number; comment: string })[];
};
export type JournalAccountOption = { code: string; name: string; type?: string; calculateExchangeDifferences?: boolean; active?: boolean };
export const JOURNAL_DRAFT_STORAGE_PREFIX = 'finansu-harmonija:v19:gl-journal-drafts:';

export function journalDraftStorageKey(companyId: string, mode: JournalSourceMode) {
  return `${JOURNAL_DRAFT_STORAGE_PREFIX}${mode}:${encodeURIComponent(companyId)}`;
}
export function parseJournalMinor(value: string): number | null {
  const normalized = value.trim().replace(',', '.');
  if (!normalized) return 0;
  if (!/^\d+(?:\.\d{1,2})?$/.test(normalized)) return null;
  const [whole, decimals = ''] = normalized.split('.');
  const minor = Number(whole) * 100 + Number(decimals.padEnd(2, '0'));
  return Number.isSafeInteger(minor) ? minor : null;
}
export function draftJournalTotals(draft: JournalDraft) {
  return draft.lines.reduce((total, line) => ({ debit: total.debit + (parseJournalMinor(line.debit) || 0), credit: total.credit + (parseJournalMinor(line.credit) || 0) }), { debit: 0, credit: 0 });
}
export function journalDraftError(draft: JournalDraft, accounts: JournalAccountOption[], existingNumbers: string[]) {
  if (!draft.number.trim()) return 'Enter a document number.';
  if (existingNumbers.some(number => number.trim().toLocaleLowerCase() === draft.number.trim().toLocaleLowerCase())) return 'This document number already exists. Enter a new number.';
  const date = new Date(`${draft.date}T12:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(draft.date) || !Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== draft.date) return 'Select a valid operation date.';
  if (!/^[A-Z]{3}$/.test(draft.currency)) return 'Select a currency.';
  if (draft.lines.length < 2) return 'Add at least one debit and one credit line.';
  for (const [index, line] of draft.lines.entries()) {
    if (!accounts.some(account => account.code === line.account)) return `Line ${index + 1}: select an active GL account.`;
    const debit = parseJournalMinor(line.debit);
    const credit = parseJournalMinor(line.credit);
    if (debit === null || credit === null) return `Line ${index + 1}: enter a non-negative amount with up to 2 decimal places.`;
    if ((debit > 0) === (credit > 0)) return `Line ${index + 1}: enter an amount on either Debit or Credit, not both.`;
  }
  const { debit, credit } = draftJournalTotals(draft);
  if (!Number.isSafeInteger(debit) || !Number.isSafeInteger(credit)) return 'The journal total is too large.';
  if (debit !== credit) return 'Debit and credit totals must be equal.';
  return '';
}

export function nextJournalNumber(rows: GlJournalRow[], date: string) {
  const prefix = `BZ-${date.slice(0, 4)}-`;
  const numbers = new Set(rows.map(row => row.documentNumber.toLocaleLowerCase()));
  let sequence = 1;
  while (numbers.has(`${prefix}${String(sequence).padStart(4, '0')}`.toLocaleLowerCase())) sequence++;
  return `${prefix}${String(sequence).padStart(4, '0')}`;
}
export function emptyJournalLine(id: string): JournalDraftLine {
  return { id, account: '', counterparty: '', costCenter: '', object: '', department: '', employee: '', vehicle: '', debit: '', credit: '', comment: '' };
}

/** Keep zero/empty amounts on their chosen side while a journal is being edited. */
export function journalDraftLineSide(line: JournalDraftLine): 'Debit' | 'Credit' {
  return line.credit.trim() !== '' && line.debit.trim() === '' ? 'Credit' : 'Debit';
}

export function setJournalDraftLineSide(line: JournalDraftLine, side: 'Debit' | 'Credit'): JournalDraftLine {
  const amount = journalDraftLineSide(line) === 'Credit' ? line.credit : line.debit;
  return { ...line, debit: side === 'Debit' ? amount || '0' : '', credit: side === 'Credit' ? amount || '0' : '' };
}

function analytics(line: JournalAnalytics): Required<JournalAnalytics> {
  return { object: (line.object || '').trim(), department: (line.department || '').trim(), employee: (line.employee || '').trim(), vehicle: (line.vehicle || '').trim() };
}

/** Read legacy line dimensions without silently choosing between conflicting values. */
export function journalDocumentAnalytics(draft: JournalDraft) {
  const values = analytics(draft.documentAnalytics || {});
  const conflicts: (typeof JOURNAL_ANALYTICS_KEYS[number])[] = [];
  if (!draft.documentAnalytics) for (const key of JOURNAL_ANALYTICS_KEYS) {
    const distinct = [...new Set(draft.lines.map(line => (line[key] || '').trim()).filter(Boolean))];
    if (distinct.length > 1) conflicts.push(key);
    else values[key] = distinct[0] || '';
  }
  return { values, conflicts };
}

export function applyJournalDocumentAnalytics(draft: JournalDraft, values: JournalAnalytics): JournalDraft {
  const documentAnalytics = analytics(values);
  return { ...draft, documentAnalytics, lines: draft.lines.map(line => ({ ...line, ...documentAnalytics })) };
}
export function newJournalDraft(number: string, date: string, currency: string): JournalDraft {
  return { number, date, currency, note: '', lines: [emptyJournalLine('line-1'), emptyJournalLine('line-2')] };
}

/** Copy the whole document from unfiltered rows, without its identity or posting status. */
export function copyJournalDraft(source: GlJournalRow[], documentId: string, number: string, date: string): JournalDraft {
  const entries = source.filter(row => row.document.id === documentId);
  if (!entries.length) throw new Error('Select a journal entry to copy.');
  const currencies = new Set(entries.map(row => row.document.currency || 'EUR'));
  if (currencies.size !== 1) throw new Error('This document uses multiple currencies. Create a separate journal entry for each currency.');
  const lines = entries.flatMap(row => {
    const base = { ...analytics(row), account: row.account, counterparty: row.counterparty === '—' ? '' : row.counterparty, costCenter: row.costCenter === '—' ? '' : row.costCenter, comment: row.description || '' };
    // Legacy combined rows are split into separate debit and credit lines.
    return [
      ...(row.debit > 0 ? [{ ...base, id: `copy-${row.id}-d`, debit: row.debit.toFixed(2), credit: '' }] : []),
      ...(row.credit > 0 ? [{ ...base, id: `copy-${row.id}-c`, debit: '', credit: row.credit.toFixed(2) }] : []),
    ];
  });
  return { number, date, currency: [...currencies][0], note: entries[0].document.note || '', copiedFromId: documentId, lines };
}

export function editJournalDraft(source: GlJournalRow[], documentId: string): JournalDraft {
  const entries = source.filter(row => row.document.id === documentId);
  if (!entries.length) throw new Error('This journal entry is no longer available.');
  if (entries.some(row => row.debit > 0 && row.credit > 0)) throw new Error('Edit this operation in its source document.');
  if (new Set(entries.map(row => row.document.currency)).size !== 1) throw new Error('Edit each currency in its source document.');
  return {
    number: entries[0].documentNumber, date: entries[0].operationDate, currency: entries[0].document.currency, note: entries[0].document.note || '',
    lines: entries.map(row => ({ ...analytics(row), id: row.id, account: row.account, counterparty: row.counterparty === '—' ? '' : row.counterparty,
      costCenter: row.costCenter === '—' ? '' : row.costCenter, debit: row.debit ? row.debit.toFixed(2) : '', credit: row.credit ? row.credit.toFixed(2) : '', comment: row.description || '' })),
  };
}

export function loadJournalDrafts(storage: Pick<Storage, 'getItem'>, companyId: string, mode: JournalSourceMode): SavedJournalEntry[] {
  const parsed: unknown = JSON.parse(storage.getItem(journalDraftStorageKey(companyId, mode)) || '[]');
  if (!Array.isArray(parsed) || !parsed.every(entry => entry && entry.companyId === companyId && entry.sourceMode === mode && entry.status === 'Draft'
    && (entry.documentAnalytics === undefined || (entry.documentAnalytics && typeof entry.documentAnalytics === 'object' && JOURNAL_ANALYTICS_KEYS.every(key => entry.documentAnalytics[key] === undefined || typeof entry.documentAnalytics[key] === 'string')))
    && (entry.inactive === undefined || typeof entry.inactive === 'boolean')
    && ['id', 'number', 'date', 'currency', 'note', 'createdAt', 'createdBy'].every(key => typeof entry[key] === 'string')
    && Array.isArray(entry.lines) && entry.lines.every((line: SavedJournalEntry['lines'][number]) => line && ['id', 'account', 'accountName', 'counterparty', 'costCenter', 'comment'].every(key => typeof line[key as keyof typeof line] === 'string')
      && ['object', 'department', 'employee', 'vehicle'].every(key => line[key as keyof typeof line] === undefined || typeof line[key as keyof typeof line] === 'string')
      && Number.isSafeInteger(line.debitMinor) && line.debitMinor >= 0 && Number.isSafeInteger(line.creditMinor) && line.creditMinor >= 0))) {
    throw new Error('Saved journal drafts could not be read. Existing data has not been changed.');
  }
  return parsed as SavedJournalEntry[];
}

export function saveJournalDraft(storage: Pick<Storage, 'getItem' | 'setItem'>, context: {
  companyId: string; mode: JournalSourceMode; id: string; createdAt: string; createdBy: string;
  revaluation?: RevaluationReport;
}, draft: JournalDraft, accounts: JournalAccountOption[], sourceNumbers: string[], beforeSave?: (entry: SavedJournalEntry) => void) {
  const existing = loadJournalDrafts(storage, context.companyId, context.mode);
  const error = journalDraftError(draft, accounts, [...sourceNumbers, ...existing.map(entry => entry.number)]);
  if (error) throw new Error(error);
  if (existing.some(entry => entry.id === context.id)) throw new Error('This journal entry was already saved.');
  const entry: SavedJournalEntry = {
    id: context.id, companyId: context.companyId, sourceMode: context.mode, number: draft.number.trim(), date: draft.date, currency: draft.currency,
    note: draft.note.trim(), copiedFromId: draft.copiedFromId, ...(draft.documentAnalytics ? { documentAnalytics: analytics(draft.documentAnalytics) } : {}), status: 'Draft', createdAt: context.createdAt, createdBy: context.createdBy,
    ...(context.revaluation ? { revaluation: context.revaluation } : {}),
    lines: draft.lines.map((line, index) => ({ ...analytics(draft.documentAnalytics || line), id: `${context.id}:${index + 1}`, account: line.account, accountName: accounts.find(account => account.code === line.account)!.name,
      counterparty: line.counterparty.trim(), costCenter: line.costCenter.trim(), debitMinor: parseJournalMinor(line.debit)!, creditMinor: parseJournalMinor(line.credit)!, comment: line.comment.trim() })),
  };
  beforeSave?.(entry);
  storage.setItem(journalDraftStorageKey(context.companyId, context.mode), JSON.stringify([...existing, entry]));
  return entry;
}

export function journalDraftRows(entries: SavedJournalEntry[], activeAccounts: Set<string>): GlJournalRow[] {
  return entries.flatMap(entry => {
    const balanced = entry.lines.reduce((sum, line) => sum + line.debitMinor - line.creditMinor, 0) === 0;
    return entry.lines.map(line => ({
      id: line.id, documentNumber: entry.number, internalNumber: entry.number, operationDate: entry.date,
      counterparty: line.counterparty || '—', account: line.account, accountName: line.accountName, description: line.comment || entry.note,
      documentType: 'Accounting note', documentSubtype: 'Journal entry', costCenter: line.costCenter || '—',
      ...analytics(entry.documentAnalytics || line), createdBy: entry.createdBy, createdAt: entry.createdAt, inactive: entry.inactive,
      postingStatus: 'Unposted', debit: line.debitMinor / 100, credit: line.creditMinor / 100, total: Math.max(line.debitMinor, line.creditMinor) / 100,
      accountActive: activeAccounts.has(line.account), posted: false, balanced, sample: entry.sourceMode === 'test',
      document: { id: entry.id, number: entry.number, currency: entry.currency, status: 'Draft', documentType: 'Accounting note', source: entry.sourceMode === 'test' ? 'Local test journal' : 'Manual journal', documentDate: entry.date, note: entry.note },
    }));
  });
}

/** Local test edits replace their displayed source, never duplicate or write to real documents. */
export function mergeJournalRows(source: GlJournalRow[], entries: SavedJournalEntry[], activeAccounts: Set<string>): GlJournalRow[] {
  const replaced = new Set(entries.filter(entry => entry.sourceMode === 'test' && entry.sourceDocumentId === entry.id).map(entry => entry.id));
  const editedRows = entries.flatMap(entry => {
    const original = replaced.has(entry.id) ? source.find(row => row.document.id === entry.id && row.sample) : undefined;
    return journalDraftRows([entry], activeAccounts).map(row => original ? {
      ...row, internalNumber: original.internalNumber, documentType: original.documentType, documentSubtype: original.documentSubtype,
      posted: original.posted, postingStatus: original.postingStatus,
      document: { ...original.document, ...row.document, documentType: original.document.documentType, status: original.document.status, source: original.document.source },
    } : row);
  });
  const inserted = new Set<string>();
  const result = source.flatMap(row => {
    if (!row.sample || !replaced.has(row.document.id)) return [row];
    if (inserted.has(row.document.id)) return [];
    inserted.add(row.document.id);
    return editedRows.filter(edited => edited.document.id === row.document.id);
  });
  return [...result, ...editedRows.filter(row => !inserted.has(row.document.id))];
}

export function updateJournalDraft(storage: Pick<Storage, 'getItem' | 'setItem'>, context: {
  companyId: string; mode: JournalSourceMode; id: string; expectedRevision: number | null; changedAt: string; changedBy: string;
}, draft: JournalDraft, accounts: JournalAccountOption[], source: GlJournalRow[], beforeSave?: (previous: JournalDraft, next: SavedJournalEntry) => void) {
  const existing = loadJournalDrafts(storage, context.companyId, context.mode);
  const previous = existing.find(entry => entry.id === context.id);
  if (previous?.inactive) throw new Error('Inactive journal entries cannot be edited. Copy the entry to create a new one.');
  if ((previous ? previous.revision || 0 : null) !== context.expectedRevision) throw new Error('This entry changed in another window. Close and reopen it before saving.');
  const original = source.filter(row => row.document.id === context.id);
  if (!previous && (context.mode !== 'test' || !original.length || original.some(row => !row.sample))) throw new Error('Edit this operation in its source document.');
  const currentRows = previous ? journalDraftRows([previous], new Set(accounts.map(account => account.code))) : original;
  const currentSource = mergeJournalRows(source, existing, new Set(accounts.map(account => account.code)));
  const error = journalDraftError(draft, accounts, currentSource.filter(row => row.document.id !== context.id).map(row => row.documentNumber));
  if (error) throw new Error(error);
  if (new Set(draft.lines.map(line => line.id)).size !== draft.lines.length) throw new Error('Journal line identifiers must be unique.');
  const before = editJournalDraft(currentRows, context.id);
  const entry: SavedJournalEntry = {
    ...previous, id: context.id, companyId: context.companyId, sourceMode: context.mode,
    sourceDocumentId: previous?.sourceDocumentId || (!previous ? context.id : undefined),
    number: draft.number.trim(), date: draft.date, currency: draft.currency, note: draft.note.trim(), status: 'Draft',
    documentAnalytics: draft.documentAnalytics && analytics(draft.documentAnalytics),
    createdAt: previous?.createdAt || original[0]?.createdAt || context.changedAt, createdBy: previous?.createdBy || original[0]?.createdBy || context.changedBy,
    updatedAt: context.changedAt, updatedBy: context.changedBy, revision: (previous?.revision || 0) + 1,
    history: [...previous?.history || [], { changedAt: context.changedAt, changedBy: context.changedBy, before }],
    lines: draft.lines.map(line => ({ ...analytics(draft.documentAnalytics || line), id: line.id, account: line.account, accountName: accounts.find(account => account.code === line.account)!.name,
      counterparty: line.counterparty.trim(), costCenter: line.costCenter.trim(), debitMinor: parseJournalMinor(line.debit)!, creditMinor: parseJournalMinor(line.credit)!, comment: line.comment.trim() })),
  };
  beforeSave?.(before, entry);
  storage.setItem(journalDraftStorageKey(context.companyId, context.mode), JSON.stringify(previous ? existing.map(item => item.id === entry.id ? entry : item) : [...existing, entry]));
  return entry;
}
