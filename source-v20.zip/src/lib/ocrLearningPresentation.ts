import { LEARNING_FIELDS, LEARNING_MIN_CONSISTENCY, LEARNING_MIN_DOCUMENTS, type LearnedRow } from './ocrLearning';

// A column is not evidence of learning. Only an explicitly matching confirmed
// field may supply its value; identity/context and extracted text never do.
export const LEARNING_VALUE_COLUMNS = [
  { key: 'expense_account', label: 'Expense account', width: 160 },
  { key: 'vat_classifier', label: 'VAT classifier', width: 150 },
] as const;

export function learnedColumnValue(row: LearnedRow, key: string): string {
  return (key === 'value' || key === `learned:${row.field}`) && row.total > 0 ? row.value : '';
}

// Reconcile saved layouts with the current column catalogue without resetting
// the remaining columns' order, sizing or visibility.
export function restoreLearningColumns<T extends { key: string; visible: boolean }>(stored: T[], defaults: T[]): T[] {
  const definitions = new Map(defaults.map(column => [column.key, column]));
  const seen = new Set<string>();
  const restored: T[] = [];
  for (const column of stored) {
    const definition = definitions.get(column.key);
    if (!definition || seen.has(column.key)) continue;
    restored.push({ ...definition, ...column });
    seen.add(column.key);
  }
  for (const [index, column] of defaults.entries()) {
    if (seen.has(column.key)) continue;
    const following = defaults.slice(index + 1).find(candidate => seen.has(candidate.key));
    const insertAt = following ? restored.findIndex(candidate => candidate.key === following.key) : restored.length;
    restored.splice(insertAt, 0, column);
    seen.add(column.key);
  }
  return restored;
}

export const LEARNING_STATUS_FILTERS = [
  { value: '', label: 'All values' },
  { value: 'Needs review', label: 'Needs review' },
  { value: 'Used automatically', label: 'Ready for auto-fill' },
  { value: 'Paused', label: 'Paused' },
  { value: 'Inactive', label: 'Inactive' },
] as const;

export function learningStatusLabel(row: LearnedRow): string {
  if (row.status !== 'Used automatically') return row.status;
  return row.sample ? 'Ready · example' : 'Automatic';
}

export function learningStatusReason(row: LearnedRow): string {
  if (row.status === 'Paused') return 'Automatic filling is paused for this company, supplier and field.';
  if (row.status === 'Inactive') return 'No active teaching documents remain. History is retained.';
  if (row.total < LEARNING_MIN_DOCUMENTS) return `${row.total} of ${LEARNING_MIN_DOCUMENTS} required documents. The field is left for a person.`;
  if (row.consistency < LEARNING_MIN_CONSISTENCY) return `${Math.round(row.consistency * 100)}% agreement is below the ${LEARNING_MIN_CONSISTENCY * 100}% threshold. The field is left for a person.`;
  return row.sample
    ? 'This example meets the thresholds, but never fills real documents.'
    : 'The most frequently confirmed value will be filled automatically.';
}

export function learningFilterValue(row: LearnedRow, key: string): string {
  if (key === 'companyName') return row.companyId;
  if (key === 'supplierKey') return row.supplierKey;
  if (key === 'field') return row.field;
  if (key === 'vatRate') return row.vatRate;
  if (key === 'value') return row.value;
  return '';
}

export function filterLearningRows(rows: LearnedRow[], query: string, filters: Record<string, string[]>): LearnedRow[] {
  const search = query.trim().toLocaleLowerCase();
  return rows.filter(row => {
    if (Object.entries(filters).some(([key, values]) => values.length && !values.includes(learningFilterValue(row, key)))) return false;
    return !search || [row.companyName, row.supplierKey, row.supplierName, LEARNING_FIELDS[row.field], row.value,
      row.status, learningStatusLabel(row), ...row.candidates.map(candidate => candidate.value)]
      .some(value => value.toLocaleLowerCase().includes(search));
  });
}
