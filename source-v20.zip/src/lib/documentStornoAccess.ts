import { canEditMenu, canViewMenu, isSystemAdministratorRole, parseSession } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import { canAccessAssignedOrganization } from './linkedSettingsData';
import { isInactiveRecord } from './recordLifecycle';
import type { StornoPeriodPolicy } from './documentStorno';

type CompanyScope = { id: string; name: string; assigned_accountant?: string };
const PREFIX = 'finansu-harmonija:v7:settings:';

export function canViewStornoDocument(company: CompanyScope) {
  try {
    const session = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
    return Boolean(session && canAccessAssignedOrganization(company, session) && canViewMenu(session, 'documents'));
  } catch { return false; }
}

/** Re-resolve current roles at action time, rather than trusting the open form. */
export function canStornoDocument(company: CompanyScope) {
  try {
    const session = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
    if (!session || !canAccessAssignedOrganization(company, session) || !canViewMenu(session, 'documents') || !canEditMenu(session, 'documents')) return false;
    if (session.roleNames.some(isSystemAdministratorRole)) return true;
    const assignedRoles: { name: string; actionPermissions?: string; permissions?: string }[] = [];
    for (const audience of ['internal', 'external']) {
      const rows = JSON.parse(window.localStorage.getItem(`${PREFIX}${audience}:roles`) || '[]');
      if (!Array.isArray(rows)) return false;
      assignedRoles.push(...rows.filter(role => session.roleNames.includes(role.name) && !isInactiveRecord(role)));
    }
    // The built-in accountant role grants all document actions until customized.
    if (!assignedRoles.length) return session.roleNames.includes('Meso accountant');
    const actions = new Set(assignedRoles.flatMap(role => {
      const config = role.actionPermissions ? JSON.parse(role.actionPermissions) : null;
      return config ? config.documents ?? [] : (role.permissions ?? '').split(',').map(value => value.trim());
    }));
    return (actions.has('VIEW') || actions.has('READ')) && (actions.has('EDIT') || actions.has('UPDATE')) && actions.has('CREATE');
  } catch { return false; }
}

/** Same assigned monthly cutoff configuration as Settings → Period locking.
 * A manual document-date override does not grant permission to reopen a period. */
export function loadStornoPeriodPolicy(companyId: string, storage: Pick<Storage, 'getItem'> = window.localStorage): StornoPeriodPolicy {
  const prefix = 'finansu-harmonija:v12:operation-date-validation:';
  const assignments = JSON.parse(storage.getItem(`${prefix}assignments`) || '{}');
  const raw = storage.getItem(`${prefix}templates`);
  const templates = raw ? JSON.parse(raw) : [
    { id: 'operation-date-standard', enabled: true, cutoffDay: 25 },
    { id: 'operation-date-early', enabled: true, cutoffDay: 20 },
    { id: 'operation-date-month-end', enabled: true, cutoffDay: 31 },
  ];
  if (!assignments || typeof assignments !== 'object' || Array.isArray(assignments) || !Array.isArray(templates)) throw new Error('The accounting period configuration could not be verified.');
  const assigned = assignments[companyId];
  const selected = templates.find(item => item.id === assigned);
  if (assigned && !selected) throw new Error('The assigned period-locking template is unavailable.');
  const legacy = JSON.parse(storage.getItem(`${prefix}${companyId}`) || 'null');
  const policy = selected ?? legacy ?? { enabled: true, cutoffDay: 25 };
  if (typeof policy.enabled !== 'boolean' || !Number.isInteger(policy.cutoffDay) || policy.cutoffDay < 1 || policy.cutoffDay > 31)
    throw new Error('The accounting period configuration could not be verified.');
  return { enabled: policy.enabled, cutoffDay: policy.cutoffDay };
}
