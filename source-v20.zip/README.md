# Finansų harmonija V20

Aktyvi tobulinimo versija iš V19 `3ad31c4b14409d9f99d0ecc9192a735af7abf4bb` (žyma `v19`). Tolesni pakeitimai atliekami tik šiame V20 projekte. V19 ir ankstesni leidimai nekeičiami.

Nekintamos V19 testavimo versijos adresas: https://albertborkovski-cmd.github.io/finansu-harmonija-v19/

## V20 testavimo leidimas

2026-11-03 paruoštas V20 leidimas skirtas atskirai `albertborkovski-cmd/finansu-harmonija-v20` saugyklai ir GitHub Pages. Testavimo adresas po publikavimo: https://albertborkovski-cmd.github.io/finansu-harmonija-v20/.

Publikuojama sukompiliuota svetainė ir tikslios šio leidimo programos išeities failų archyvas `source-v20.zip`. Publikavimo saugykla atskirta nuo vietinės išeities kodo saugyklos; jos nereikia perrašyti vietine Git istorija. V19 ir ankstesnių leidimų saugyklos nekeičiamos.

## Vietinis paleidimas

```bash
npm ci
npm run dev
```

Vietinis V20 adresas: http://127.0.0.1:5201/.
V20 turi atskirą Git saugyklą be V19 ar senesnių versijų nuotolinių adresų. Vietinis duomenų failas nukopijuotas atskirai, o naršyklės duomenys dėl atskiro prievado nesidalija su V19.

## Testavimo prisijungimas

- Vidinio administratoriaus demonstracija: `albertborkvski@gmail.com`.
- Išorinio naudotojo demonstracija: `aurika.z@meso.lt`.
- Slaptažodžio laukas šiame prototipe tikrina tik formatą: bent 6 simboliai, didžioji raidė ir specialus simbolis. Naudokite išgalvotą testinę reikšmę, ne tikrą slaptažodį.

Tai demonstracinis prototipas, ne produkcinė apskaitos sistema. GitHub Pages versijoje nėra saugaus serverinio autentifikavimo, bendros duomenų bazės, tikro OCR vykdymo ar laiškų siuntimo serverio. Demonstraciniai vaidmenys nėra saugumo riba. Nenaudokite konfidencialių dokumentų ar tikrų slaptažodžių.

Vietiniai `.env`, `.meso-shared-data.json`, `node_modules` ir darbo katalogų failai nepublikuojami. Interneto versija naudoja demonstracinius ir naršyklėje saugomus duomenis. To paties GitHub Pages domeno senesni leidimai gali dalytis naršyklės saugykla; izoliuotam testavimui naudokite atskirą naršyklės profilį.

## Leidimo patikra

- `npm run typecheck` ir `npm run build` praeina.
- 2026-11-03 pilnas esamų testų paleidimas: 733 praėjo, 10 nepraėjo. Nepraėję senesni UI testai turi `import.meta` / CommonJS bei `useWorkspaceExpansion` testinių priklausomybių neatitikimų. Šis leidimas išsaugo dabartinę naudotojo testuojamą programos versiją.
- 111 tikslinių Warehouse, OCR mokymosi ir dokumentų peržiūros, rolių / naudotojų, įmonės meniu, sąskaitų plano ir valiutų perskaičiavimo testų praėjo.
- Atskiros viešos nuorodos, kurioms reikalingi serverio maršrutai, statiniame GitHub Pages prototipe gali neveikti.

## Dokumento Storno (vietinis V20)

`Companies → Documents → dokumento detalizacija → Storno` sukuria vienos patvirtintos DK operacijos priešingą operaciją. Masinio stornavimo nėra. Originali operacija ir jos apskaitiniai dokumento laukai lieka nekintami; reversas, pirminės operacijos / eilučių ID, data, priežastis, autorius ir autoritetinga istorija išsaugomi vienu dokumento įrašo pakeitimu. D/K ir bazinės valiutos sumos sukeičiamos tiksliai, neimant naujo valiutos kurso. Abi operacijos rodomos GL journal.

Patvirtintos operacijos sutartis: `DbDocument.accounting_posting` atitinka `PostedDocumentOperation` iš `src/lib/documentStorno.ts`. Ją turi pateikti tikras patvirtinimo / importo procesas: atskiros subalansuotos D/K eilutės, sveikais mažiausiais valiutos vienetais užregistruotos ir bazinės sumos, dokumento bei įmonės ID, operacijos ID / numeris / data, patvirtinimo autorius / laikas ir integracijos būsena. Vien dokumento būsena `Approved`, suma ar dabartinio demonstracinio GL žurnalo apskaičiuotos eilutės nėra patvirtinta operacija. Senų demonstracinių dokumentų įrašai automatiškai nesukuriami ir neperrašomi; be šios išsaugotos operacijos Storno blokuojamas.

Kontrolės: įmonės prieiga ir Documents View/Read + Edit/Update + Create teisės, pasirinkta ne būsima ir ne ankstesnė už originalą data, įmonei priskirtas Period locking mėnesio terminas (iki termino atviras ankstesnis ir dabartinis mėnuo, po termino – dabartinis), privaloma priežastis, originalo pasikeitimo ir pakartotinio stornavimo patikra. Uždaras originalo laikotarpis netrukdo reversui atvirame laikotarpyje; rankinis dokumento datos keitimo leidimas nepanaikina užrakinimo.

Išorinei apskaitos sistemai perduotos / laukiančios / neaiškios operacijos blokuojamos: kol nėra patvirtinto integracijos reverso kontrakto, nėra jokio „apeiti“ ar „laikyti išsiųsta“ pasirinkimo. Šiame prototipe nėra tikro DK registravimo ar išorinio reverso API. Produkcijoje būtina serverinė autorizacija, nekintamas DK registras, unikalumas pagal pirminę operaciją ir DB transakcija bei integracijos idempotentiškumas; naršyklės ir vietinio bendrų duomenų failo saugykla to neatstoja.

## Dokumentų laukų redagavimas sąraše (vietinis V20)

`Note`, `Document purpose`, `Order No.`, serija ir atsakingas asmuo yra dokumento lygmens laukai. Jų redagavimas nepriklauso nuo apskaitinių paskirstymų skaičiaus. DK sąskaita, PVM klasifikatorius, padalinys, objektas / projektas, kaštų centras ir produktų grupė sąraše keičiami tik turint vieną apskaitinį paskirstymą. Keli paskirstymai redaguojami esamoje `Edit` kortelėje.

Paskirstymų šaltinis – `summary_line_items` (`Summary`), o ne OCR / prekių `line_items` (`Quantity`). Senas dokumentas be Summary eilučių turi vieną dokumento lygmens paskirstymą. Tiesioginis lauko keitimas nekeičia OCR eilučių ar sumų. Išsaugojimo komanda iš naujo tikrina aktyvų naudotoją, View + Edit teises, įmonės priskyrimą, dokumento būseną, paskirstymų skaičių ir pasenusius duomenis; pakeitimai registruojami istorijoje. Tai prototipo kontrolės – produkcijoje jos turi būti įgyvendintos serveryje.
