# Finansų harmonija V20

Aktyvi tobulinimo versija iš V19 `3ad31c4b14409d9f99d0ecc9192a735af7abf4bb` (žyma `v19`). Tolesni pakeitimai atliekami tik šiame V20 projekte. V19 ir ankstesni leidimai nekeičiami.

Nekintamos V19 testavimo versijos adresas: https://albertborkovski-cmd.github.io/finansu-harmonija-v19/

## V20 testavimo leidimas

2026-11-03 paruoštas V20 leidimas skirtas atskirai `albertborkovski-cmd/finansu-harmonija-v20` saugyklai ir GitHub Pages. Testavimo adresas po publikavimo: https://albertborkovski-cmd.github.io/finansu-harmonija-v20/.

Publikuojama sukompiliuota svetainė ir tikslios šio leidimo programos išeities failų archyvas `source-v20.zip`. Publikavimo saugykla atskirta nuo vietinės išeities kodo saugyklos; jos nereikia perrašyti vietine Git istorija. V19 ir ankstesnių leidimų saugyklos nekeičiamos.

## Vietinis paleidimas

```bash
npm ci
npm run dev
```

Vietinis V20 adresas: http://127.0.0.1:5201/.
V20 turi atskirą Git saugyklą be V19 ar senesnių versijų nuotolinių adresų. Vietinis duomenų failas nukopijuotas atskirai, o naršyklės duomenys dėl atskiro prievado nesidalija su V19.

## Testavimo prisijungimas

- Vidinio administratoriaus demonstracija: `albertborkvski@gmail.com`.
- Išorinio naudotojo demonstracija: `aurika.z@meso.lt`.
- Slaptažodžio laukas šiame prototipe tikrina tik formatą: bent 6 simboliai, didžioji raidė ir specialus simbolis. Naudokite išgalvotą testinę reikšmę, ne tikrą slaptažodį.

Tai demonstracinis prototipas, ne produkcinė apskaitos sistema. GitHub Pages versijoje nėra saugaus serverinio autentifikavimo, bendros duomenų bazės, tikro OCR vykdymo ar laiškų siuntimo serverio. Demonstraciniai vaidmenys nėra saugumo riba. Nenaudokite konfidencialių dokumentų ar tikrų slaptažodžių.

Vietiniai `.env`, `.meso-shared-data.json`, `node_modules` ir darbo katalogų failai nepublikuojami. Interneto versija naudoja demonstracinius ir naršyklėje saugomus duomenis. To paties GitHub Pages domeno senesni leidimai gali dalytis naršyklės saugykla; izoliuotam testavimui naudokite atskirą naršyklės profilį.

## Leidimo patikra

- `npm run typecheck` ir `npm run build` praeina.
- 2026-11-03 pilnas esamų testų paleidimas: 733 praėjo, 10 nepraėjo. Nepraėję senesni UI testai turi `import.meta` / CommonJS bei `useWorkspaceExpansion` testinių priklausomybių neatitikimų. Šis leidimas išsaugo dabartinę naudotojo testuojamą programos versiją.
- 111 tikslinių Warehouse, OCR mokymosi ir dokumentų peržiūros, rolių / naudotojų, įmonės meniu, sąskaitų plano ir valiutų perskaičiavimo testų praėjo.
- Atskiros viešos nuorodos, kurioms reikalingi serverio maršrutai, statiniame GitHub Pages prototipe gali neveikti.
