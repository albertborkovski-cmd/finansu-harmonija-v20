import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';
const source = name => readFileSync(new URL(name, import.meta.url), 'utf8');
const compiled = ts.transpileModule(source('../src/lib/dropdownPosition.ts'), { compilerOptions: { module: ts.ModuleKind.CommonJS } }).outputText;
const api = {}; new Function('exports', compiled)(api);

test('dropdown fits below its anchor without expanding a table row', () => {
  assert.deepEqual(api.dropdownPosition({ left: 300, top: 100, bottom: 128, width: 100 }, { width: 1280, height: 720 }, 300, 400), { left: 300, width: 300, top: 132, maxHeight: 400 });
});
test('bottom/right edge dropdown stays on screen and scrolls above its anchor', () => {
  const position = api.dropdownPosition({ left: 1200, top: 650, bottom: 678, width: 100 }, { width: 1280, height: 720 }, 300, 400);
  assert.equal(position.left, 972); assert.equal(position.width, 300);
  assert.equal(position.bottom, 74); assert.equal(position.maxHeight, 400);
  assert.equal(position.top, undefined);
});
test('narrow or short screens constrain both menu width and height', () => {
  const position = api.dropdownPosition({ left: 10, top: 40, bottom: 68, width: 100 }, { width: 200, height: 180 }, 300, 400);
  assert.equal(position.left, 8); assert.equal(position.width, 184);
  assert.equal(position.top, 72); assert.equal(position.maxHeight, 100);
});
test('document menus escape clipping, retain portal-aware dismissal and refresh edit status', () => {
  const list = source('../src/components/Documents.tsx');
  const portal = source('../src/components/DropdownPortal.tsx');
  assert.match(portal, /createPortal\(/); assert.match(portal, /document.body/);
  assert.match(portal, /fixed z-\[1100\]/); assert.match(portal, /useLayoutEffect/);
  assert.match(list, /anchorRef=\{addFilterRef\} menuRef=\{addFilterMenuRef\}/);
  assert.match(list, /anchorRef=\{statusDropdownRef\} menuRef=\{statusDropdownMenuRef\}/);
  assert.match(list, /statusDropdownRef.current = e.currentTarget;/);
  assert.match(list, /useDropdownDismiss\(showAddFilterMenu[^;]+addFilterMenuRef\)/);
  assert.match(list, /useDropdownDismiss\(statusDropdownDocId[^;]+statusDropdownMenuRef\)/);
  assert.match(list, /Search available filters/);
  assert.match(list, /inlineSource: \{ \.\.\.d.inlineSource, status: newStatus \}/);
  assert.match(list, /'type', 'accountableResponsible'\]\.includes/);
});
