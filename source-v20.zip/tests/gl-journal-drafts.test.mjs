import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

async function load(name) {
  const source = ts.transpileModule(readFileSync(new URL(`../src/lib/${name}.ts`, import.meta.url), 'utf8'), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } }).outputText;
  return import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
}
const { createSampleJournalRows, buildJournalGroups, JOURNAL_GROUPINGS } = await load('glJournal');
const { parseJournalMinor, newJournalDraft, copyJournalDraft, editJournalDraft, mergeJournalRows, updateJournalDraft, journalDraftError, journalDraftLineSide, setJournalDraftLineSide, emptyJournalLine, saveJournalDraft, loadJournalDrafts, journalDraftRows, journalDraftStorageKey, nextJournalNumber } = await load('glJournalDrafts');
const rows = createSampleJournalRows('alice');
const accounts = [...new Map(rows.map(row => [row.account, { code: row.account, name: row.accountName }])).values()];
const context = { companyId: 'alice', mode: 'test', id: 'new-id', createdAt: '2026-10-12T10:00:00Z', createdBy: 'Test accountant' };
function storage() { const values = new Map(); return { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, value) }; }
const copied = () => copyJournalDraft(rows, rows[0].document.id, 'BZ-2026-0001', '2026-10-12');

test('copy includes every line of the source document and changes no source data', () => {
  const before = JSON.stringify(rows);
  const draft = copied();
  assert.equal(draft.lines.length, rows.filter(row => row.document.id === rows[0].document.id).length);
  assert.equal(draft.copiedFromId, rows[0].document.id);
  assert.equal(draft.number, 'BZ-2026-0001');
  assert.equal(draft.date, '2026-10-12');
  assert.equal(journalDraftError(draft, accounts, rows.map(row => row.documentNumber)), '');
  draft.lines[0].comment = 'Changed copy';
  assert.equal(JSON.stringify(rows), before);
});

test('saved copies receive fresh document and line identities, remain unposted and survive reload', () => {
  const s = storage(); let registered;
  const saved = saveJournalDraft(s, context, copied(), accounts, [], entry => { registered = entry.id; });
  assert.equal(registered, 'new-id');
  assert.equal(saved.status, 'Draft');
  assert.equal(saved.createdBy, 'Test accountant');
  assert.deepEqual(loadJournalDrafts(s, 'alice', 'test'), [saved]);
  const mapped = journalDraftRows([saved], new Set(accounts.map(account => account.code)));
  assert.ok(mapped.every(row => row.document.id === 'new-id' && row.postingStatus === 'Unposted' && !row.posted && row.balanced));
  assert.ok(mapped.every(row => !rows.some(original => original.id === row.id)));
  assert.equal(nextJournalNumber([...rows, ...mapped], '2026-10-12'), 'BZ-2026-0002');
});

test('new entries begin with two empty lines; users can create balanced multi-line journals', () => {
  const draft = newJournalDraft('BZ-2026-0001', '2026-10-12', 'EUR');
  assert.equal(draft.lines.length, 2);
  assert.match(journalDraftError(draft, accounts, []), /GL account/);
  draft.lines[0] = { ...draft.lines[0], account: accounts[0].code, debit: '10,10' };
  draft.lines[1] = { ...draft.lines[1], account: accounts[1].code, credit: '4.05' };
  draft.lines.push({ ...draft.lines[1], id: 'third', credit: '6.05' });
  assert.equal(journalDraftError(draft, accounts, []), '');
  const saved = saveJournalDraft(storage(), context, draft, accounts, []);
  assert.equal(saved.lines.length, 3);
  assert.equal(saved.lines.reduce((sum, line) => sum + line.debitMinor - line.creditMinor, 0), 0);
});

test('document-style editor preserves the chosen side for zero amounts and changes sides without losing amounts', () => {
  const original = { ...emptyJournalLine('test'), account: '2410', debit: '12,34', counterparty: 'Company' };
  const credit = setJournalDraftLineSide(original, 'Credit');
  assert.equal(journalDraftLineSide(credit), 'Credit');
  assert.equal(credit.credit, '12,34'); assert.equal(credit.debit, '');
  assert.equal(original.debit, '12,34'); assert.equal(original.credit, '');
  const debit = setJournalDraftLineSide(credit, 'Debit');
  assert.deepEqual(debit, original);
  assert.equal(journalDraftLineSide({ ...credit, credit: '0' }), 'Credit');
  assert.equal(journalDraftLineSide(setJournalDraftLineSide(emptyJournalLine('empty'), 'Credit')), 'Credit');
});

test('view, edit and copy share one document layout, field order, correspondence and totals', () => {
  const read = name => readFileSync(new URL(`../src/components/${name}.tsx`, import.meta.url), 'utf8');
  const view = read('GlJournalDocumentView'); const editor = read('GlJournalEntryEditor'); const layout = read('GlJournalDocumentLayout');
  for (const component of ['GlJournalDocumentLayout', 'JournalEntryHeader', 'JournalDocumentFields', 'JournalCorrespondenceTable', 'JournalDocumentTotals']) {
    assert.match(view, new RegExp(`<${component}[\\s>]`));
    assert.match(editor, new RegExp(`<${component}[\\s>]`));
  }
  assert.match(layout, /h-\[min\(900px,92vh\)\].*max-w-\[1680px\]/);
  assert.match(layout, /lg:grid-cols-\[minmax\(340px,0.85fr\)_minmax\(0,1.4fr\)\]/);
  assert.doesNotMatch(editor, /max-w-\[1400px\]|sm:grid-cols-3|mode === 'edit' && <div/);
  for (const field of ['counterparty', 'number', 'account', 'object', 'department', 'employee', 'vehicle', 'comment']) {
    assert.equal((layout.match(new RegExp(`\\['${field}',`, 'g')) || []).length, 1);
  }
  assert.match(editor, /sourceRow\?\.id/);
  assert.match(editor, /journalDraftLineSide\(line\) !== side/);
  assert.match(editor, /onSave\(applyJournalDocumentAnalytics\(draft, documentAnalytics.values\)\)/);
});

test('invalid amounts, same-line debit/credit, inactive accounts and unbalanced journals cannot be saved', () => {
  for (const mutate of [draft => { draft.lines[0].debit = '-1'; }, draft => { draft.lines[0].credit = '10'; }, draft => { draft.lines[0].debit = '1.001'; }, draft => { draft.lines[0].debit = '1'; }, draft => { draft.lines[0].account = 'inactive'; }, draft => { draft.lines = []; }]) {
    const draft = copied(); mutate(draft); const s = storage();
    assert.throws(() => saveJournalDraft(s, context, draft, accounts, []));
    assert.deepEqual(loadJournalDrafts(s, 'alice', 'test'), []);
  }
  assert.equal(parseJournalMinor('0.10'), 10);
  assert.equal(parseJournalMinor('12,34'), 1234);
  assert.equal(parseJournalMinor('1e2'), null);
  assert.equal(parseJournalMinor('9007199254740991'), null);
});

test('duplicate numbers and invalid dates are rejected, including a second-tab save', () => {
  const s = storage(); saveJournalDraft(s, context, copied(), accounts, []);
  assert.throws(() => saveJournalDraft(s, { ...context, id: 'another' }, copied(), accounts, []), /number already exists/);
  assert.match(journalDraftError({ ...copied(), number: ' pir26-08001 ' }, accounts, [rows[0].documentNumber]), /already exists/);
  assert.match(journalDraftError({ ...copied(), date: '2026-02-30' }, accounts, []), /valid operation date/);
});

test('company and test/live draft stores remain isolated', () => {
  const s = storage(); saveJournalDraft(s, context, copied(), accounts, []);
  assert.deepEqual(loadJournalDrafts(s, 'other-company', 'test'), []);
  assert.deepEqual(loadJournalDrafts(s, 'alice', 'company'), []);
});

test('corrupted stored data and failed reference registration never overwrite saved drafts', () => {
  for (const invalid of ['{', '{}', '[{}]']) {
    const s = storage(); const key = journalDraftStorageKey('alice', 'test'); s.setItem(key, invalid);
    assert.throws(() => saveJournalDraft(s, context, copied(), accounts, [])); assert.equal(s.getItem(key), invalid);
  }
  const s = storage();
  assert.throws(() => saveJournalDraft(s, context, copied(), accounts, [], () => { throw new Error('Cannot register GL usage'); }));
  assert.deepEqual(loadJournalDrafts(s, 'alice', 'test'), []);
});

test('copy rejects missing records and mixed currencies; splits legacy combined postings', () => {
  assert.throws(() => copyJournalDraft(rows, 'missing', 'new', '2026-10-12'), /Select/);
  const combined = { ...rows[0], debit: 5, credit: 5 };
  assert.equal(copyJournalDraft([combined], combined.document.id, 'new', '2026-10-12').lines.length, 2);
  const foreign = { ...rows[1], document: { ...rows[0].document, currency: 'USD' } };
  assert.throws(() => copyJournalDraft([rows[0], foreign], rows[0].document.id, 'new', '2026-10-12'), /multiple currencies/);
});

test('GL journal UI excludes account expansion but retains other column grouping', () => {
  const component = readFileSync(new URL('../src/components/CompanyGlJournalView.tsx', import.meta.url), 'utf8');
  assert.match(component, /key !== 'account'/);
  const groups = buildJournalGroups(rows, JOURNAL_GROUPINGS[0].keys.filter(key => key !== 'account'));
  const visit = nodes => nodes.forEach(node => { assert.notEqual(node.key, 'account'); visit(node.children); });
  visit(groups);
  assert.match(component, /<PageHeader title="GL journal" actions=/);
  assert.match(component, />New journal<\/PageActionButton>/);
  assert.doesNotMatch(component, />(New journal entry|Copy journal entry|GL reports|Analytics)<\/PageActionButton>/);
  assert.match(component, /title="Copy journal entry"/);
  assert.match(component, /aria-label=\{`Edit /);
});

const editContext = { companyId: 'alice', mode: 'test', id: 'new-id', expectedRevision: 0, changedAt: '2026-10-12T11:00:00Z', changedBy: 'Other accountant' };
test('editing saved BŽ updates the same identity without duplicating rows or losing creation details', () => {
  const s = storage(); const saved = saveJournalDraft(s, context, copied(), accounts, []);
  const originalRows = journalDraftRows([saved], new Set(accounts.map(account => account.code)));
  const draft = editJournalDraft(originalRows, saved.id);
  draft.note = 'Edited description'; draft.lines[0].comment = 'Updated line';
  const edited = updateJournalDraft(s, editContext, draft, accounts, rows);
  assert.equal(loadJournalDrafts(s, 'alice', 'test').length, 1);
  assert.equal(edited.id, saved.id); assert.equal(edited.number, saved.number);
  assert.equal(edited.createdAt, saved.createdAt); assert.equal(edited.createdBy, saved.createdBy);
  assert.equal(edited.updatedBy, 'Other accountant'); assert.equal(edited.revision, 1);
  assert.deepEqual(edited.lines.map(line => line.id), saved.lines.map(line => line.id));
  assert.equal(edited.history[0].before.lines[0].comment, saved.lines[0].comment);
  assert.equal(edited.lines[0].comment, 'Updated line');
  assert.equal(edited.note, 'Edited description');
});

test('sample editing replaces only that sample document, retains type and status and survives reload', () => {
  const s = storage(); const original = JSON.stringify(rows);
  const selected = rows[0]; const draft = editJournalDraft(rows, selected.document.id);
  draft.lines[0].debit = '140'; draft.lines[2].credit = '169.15';
  const edited = updateJournalDraft(s, { ...editContext, id: selected.document.id, expectedRevision: null }, draft, accounts, rows);
  assert.equal(edited.sourceDocumentId, selected.document.id);
  const merged = mergeJournalRows(rows, loadJournalDrafts(s, 'alice', 'test'), new Set(accounts.map(account => account.code)));
  assert.equal(merged.length, rows.length);
  assert.deepEqual(merged.map(row => row.id), rows.map(row => row.id));
  assert.equal(new Set(merged.map(row => row.document.id)).size, 96);
  const changed = merged.find(row => row.id === selected.id);
  assert.equal(changed.debit, 140); assert.equal(changed.posted, selected.posted);
  assert.equal(changed.documentType, selected.documentType);
  assert.equal(changed.internalNumber, selected.internalNumber);
  assert.equal(JSON.stringify(rows), original);
  assert.deepEqual(merged.filter(row => row.document.id !== selected.document.id), rows.filter(row => row.document.id !== selected.document.id));
});

test('editing retains balance validation, own document number is allowed but other numbers are rejected', () => {
  const s = storage(); const id = rows[0].document.id; const draft = editJournalDraft(rows, id);
  const ctx = { ...editContext, id, expectedRevision: null };
  draft.number = rows.find(row => row.document.id !== id).documentNumber;
  assert.throws(() => updateJournalDraft(s, ctx, draft, accounts, rows), /already exists/);
  draft.number = rows[0].documentNumber; draft.lines[0].debit = '1';
  assert.throws(() => updateJournalDraft(s, ctx, draft, accounts, rows), /totals must be equal/);
  assert.deepEqual(loadJournalDrafts(s, 'alice', 'test'), []);
});

test('stale edit and cross-company attempts never overwrite the latest version', () => {
  const s = storage(); const saved = saveJournalDraft(s, context, copied(), accounts, []);
  const draft = editJournalDraft(journalDraftRows([saved], new Set()), saved.id);
  updateJournalDraft(s, editContext, draft, accounts, rows);
  const latest = s.getItem(journalDraftStorageKey('alice', 'test'));
  assert.throws(() => updateJournalDraft(s, editContext, draft, accounts, rows), /another window/);
  assert.equal(s.getItem(journalDraftStorageKey('alice', 'test')), latest);
  assert.throws(() => updateJournalDraft(s, { ...editContext, companyId: 'other' }, draft, accounts, rows), /another window/);
});

test('real source documents cannot be silently changed through a local journal override', () => {
  const source = rows.map(row => ({ ...row, sample: false }));
  const draft = editJournalDraft(source, source[0].document.id);
  for (const mode of ['test', 'company']) assert.throws(() => updateJournalDraft(storage(), { ...editContext, id: source[0].document.id, mode, expectedRevision: null }, draft, accounts, source), /source document/);
});
