import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = readFileSync(new URL('../src/components/CompanyDetail.tsx', import.meta.url), 'utf8');
const tree = ts.createSourceFile('CompanyDetail.tsx', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
function declaration(name) {
  let result;
  const visit = node => {
    if (ts.isVariableDeclaration(node) && node.name.getText(tree) === name) result = `const ${node.getText(tree)};`;
    ts.forEachChild(node, visit);
  };
  visit(tree);
  assert.ok(result, `Missing ${name}`);
  return result;
}
const js = ts.transpileModule(`
  ${declaration('COMPANY_SUBMENU_IDS')}
  export const submenuIds = COMPANY_SUBMENU_IDS;
  export function navigate(initialActive, initialExpanded, next, initialInformation = 'Contacts') {
    let activeMenu = initialActive, expandedMenu = initialExpanded, information = initialInformation;
    const setExpandedMenu = update => { expandedMenu = typeof update === 'function' ? update(expandedMenu) : update; };
    const setActiveMenu = id => { activeMenu = id; };
    const setActiveCompanyInformationMenu = id => { information = id; };
    // Mirror React's render snapshot: setters do not change captured activeMenu until commit.
    let nextActive = activeMenu;
    const select = (() => {
      const setActiveMenu = id => { nextActive = id; };
      ${declaration('selectCompanyMenu')}
      return selectCompanyMenu;
    })();
    select(next);
    return { activeMenu: nextActive, expandedMenu, information };
  }
`, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } }).outputText;
const { navigate, submenuIds } = await import(`data:text/javascript;base64,${Buffer.from(js).toString('base64')}`);

test('each company submenu opens, closes, and reopens without changing the active page', () => {
  assert.deepEqual(submenuIds, ['documents', 'warehouse', 'gl-journal', 'bank', 'reports', 'activity']);
  for (const id of submenuIds) {
    const opened = navigate('overview', null, id);
    assert.equal(opened.activeMenu, id);
    assert.equal(opened.expandedMenu, id);
    const closed = navigate(id, id, id);
    assert.equal(closed.activeMenu, id);
    assert.equal(closed.expandedMenu, null);
    assert.equal(navigate(id, null, id).expandedMenu, id);
  }
});

test('changing menu opens the new group and leaf navigation closes submenus', () => {
  assert.deepEqual(navigate('documents', null, 'bank'), { activeMenu: 'bank', expandedMenu: 'bank', information: 'Contacts' });
  assert.equal(navigate('bank', 'bank', 'gl-journal').expandedMenu, 'gl-journal');
  for (const id of ['overview', 'services', 'counterparties', 'contacts', 'partners', 'team']) {
    assert.equal(navigate('documents', 'documents', id).expandedMenu, null);
  }
});

test('toggling does not reset the selected child or its view state', () => {
  assert.equal(navigate('activity', 'activity', 'activity', 'Taxes').information, 'Taxes');
  assert.equal(navigate('activity', null, 'activity', 'Taxes').information, 'Taxes');
  assert.doesNotMatch(declaration('selectCompanyMenu'), /setActiveDocumentsMenu|setActiveBankMenu|setActiveGlJournalMenu|setActiveWarehouseMenu|setActiveDebtsMenu/);
  const mainContent = source.slice(source.indexOf('{/* Main content */}'));
  assert.doesNotMatch(mainContent, /isSubmenuOpen|expandedMenu ===/);
});

test('submenu visibility, disclosure arrows, and accessibility use separate expansion state', () => {
  assert.match(source, /useState<string \| null>\(activeMenu\)/);
  assert.match(source, /const isSubmenuOpen = isExpanded && isActive && expandedMenu === item\.id/);
  assert.match(source, /aria-expanded=\{hasSubmenu \? isSubmenuOpen : undefined\}/);
  for (const id of submenuIds) {
    assert.ok(source.includes(`isSubmenuOpen && item.id === '${id}'`));
    assert.ok(source.includes(`id="company-${id}-submenu"`));
  }
  assert.match(declaration('openGeneralLedger'), /setExpandedMenu\('gl-journal'\)/);
  assert.match(source, /setActiveMenu\('documents'\);\s*setExpandedMenu\('documents'\)/);
});
