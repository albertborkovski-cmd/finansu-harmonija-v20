import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import test from 'node:test';
import ts from 'typescript';
const source = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const require = createRequire(import.meta.url), api = {};
new Function('exports', 'require', ts.transpileModule(source('../src/lib/documentExport.ts'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText)(api, require);
const columns = [{ key: 'number', label: 'Document No.' }, { key: 'note', label: 'Note' }];
const rows = [{ id: 'a', companyId: 'one', number: 'INV-1', note: 'Lithuanian: ą, "quote"\nsecond line', privateData: 'do not export' }, { id: 'b', companyId: 'one', number: '=1+1', note: ' \t@SUM(A1)', privateData: 'secret' }];

test('selection exports explicit IDs only, preserving hidden selections without adding filtered-out records', () => {
  const documents = [{ id: 'a', company_id: 'one' }, { id: 'b', company_id: 'one' }, { id: 'c', company_id: 'two' }];
  assert.deepEqual(api.selectedDocumentRecords(documents, ['b', 'a', 'a'], 'one').map(row => row.id), ['b', 'a']);
  assert.throws(() => api.selectedDocumentRecords(documents, [], 'one'), /Select/);
  assert.throws(() => api.selectedDocumentRecords(documents, ['missing'], 'one'), /no longer/);
  assert.throws(() => api.selectedDocumentRecords(documents, ['c'], 'one'), /no longer/);
});
test('destination options follow company configuration, omit inactive systems and never expose secrets', () => {
  assert.deepEqual(api.documentDeliveryDestinations().map(option => option.label), ['Rivilė', 'Rivilė API', 'Agnum']);
  assert.deepEqual(api.documentDeliveryDestinations(JSON.stringify({ apiKey: 'secret', exportIntegrations: [{ id: 'one', name: 'ERP', apiUrl: 'private', apiKey: 'secret' }, { id: 'two', name: 'Old', active: false }, { id: 'one', name: 'Duplicate' }] })), [{ value: 'one', label: 'ERP' }]);
  assert.deepEqual(api.documentDeliveryDestinations('{broken'), []);
  assert.deepEqual(api.documentDeliveryDestinations('{"exportIntegrations":[]}'), []);
});
test('CSV is real UTF-8 CSV with quoting and formula-injection protection', async () => {
  const file = await api.buildDocumentExport(rows, columns, 'csv', 'Alice/Stone');
  assert.match(file.filename, /^AliceStone-documents-\d{4}-\d{2}-\d{2}\.csv$/);
  assert.equal(file.mime, 'text/csv;charset=utf-8');
  assert.ok(file.content.startsWith('\uFEFF"Document No.","Note"\r\n'));
  assert.ok(file.content.includes('"Lithuanian: ą, ""quote""\nsecond line"'));
  assert.ok(file.content.includes('"\'=1+1"'));
  assert.ok(file.content.includes('"\' \t@SUM(A1)"'));
  assert.ok(!file.content.includes('secret'));
});
test('JSON includes selected display columns and stable record identity only', async () => {
  const before = structuredClone(rows);
  const file = await api.buildDocumentExport(rows.slice(0, 1), columns, 'json');
  const parsed = JSON.parse(file.content);
  assert.equal(parsed.documents.length, 1);
  assert.deepEqual(parsed.documents[0], { id: 'a', companyId: 'one', values: { number: rows[0].number, note: rows[0].note } });
  assert.deepEqual(rows, before);
});
test('Excel format contains a readable workbook, not renamed text, and cell strings are not formulas', async () => {
  const XLSX = require('xlsx');
  const file = await api.buildDocumentExport(rows, columns, 'xlsx');
  const workbook = XLSX.read(file.content, { type: 'array' });
  assert.deepEqual(XLSX.utils.sheet_to_json(workbook.Sheets.Documents, { header: 1 }), [columns.map(column => column.label), ...rows.map(row => [row.number, row.note])]);
  assert.equal(workbook.Sheets.Documents.A3.f, undefined);
  assert.equal(workbook.Sheets.Documents.A3.t, 's');
});
test('empty selections, empty columns and unsupported formats cannot download misleading files', async () => {
  await assert.rejects(api.buildDocumentExport([], columns, 'csv'), /Select/);
  await assert.rejects(api.buildDocumentExport(rows, [], 'csv'), /Column settings/);
  await assert.rejects(api.buildDocumentExport(rows, columns, 'pdf'), /supported/);
});
test('list separates selected-document transfer from file export and refreshes scope and rights at action time', () => {
  const list = source('../src/components/Documents.tsx'), dialog = source('../src/components/DocumentDeliveryDialog.tsx');
  assert.match(list, /Send to accounting/);
  assert.ok(list.indexOf('>Send to accounting</PageActionButton>') < list.indexOf('{/* Filter bar */}'));
  assert.match(list, /aria-label="Export selected documents"/);
  assert.match(list, /mode: 'transfer', ids: \[\.\.\.selectedIds\]/);
  assert.match(list, /mode: 'export', ids: \[\.\.\.selectedIds\]/);
  assert.match(list, /selectedDocumentRecords\(/);
  assert.match(list, /canViewCompanyDocuments\(organization\)/);
  assert.match(list, /const \{ documents \} = await loadDeliveryRecords\(delivery\)/);
  assert.doesNotMatch(list, /importDocuments\(|update\(\{ status: 'Transferred' \}\)|IMPORTDATA/);
  assert.match(dialog, /<PageActionButton disabled icon=\{<Send/);
  assert.doesNotMatch(dialog, /fetch\(|\.update\(/);
  assert.match(dialog, /No documents will be sent or marked as Transferred/);
  assert.equal((dialog.match(/<SearchableSelect portalMenu menuClassName="!z-\[5100\]"/g) ?? []).length, 2);
});
