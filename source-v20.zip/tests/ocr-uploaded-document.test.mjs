import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = (path) => readFileSync(new URL(path, import.meta.url), 'utf8');
const compiled = ts.transpileModule(read('../src/lib/ocrDocumentScope.ts'), {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext },
}).outputText;
const { documentsForOcrOrganization } = await import(`data:text/javascript;base64,${Buffer.from(compiled).toString('base64')}`);
const alice = { id: 'alice', name: 'Alice Stone' };
const bob = { id: 'bob', name: 'Bob Morris' };
const records = [
  { id: 'alice::invoice', fileName: 'invoice.pdf', organizationName: alice.name },
  { id: 'bob::invoice', fileName: 'invoice.pdf', organizationName: bob.name },
  { id: 'alice::contract', fileName: 'contract.pdf', organizationName: alice.name },
  { id: 'unassigned', fileName: 'invoice.pdf' },
];

test('only the single selected organization supplies uploaded documents', () => {
  assert.deepEqual(documentsForOcrOrganization(records, alice).map((row) => row.id), ['alice::invoice', 'alice::contract']);
  assert.deepEqual(documentsForOcrOrganization(records, bob).map((row) => row.id), ['bob::invoice']);
});

test('missing, invalid and empty organizations never fall back to other companies', () => {
  for (const organization of [null, undefined, { id: '', name: alice.name }, { id: 'unknown', name: 'No documents' }]) {
    assert.deepEqual(documentsForOcrOrganization(records, organization), []);
  }
});

test('clearing search still exposes only selected-company records', () => {
  const scoped = documentsForOcrOrganization(records, alice);
  const search = (query) => scoped.filter((row) => row.fileName.includes(query));
  assert.deepEqual(search('invoice').map((row) => row.id), ['alice::invoice']);
  assert.deepEqual(search('').map((row) => row.id), ['alice::invoice', 'alice::contract']);
});

test('scoping retains original IDs and records without changing the source', () => {
  const before = JSON.stringify(records);
  const scoped = documentsForOcrOrganization(records, bob);
  assert.equal(scoped[0], records[1]);
  assert.equal(JSON.stringify(records), before);
});

test('uploaded and processed documents use the same workspace layout', () => {
  const uploaded = read('../src/components/AllDocumentsView.tsx');
  const processed = read('../src/components/OcrProcessedDocumentsView.tsx');
  assert.match(uploaded, /<OcrDocumentsWorkspace[\s\S]*?singleOrganization/);
  assert.match(processed, /<OcrDocumentsWorkspace/);
  assert.match(uploaded, /documentsForOcrOrganization\(documents, selectedOrganization\)/);
  assert.match(uploaded, /company:\$\{isUploadedOcr \? selectedOrganization\?\.name : companyName\}:draft/);
});

test('single-company sidebar has no All organizations control and retains selection', () => {
  const workspace = read('../src/components/OcrDocumentsWorkspace.tsx');
  assert.match(workspace, /if \(singleOrganization\) \{\s*onChange\(\[id\]\);\s*return;/);
  assert.match(workspace, /!singleOrganization && <>[\s\S]*?All organizations[\s\S]*?<\/>/);
});

test('OCR and company menus use Uploaded document without changing their route identifiers', () => {
  assert.match(read('../src/components/Sidebar.tsx'), /id: "ocr-all-documents-uploaded", label: "Uploaded document"/);
  assert.match(read('../src/components/AllDocumentsView.tsx'), /scope === "company" \? "Uploaded document" : "Processed documents"/);
  assert.match(read('../src/components/CompanyDetail.tsx'), /id: 'processed' as const, label: 'Uploaded document'/);
  assert.match(read('../src/components/CompanyDetail.tsx'), /<AllDocumentsView mode="processed" scope="company"/);
});
