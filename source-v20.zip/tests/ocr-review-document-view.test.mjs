import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const exports = {};
const compiled = ts.transpileModule(source('../src/lib/ocrReviewDocuments.ts'), {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
}).outputText;
new Function('exports', compiled)(exports);
const { findSavedReviewDocumentTask, loadSavedReviewDocumentTask, reviewDocumentPosition, isOcrReviewDocument, OCR_REVIEW_DOCUMENT_TASK_KEYS } = exports;

const document = { id: 'document-1', companyId: 'company-1' };
const task = (overrides = {}) => ({
  id: 'document-set-document-1', name: 'invoice.pdf',
  accounting: { documentId: document.id, companyId: document.companyId },
  documentType: 'Credit note', fields: { invoiceNumber: 'SAVED-001', totalAmount: '123.45' },
  products: [{ id: 'line-1', name: 'Saved product', quantity: '2', price: '61.725' }],
  ...overrides,
});

test('review view resolves the exact document and company, never a matching filename', () => {
  const match = task();
  const wrongCompany = task({ accounting: { documentId: document.id, companyId: 'company-2' } });
  const wrongDocument = task({ accounting: { documentId: 'document-2', companyId: document.companyId } });
  assert.equal(findSavedReviewDocumentTask(document, [{ [document.id]: wrongCompany }, { wrongDocument }, { match }]), match);
  assert.equal(findSavedReviewDocumentTask(document, [{ wrongCompany, wrongDocument }]), undefined);
});

test('the newest saved result retains corrected fields, document type and product lines unchanged', () => {
  const older = task({ lastCorrectedAt: '2026-10-28T10:00:00Z' });
  const latest = task({ lastCorrectedAt: '2026-10-29T10:00:00Z', fields: { invoiceNumber: 'CORRECTED-2' } });
  const original = JSON.stringify(latest);
  const result = findSavedReviewDocumentTask(document, [{ older }, { latest }]);
  assert.equal(result, latest);
  assert.equal(result.fields.invoiceNumber, 'CORRECTED-2');
  assert.equal(result.documentType, 'Credit note');
  assert.equal(result.products[0].name, 'Saved product');
  assert.equal(JSON.stringify(latest), original);
});

test('legacy drafts match stable document keys or IDs, not names', () => {
  const legacy = task({ accounting: undefined, id: 'legacy-task' });
  assert.equal(findSavedReviewDocumentTask(document, [{ [document.id]: legacy }]), legacy);
  assert.equal(findSavedReviewDocumentTask(document, [{ [`document-set-${document.id}`]: legacy }]), legacy);
  assert.equal(findSavedReviewDocumentTask(document, [{ 'invoice.pdf': legacy }]), undefined);
});

test('saved task loading is read-only and tolerates missing or corrupt collections', () => {
  const saved = task();
  const reads = [];
  const storage = { getItem(key) {
    reads.push(key);
    if (key === OCR_REVIEW_DOCUMENT_TASK_KEYS[0]) return '{broken';
    if (key === OCR_REVIEW_DOCUMENT_TASK_KEYS[1]) return '[]';
    if (key === OCR_REVIEW_DOCUMENT_TASK_KEYS[2]) return JSON.stringify({ saved });
    return null;
  } };
  assert.deepEqual(loadSavedReviewDocumentTask(document, storage), saved);
  assert.deepEqual(reads, [...OCR_REVIEW_DOCUMENT_TASK_KEYS]);
  assert.equal(loadSavedReviewDocumentTask(document, { getItem() { throw new Error('Unavailable'); } }), undefined);
});

test('View is a separate row action and opens the shared read-only result without save or approval handlers', () => {
  const table = source('../src/components/OcrProcessedDocumentsView.tsx');
  const review = source('../src/components/OcrReviewView.tsx');
  const workspace = source('../src/components/WorkspaceView.tsx');
  assert.match(table, /aria-label=\{`View \$\{row.fileCase\}`\}/);
  assert.match(table, /companyId: row.organizationId/);
  assert.match(table, /rowActionCount = Number\(Boolean\(onViewDocument\)\)/);
  assert.match(review, /onViewDocument=\{/);
  const preview = review.slice(review.indexOf('if (viewedDocument)'), review.indexOf('if (reviewTaskId &&'));
  assert.match(preview, /<WorkspaceDocumentEditor/);
  assert.match(preview, /\n\s+readOnly\n/);
  assert.match(preview, /companyId=\{viewedDocument.companyId\}/);
  assert.doesNotMatch(preview, /onSave=|onNextFile=|finishWorkSession|recordReviewedOcrDocuments/);
  assert.match(workspace, /documentType: readOnly && !hasSavedDraft/);
  assert.match(workspace, /<fieldset disabled=\{readOnly\}/);
});

test('Approve documents has View and Edit without row or bulk Run actions', () => {
  const review = source('../src/components/OcrReviewView.tsx');
  const approve = review.slice(review.indexOf('function ApproveDocumentsView()'), review.indexOf('function ReviewAnalyticsView()'));
  assert.match(approve, /onViewDocument=\{/);
  assert.match(approve, /onEditDocument=\{openDocument\}/);
  assert.doesNotMatch(approve, /onRunDocument=|onImportDocuments=|selectionActionVariant=|runAndApprove|recordReviewedOcrDocuments/);
  // Running OCR remains available to other callers of the shared table.
  const table = source('../src/components/OcrProcessedDocumentsView.tsx');
  assert.match(table, /onRunDocument &&/);
});

test('deep links use the destination document queue and exact company/document identity', () => {
  const queue = Array.from({ length: 21 }, (_, index) => ({
    id: `document-${index + 1}`, company_id: 'company-1', status: 'Need review', file_name: 'same.pdf',
  }));
  const accepted = { id: 'accepted-document', company_id: 'company-1', status: 'Accepted' };
  assert.deepEqual(reviewDocumentPosition(document, [...queue, accepted]), { position: 1, total: 21 });
  assert.deepEqual(reviewDocumentPosition({ id: 'document-17', companyId: 'company-1' }, queue), { position: 17, total: 21 });
  assert.deepEqual(reviewDocumentPosition({ id: 'document-1', companyId: 'company-2' }, queue), { position: 1, total: 1 });
  assert.deepEqual(reviewDocumentPosition({ id: accepted.id, companyId: 'company-1' }, [...queue, accepted]), { position: 22, total: 22 });
  assert.equal(isOcrReviewDocument({ status: ' Need Review ' }), true);
  assert.equal(isOcrReviewDocument(accepted), false);
});

test('learning hyperlinks and View share navigation to the selected document in Review', () => {
  const learning = source('../src/components/OcrMachineLearningView.tsx');
  const dashboard = source('../src/components/Dashboard.tsx');
  const review = source('../src/components/OcrReviewView.tsx');
  const viewer = source('../src/components/OcrLearningDocumentView.tsx');
  const sidebar = source('../src/components/Sidebar.tsx');
  assert.match(learning, /onOpenDocument=\{onOpenDocument\}/);
  assert.equal((learning.match(/onClick=\{\(\) => onOpenDocument\(item\)\}/g) ?? []).length, 2);
  assert.doesNotMatch(learning, /if \(reviewDocument\)|setReviewDocument/);
  assert.match(dashboard, /canViewMenu\(session, 'ocr-review-approve-documents'\)/);
  assert.match(dashboard, /handleMenuClick\('ocr-review-approve-documents'\);\s+setOcrLearningDocument\(document\)/);
  assert.match(dashboard, /learningDocument=\{ocrLearningDocument\}/);
  assert.match(dashboard, /if \(ocrLearningDocument && mainContentRef.current\) mainContentRef.current.scrollTop = 0/);
  assert.match(review, /evidence=\{learningDocument\} onBack=\{onCloseLearningDocument\}/);
  assert.match(sidebar, /if \(isReviewActive\(activeMenu\)\) setReviewExpanded\(true\)/);
  assert.match(viewer, /loadSavedReviewDocumentTask\(\{ id: evidence.documentId, companyId: evidence.companyId \}/);
  assert.match(viewer, /filePosition=\{file.position\}/);
  assert.match(viewer, /fileTotal=\{file.total\}/);
  assert.match(viewer, /\n\s+readOnly\n/);
});
