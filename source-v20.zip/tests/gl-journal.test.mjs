import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = ts.transpileModule(readFileSync(new URL('../src/lib/glJournal.ts', import.meta.url), 'utf8'), {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext },
}).outputText;
const { createSampleJournalRows, buildJournalGroups, buildJournalTableRows, journalCurrencyTotals, journalDate, journalDocumentDetails, journalEntrySide, JOURNAL_GROUPINGS } = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
const rows = createSampleJournalRows('alice-test');

test('document preview contains all opposite-side postings for the selected source document only', () => {
  for (const row of rows) {
    const detail = journalDocumentDetails(row, rows);
    const documentRows = rows.filter(entry => entry.document.id === row.document.id);
    assert.deepEqual(detail.entries, documentRows);
    assert.equal(detail.side, row.debit > 0 ? 'Debit' : 'Credit');
    assert.deepEqual(detail.correspondingEntries, documentRows.filter(entry => row.debit > 0 ? entry.credit > 0 : entry.debit > 0));
    assert.deepEqual(detail.totals, journalCurrencyTotals(documentRows));
  }
});

test('document preview does not invent a side or correspondence for legacy combined rows', () => {
  const combined = { ...rows[0], debit: 100, credit: 100 };
  assert.equal(journalEntrySide(combined), 'Debit / Credit');
  assert.deepEqual(journalDocumentDetails(combined, [combined]).correspondingEntries, []);
  const sameNumber = { ...rows[1], id: 'other', document: { ...rows[1].document, id: 'other-document' } };
  assert.equal(journalDocumentDetails(rows[0], [rows[0], sameNumber]).entries.length, 1);
});

test('96 isolated sample documents cover dates, currencies, counterparties, posting states and four operation types', () => {
  assert.equal(new Set(rows.map(row => row.document.id)).size, 96);
  assert.ok(rows.length > 250);
  assert.equal(new Set(rows.map(row => row.id)).size, rows.length);
  assert.equal(new Set(rows.map(row => row.operationDate)).size, 12);
  assert.equal(new Set(rows.map(row => row.counterparty)).size, 6);
  assert.deepEqual(new Set(rows.map(row => row.documentType)), new Set(['Purchase', 'Sale', 'Bank', 'Accounting note']));
  assert.deepEqual(new Set(rows.map(row => row.document.currency)), new Set(['EUR', 'USD']));
  assert.deepEqual(new Set(rows.map(row => row.postingStatus)), new Set(['Posted', 'Unposted']));
  assert.ok(rows.every(row => row.sample && row.document.source === 'Test data' && /^(PIR|SF|BNK|BP)26-\d{5}$/.test(row.documentNumber)));
  assert.ok(rows.every(row => /^\d+$/.test(row.internalNumber) && row.accountName && row.description));
  assert.deepEqual(createSampleJournalRows('alice-test'), rows);
  assert.ok(createSampleJournalRows('other-test').every(row => !rows.some(first => first.id === row.id)));
});

test('test postings use separate debit/credit sides and every document balances in minor units', () => {
  for (const id of new Set(rows.map(row => row.document.id))) {
    const entries = rows.filter(row => row.document.id === id);
    assert.ok(entries.every(row => row.debit > 0 ? row.credit === 0 : row.credit > 0));
    assert.equal(entries.reduce((sum, row) => sum + Math.round(row.debit * 100), 0), entries.reduce((sum, row) => sum + Math.round(row.credit * 100), 0));
  }
  const totals = journalCurrencyTotals(rows);
  assert.equal(totals.length, 2);
  assert.ok(totals.every(total => total.debit === total.credit && total.debit > 0));
});

test('all hierarchy modes retain every row exactly once at their deepest level', () => {
  for (const mode of JOURNAL_GROUPINGS.filter(mode => mode.keys.length)) {
    const tree = buildJournalGroups(rows, mode.keys);
    const leafIds = [];
    const groupIds = new Set();
    const visit = nodes => nodes.forEach(node => {
      assert.ok(!groupIds.has(node.id));
      groupIds.add(node.id);
      assert.equal(node.key, mode.keys[node.depth]);
      assert.deepEqual(node.totals, journalCurrencyTotals(node.rows));
      assert.equal(node.documentCount, new Set(node.rows.map(row => row.document.id)).size);
      if (node.children.length) visit(node.children);
      else leafIds.push(...node.rows.map(row => row.id));
    });
    visit(tree);
    assert.deepEqual(leafIds.sort(), rows.map(row => row.id).sort());
  }
  assert.deepEqual(buildJournalGroups(rows, []), []);
});

test('groups do not merge distinct documents with the same document number', () => {
  const first = rows[0];
  const second = { ...first, id: 'other-row', document: { ...first.document, id: 'other-document' } };
  const grouped = buildJournalGroups([first, second], ['documentNumber']);
  assert.equal(grouped.length, 2);
  assert.notEqual(grouped[0].id, grouped[1].id);
});

test('group IDs remain stable when filters are applied and restored; source rows stay unchanged', () => {
  const before = JSON.stringify(rows);
  const mode = JOURNAL_GROUPINGS[0];
  const date = rows[0].operationDate;
  const full = buildJournalGroups(rows, mode.keys).find(group => group.label === date);
  const filtered = buildJournalGroups(rows.filter(row => row.operationDate === date), mode.keys);
  assert.equal(filtered[0].id, full.id);
  assert.equal(filtered[0].children[0].id, full.children[0].id);
  assert.equal(JSON.stringify(rows), before);
});

test('dates normalize for period filtering and grouping without currency conversion', () => {
  assert.equal(journalDate('03.10.2026'), '2026-10-03');
  assert.equal(journalDate('03/10/2026'), '2026-10-03');
  assert.equal(journalDate('2026-10-03T12:30:00'), '2026-10-03');
  const september = rows.filter(row => journalDate(row.operationDate) >= '2026-09-01' && journalDate(row.operationDate) <= '2026-09-30');
  assert.equal(new Set(september.map(row => row.document.id)).size, 32);
  assert.equal(journalCurrencyTotals(september).length, 2);
});

function assertColumnSpans(matrix, keys) {
  for (const key of keys) {
    let remaining = 0;
    for (const row of matrix) {
      if (remaining > 0) {
        assert.ok(row.coveredCells.includes(key), `missing covered ${key} in ${row.id}`);
        assert.equal(row.groupCells[key], undefined);
        remaining--;
      } else if (row.groupCells[key]) {
        remaining = row.groupCells[key].rowSpan - 1;
        assert.ok(!row.coveredCells.includes(key));
      } else {
        assert.ok(!row.coveredCells.includes(key), `orphaned covered cell ${key}`);
      }
    }
    assert.equal(remaining, 0, `${key} spans past table end`);
  }
}

test('expanded hierarchy renders only posting rows, with grouped cells spanning the correct columns', () => {
  for (const mode of JOURNAL_GROUPINGS) {
    const matrix = buildJournalTableRows(buildJournalGroups(rows, mode.keys), rows, () => true);
    assert.equal(matrix.length, rows.length);
    assert.ok(matrix.every(row => row.entry && !row.summary));
    assertColumnSpans(matrix, mode.keys);
  }
});

test('collapse at every hierarchy level retains aligned columns and separate currency sums', () => {
  const mode = JOURNAL_GROUPINGS[0];
  const tree = buildJournalGroups(rows, mode.keys);
  for (let depth = 0; depth < mode.keys.length; depth++) {
    const matrix = buildJournalTableRows(tree, rows, group => group.depth < depth);
    assert.ok(matrix.every(row => row.summary && !row.entry));
    assertColumnSpans(matrix, mode.keys);
    for (const total of journalCurrencyTotals(rows)) {
      const subset = matrix.filter(row => row.currency === total.currency);
      assert.equal(subset.reduce((sum, row) => sum + Math.round(row.debit * 100), 0), Math.round(total.debit * 100));
      assert.equal(subset.reduce((sum, row) => sum + Math.round(row.credit * 100), 0), Math.round(total.credit * 100));
    }
  }
});

test('single branch collapse and 50-document loading do not create overlapping or orphaned table cells', () => {
  const mode = JOURNAL_GROUPINGS[0];
  const tree = buildJournalGroups(rows, mode.keys);
  const closed = tree[0].children[0].id;
  const firstBatch = new Set([...new Set(rows.map(row => row.document.id))].slice(0, 50));
  const matrix = buildJournalTableRows(tree, rows, group => group.id !== closed, firstBatch);
  assertColumnSpans(matrix, mode.keys);
  assert.ok(matrix.some(row => row.summary?.id === closed));
  assert.ok(matrix.filter(row => row.entry).every(row => firstBatch.has(row.entry.document.id)));
  assert.equal(new Set(matrix.map(row => row.id)).size, matrix.length);
});
