import assert from 'node:assert/strict';
import test from 'node:test';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
const source = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const core = {};
new Function('exports', ts.transpileModule(source('../src/lib/warehouse.ts'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText)(core);
const { createWarehouseExamples, warehouseLedger, blankWarehouseDocument, saveWarehouseDocument, postWarehouseDocument, documentTotals, submitWarehouseTransfer, removeWarehouseDocument, createReturnDraft, convertWarehouseOrder, generateRecurringInvoices, revalueWarehousePrices, effectivePrice, removeWarehouseMaster, saveWarehouseMaster, copyWarehouseDocument } = core;
const actor = 'Test accountant';
const seed = () => createWarehouseExamples('company-a');
function doc(store, kind, quantity = 1, price = 10) {
  return { ...blankWarehouseDocument(store, kind, actor, '2026-10-29'), counterparty: 'Test counterparty', lines: [{ id: crypto.randomUUID(), itemId: store.items[0].id, quantity, unitPrice: price, vatRate: 21, discount: 0 }] };
}
function quantity(store, item = store.items[0].id, location = store.locations[0].id) {
  return warehouseLedger(store).balances.find(row => row.itemId === item && row.warehouseId === location)?.quantity ?? 0;
}
test('warehouse navigation excludes Sales and Purchases while their stock history remains available', () => {
  const a = seed(), b = createWarehouseExamples('company-b');
  assert.equal(core.WAREHOUSE_SECTIONS.length, 13);
  assert.equal(core.WAREHOUSE_MENU_SECTIONS.length, 11);
  assert.ok(core.WAREHOUSE_MENU_SECTIONS.every(row => !['sales', 'purchases'].includes(row.id)));
  assert.ok(a.documents.some(row => row.kind === 'Sale'));
  assert.ok(a.documents.some(row => row.kind === 'Purchase'));
  assert.match(source('../src/components/CompanyDetail.tsx'), /items=\{WAREHOUSE_MENU_SECTIONS\}/);
  assert.ok(a.items.length >= 20 && a.documents.length >= 50);
  assert.ok(a.documents.every(row => row.companyId === 'company-a'));
  assert.ok(a.items.every(row => !b.items.some(other => other.id === row.id)));
  assert.ok(warehouseLedger(a).movements.length > 35);
});
test('drafts do not change balances; posting purchase and sale uses weighted cost exactly once', () => {
  let store = seed(); const initial = quantity(store);
  const purchase = doc(store, 'Purchase', 5, 20);
  store = saveWarehouseDocument(store, purchase, actor);
  assert.equal(quantity(store), initial);
  store = postWarehouseDocument(store, purchase.id, actor);
  assert.equal(quantity(store), initial + 5);
  assert.throws(() => postWarehouseDocument(store, purchase.id, actor), /again/);
  assert.throws(() => saveWarehouseDocument(store, purchase, actor), /Only draft/);
  const sale = doc(store, 'Sale', 2, 50);
  store = postWarehouseDocument(saveWarehouseDocument(store, sale, actor), sale.id, actor);
  assert.equal(quantity(store), initial + 3);
  const movement = warehouseLedger(store).movements.find(row => row.documentId === sale.id);
  assert.ok(movement.unitCost < 20); // Sale price is never used as stock cost.
  assert.equal(movement.quantityOut, 2);
});
test('insufficient or backdated stock cannot be posted and failure leaves the original unchanged', () => {
  const store = seed(), sale = doc(store, 'Sale', 100000);
  const draft = saveWarehouseDocument(store, sale, actor);
  assert.throws(() => postWarehouseDocument(draft, sale.id, actor), /Insufficient stock/);
  assert.equal(draft.documents.find(row => row.id === sale.id).status, 'Draft');
  const backdated = { ...doc(store, 'Sale', 1), date: '2026-09-01' };
  assert.throws(() => postWarehouseDocument(saveWarehouseDocument(store, backdated, actor), backdated.id, actor), /Insufficient stock/);
});
test('internal transfers require submission and conserve total quantity and value', () => {
  let store = seed(); const before = warehouseLedger(store).balances;
  const transfer = { ...doc(store, 'Transfer', 3), destinationId: store.locations[1].id };
  store = saveWarehouseDocument(store, transfer, actor);
  assert.throws(() => postWarehouseDocument(store, transfer.id, actor), /Submit/);
  store = submitWarehouseTransfer(store, transfer.id, actor);
  assert.deepEqual(warehouseLedger(store).balances, before);
  store = postWarehouseDocument(store, transfer.id, actor);
  const after = warehouseLedger(store).balances;
  const sum = (rows, key) => rows.filter(row => row.itemId === transfer.lines[0].itemId).reduce((value, row) => value + row[key], 0);
  assert.equal(sum(before, 'quantity'), sum(after, 'quantity'));
  assert.ok(Math.abs(sum(before, 'value') - sum(after, 'value')) < 0.000001);
});
test('partial returns reference the original sale and cannot exceed the sold quantity', () => {
  let store = seed(); const sale = store.documents.find(row => row.kind === 'Sale' && row.status === 'Posted');
  const returned = createReturnDraft(store, sale, actor);
  returned.date = '2026-10-29'; returned.lines[0].quantity = 1;
  const before = quantity(store, sale.lines[0].itemId);
  store = postWarehouseDocument(saveWarehouseDocument(store, returned, actor), returned.id, actor);
  assert.equal(quantity(store, sale.lines[0].itemId), before + 1);
  const over = createReturnDraft(store, sale, actor); over.lines[0].quantity = 100;
  assert.throws(() => saveWarehouseDocument(store, over, actor), /exceeds/);
  const changedPrice = createReturnDraft(store, sale, actor); changedPrice.lines[0].unitPrice += 1;
  assert.throws(() => saveWarehouseDocument(store, changedPrice, actor), /prices and VAT/);
});
test('stocktaking records actual stock including zero; services never change physical quantities', () => {
  let store = seed(); const count = doc(store, 'Stocktake', 0, 7);
  store = postWarehouseDocument(saveWarehouseDocument(store, count, actor), count.id, actor);
  assert.equal(quantity(store), 0);
  const sale = doc(store, 'Sale', 3, 50); sale.lines[0].itemId = store.items.find(row => row.type === 'Service').id;
  store = postWarehouseDocument(saveWarehouseDocument(store, sale, actor), sale.id, actor);
  assert.equal(warehouseLedger(store).movements.filter(row => row.documentId === sale.id).length, 0);
});
test('consignment is tracked per counterparty and can only be returned up to its balance', () => {
  let store = seed(); const before = quantity(store);
  const consignment = doc(store, 'Consignment', 3);
  store = postWarehouseDocument(saveWarehouseDocument(store, consignment, actor), consignment.id, actor);
  assert.equal(quantity(store), before - 3);
  const returned = doc(store, 'Consignment return', 4);
  assert.throws(() => postWarehouseDocument(saveWarehouseDocument(store, returned, actor), returned.id, actor), /exceeds/);
  returned.lines[0].quantity = 2;
  store = postWarehouseDocument(saveWarehouseDocument(store, returned, actor), returned.id, actor);
  assert.equal(quantity(store), before - 1);
  assert.equal(warehouseLedger(store).consigned.find(row => row.counterparty === 'Test counterparty').quantity, 1);
});
test('used records are deactivated and stock-invalid reversals are refused; unused drafts may be deleted', () => {
  let store = seed(); const draft = doc(store, 'Sale');
  store = saveWarehouseDocument(store, draft, actor);
  assert.ok(!removeWarehouseDocument(store, draft.id, actor).documents.some(row => row.id === draft.id));
  const sale = store.documents.find(row => row.kind === 'Sale' && row.status === 'Posted' && !store.documents.some(other => other.referenceId === row.id));
  const next = removeWarehouseDocument(store, sale.id, actor);
  assert.equal(next.documents.find(row => row.id === sale.id).status, 'Inactive');
  assert.throws(() => removeWarehouseDocument(store, store.documents.find(row => row.kind === 'Purchase').id, actor), /Insufficient stock/);
  const removedItem = removeWarehouseMaster(store, 'items', store.items[0].id, actor);
  assert.equal(removedItem.items[0].inactive, true);
});
test('customer price validity is honored; revaluation changes sales price, not stock cost', () => {
  const store = seed(), price = store.prices[0];
  assert.deepEqual(effectivePrice(store, price.itemId, price.counterparty, '2026-11-01'), { unitPrice: price.unitPrice, discount: price.discount });
  assert.equal(effectivePrice(store, price.itemId, price.counterparty, '2027-01-01').discount, 0);
  const revalued = revalueWarehousePrices(store, [store.items[0].id], 'Fixed price', 99, '2026-10-29', actor);
  assert.equal(revalued.items[0].salePrice, 99);
  assert.equal(store.items[0].salePrice, 12);
  assert.deepEqual(warehouseLedger(store), warehouseLedger(revalued));
  assert.equal(revalued.revaluations[0].oldPrice, 12);
  assert.throws(() => revalueWarehousePrices(store, [store.items[0].id], 'Fixed price', -1, '2026-10-29', actor), /negative/);
});
test('recurring generation is period-aware and does not duplicate a previously generated invoice', () => {
  const store = seed(), contract = store.contracts[0];
  const generated = generateRecurringInvoices(store, [contract.id], '2026-11-01', actor);
  const invoices = generated.documents.filter(row => row.sourceId.startsWith(contract.id));
  assert.equal(invoices.length, 2); assert.ok(invoices.every(row => row.status === 'Draft'));
  assert.equal(generated.contracts[0].nextDate, '2026-12-01');
  assert.throws(() => generateRecurringInvoices(generated, [contract.id], '2026-11-01', actor), /No selected contracts/);
  assert.deepEqual(warehouseLedger(store), warehouseLedger(generated));
});
test('e-commerce orders convert to one draft sale and are never silently shipped twice', () => {
  const store = seed(), order = store.documents.find(row => row.kind === 'Order');
  const converted = convertWarehouseOrder(store, order.id, actor);
  assert.equal(converted.documents.find(row => row.id === order.id).status, 'Converted');
  assert.equal(converted.documents.filter(row => row.sourceId === order.id).length, 1);
  assert.throws(() => convertWarehouseOrder(converted, order.id, actor), /already/);
  assert.deepEqual(warehouseLedger(store), warehouseLedger(converted));
});
test('cash totals, dates, duplicate item lines and cross-company records are validated', () => {
  const store = seed(), cash = doc(store, 'Cash sale', 2, 10);
  assert.throws(() => saveWarehouseDocument(store, cash, actor), /Cash and card/);
  cash.cashPaid = documentTotals(cash).total;
  assert.doesNotThrow(() => saveWarehouseDocument(store, cash, actor));
  assert.throws(() => saveWarehouseDocument(store, { ...cash, companyId: 'another-company' }, actor), /another company/);
  assert.throws(() => saveWarehouseDocument(store, { ...cash, date: '2026-02-30' }, actor), /valid document date/);
  assert.throws(() => saveWarehouseDocument(store, { ...cash, lines: [...cash.lines, { ...cash.lines[0], id: 'duplicate' }] }, actor), /only once/);
  assert.throws(() => saveWarehouseMaster(store, 'items', { ...store.items[0], type: 'Service' }, actor), /type of a used item/);
  assert.notEqual(copyWarehouseDocument(store, store.documents[0], actor).id, store.documents[0].id);
});
test('UI uses shared menus, filtering, ID selection, columns, lifecycle actions and fullscreen', () => {
  const table = source('../src/components/WarehouseTable.tsx'), view = source('../src/components/CompanyWarehouseView.tsx'), menu = source('../src/components/CompanyDetail.tsx');
  for (const name of ['SystemAddFilters', 'ColumnSettingsPanel', 'ColumnSortButton', 'ResizeHandle', 'HorizontalTableScrollbar', 'toggleFilteredSelection']) assert.ok(table.includes(name));
  assert.match(table, /system-table-row-actions/);
  assert.match(table, /system-table-header-row/);
  assert.match(menu, /CompanySubmenu id="company-warehouse-submenu"/);
  assert.match(view, /isRecordLinked/); assert.match(view, /RowDeleteButton/);
  const persistence = source('../src/lib/warehouseStore.ts');
  assert.match(persistence, /warehousePermissions\(company\)\.edit/);
  assert.match(persistence, /change\(loadWarehouse\(company.id\)\)/);
  assert.match(persistence, /companyId !== companyId/);
});

test('warehouse uses compact system toolbar icons and matching table and row-action geometry', () => {
  const table = source('../src/components/WarehouseTable.tsx');
  const view = source('../src/components/CompanyWarehouseView.tsx');
  assert.match(table, /data-button-family="export" aria-label="EXPORT" title="EXPORT" onClick=\{\(\) => exportRows\(title, visible, sortedRows\)\}/);
  assert.ok(!table.includes('PageActionButton'));
  assert.match(table, /data-table-workspace-tools role="group"/);
  assert.match(table, /42px \$\{visible/);
  assert.match(table, /system-table-select-cell/);
  assert.match(table, /grid h-10 items-center rounded-lg/);
  assert.match(table, /role="columnheader" aria-sort=/);
  assert.match(view, /function WarehouseRowAction/);
  assert.match(view, /h-7 w-7 shrink-0/);
  assert.ok(!view.includes('iconOnly'));
});

test('equal posting timestamps retain document order instead of sorting random IDs', () => {
  let store = seed();
  const out = { ...doc(store, 'Consignment', 3), id: 'z-consignment', createdAt: '2026-10-29T10:00:00.000Z' };
  store = postWarehouseDocument(saveWarehouseDocument(store, out, actor), out.id, actor);
  const back = { ...doc(store, 'Consignment return', 2), id: 'a-return', createdAt: out.createdAt };
  store = postWarehouseDocument(saveWarehouseDocument(store, back, actor), back.id, actor);
  store = { ...store, documents: store.documents.map(row => [out.id, back.id].includes(row.id) ? { ...row, postedAt: out.createdAt } : row) };
  assert.equal(warehouseLedger(store).consigned.find(row => row.counterparty === out.counterparty).quantity, 1);
});

test('future and out-of-order price revaluations are rejected', () => {
  const store = seed();
  assert.throws(() => revalueWarehousePrices(store, [store.items[0].id], 'Fixed price', 25, '9999-01-01', actor), /Future/);
  const revalued = revalueWarehousePrices(store, [store.items[0].id], 'Fixed price', 25, '2026-10-20', actor);
  assert.throws(() => revalueWarehousePrices(revalued, [store.items[0].id], 'Fixed price', 20, '2026-10-19', actor), /later price/);
});

test('persistence rechecks permission, preserves corrupt data and isolates companies', () => {
  const memory = new Map();
  const storage = { getItem: key => memory.get(key) ?? null, setItem: (key, value) => memory.set(key, value) };
  const events = [];
  const adapters = {
    './accessControl': { parseSession: raw => raw ? JSON.parse(raw) : null, canViewMenu: session => session.view, canEditMenu: session => session.edit },
    './currentUser': { AUTH_SESSION_KEY: 'session' },
    './linkedSettingsData': { canAccessAssignedOrganization: (company, session) => session.companyId === company.id },
    './warehouse': core,
  };
  const persistence = {};
  const compiled = ts.transpileModule(source('../src/lib/warehouseStore.ts'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  new Function('exports', 'require', 'localStorage', 'window', 'CustomEvent', compiled)(persistence, key => adapters[key], storage, { dispatchEvent: event => events.push(event) }, class { constructor(type, data) { this.type = type; this.detail = data.detail; } });
  const company = { id: 'company-a' };
  memory.set('session', JSON.stringify({ companyId: company.id, view: true, edit: true }));
  persistence.updateWarehouse(company, store => saveWarehouseDocument(store, doc(store, 'Purchase'), actor));
  assert.ok(memory.has(persistence.warehouseStorageKey(company.id)));
  assert.equal(events.length, 1);
  const original = memory.get(persistence.warehouseStorageKey(company.id));
  memory.set('session', JSON.stringify({ companyId: company.id, view: true, edit: false }));
  assert.throws(() => persistence.updateWarehouse(company, store => store), /permission/);
  assert.equal(memory.get(persistence.warehouseStorageKey(company.id)), original);
  memory.set('session', JSON.stringify({ companyId: company.id, view: true, edit: true }));
  assert.throws(() => persistence.updateWarehouse({ id: 'company-b' }, store => store), /permission/);
  assert.ok(!memory.has(persistence.warehouseStorageKey('company-b')));
  memory.set(persistence.warehouseStorageKey(company.id), '{broken');
  assert.throws(() => persistence.updateWarehouse(company, store => store));
  assert.equal(memory.get(persistence.warehouseStorageKey(company.id)), '{broken');
});
