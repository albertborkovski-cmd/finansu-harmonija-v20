import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const compile = file => ts.transpileModule(source(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const core = {};
new Function('exports', compile('../src/lib/documentIssues.ts'))(core);
const { transitionDocumentIssue: transition, guardDocumentMutation: guard, hasBlockingDocumentIssue: blocked, documentIssueStatus: status } = core;
const draft = () => ({ id: 'd1', company_id: 'c1', status: 'Draft', number: 'INV-1', expense_account: '6000', vat_classifier: 'PVM1' });
const report = document => transition(document, { type: 'report', message: 'Wrong organization / amount' }, 'Accountant');
const latest = document => document.digitization_issues.at(-1);

test('report records author, original organization and immutable history without OCR or approval', () => {
  const before = draft(), after = report(before);
  assert.equal(status(after), 'Open'); assert.equal(blocked(after), true);
  assert.equal(after.status, 'Draft'); assert.equal(after.ocr_rerun_request, undefined);
  assert.equal(latest(after).organizationId, 'c1'); assert.equal(latest(after).createdBy, 'Accountant');
  assert.equal(latest(after).events[0].action, 'Reported to MESO Worker');
  assert.equal(before.digitization_issues, undefined);
  assert.throws(() => transition(before, { type: 'report', message: '  ' }, 'A'), /Describe/);
  assert.throws(() => transition(before, { type: 'report', message: 'x'.repeat(5001) }, 'A'), /5,000/);
});

test('all approval and accounting-transfer variants are guarded', () => {
  const document = report(draft());
  for (const value of ['Approved', 'Accepted', 'Completed', 'Processed', 'Transferred', 'Exported', 'Posted', 'Paid'])
    assert.throws(() => guard(document, { status: value }, 'Accountant'), /Resolve the reported/);
  for (const patch of [{ accounting_note_status: 'Posted' }, { exported_at: '2026-11-03' }, { transferred: true }, { approved_by: 'A' }])
    assert.throws(() => guard(document, patch, 'A'), /Resolve the reported/);
  assert.equal(guard(document, { status: 'Correcting' }, 'Worker').status, 'Correcting');
});

test('regular edits retain open reports and append field-level changes', () => {
  const document = report(draft());
  const corrected = guard(document, { number: 'CORRECTED-2' }, 'Worker');
  assert.equal(latest(corrected).events.length, 2); assert.equal(latest(document).events.length, 1);
  assert.deepEqual(latest(corrected).events[1].changes, [{ field: 'number', before: 'INV-1', after: 'CORRECTED-2' }]);
  assert.equal(blocked(corrected), true);
  assert.throws(() => guard(corrected, { digitization_issues: [] }, 'A'), /history has changed/);
  assert.throws(() => guard(corrected, { digitization_issues: document.digitization_issues }, 'A'), /history has changed/);
});

test('organization is immutable in ordinary edits; worker correction retains audit and clears company-specific references', () => {
  const document = report({ ...draft(), line_items: [{ id: 'l1', expense: '6000', vatClass: 'PVM1', product: 'Paper', qty: '2' }] });
  assert.throws(() => guard(document, { company_id: 'c2' }, 'Worker'), /Report an issue/);
  const corrected = transition(document, { type: 'organization', issueId: latest(document).id, organizationId: 'c2', note: 'Buyer verified against source invoice' }, 'Worker');
  assert.equal(corrected.company_id, 'c2'); assert.equal(corrected.expense_account, '');
  assert.equal(corrected.line_items[0].expense, ''); assert.equal(corrected.line_items[0].product, 'Paper');
  assert.equal(latest(corrected).organizationId, 'c1'); assert.match(latest(corrected).events.at(-1).details, /c1 → c2/);
  assert.equal(blocked(corrected), true);
});

test('only explicit OCR requests create a pending request, never claim a completed rescan', () => {
  const document = report(draft());
  const started = transition(document, { type: 'start', issueId: latest(document).id }, 'Worker');
  assert.equal(started.ocr_rerun_request, undefined);
  const rerun = transition(started, { type: 'request-ocr', issueId: latest(document).id, note: 'Unreadable line needs another extraction' }, 'Worker');
  assert.equal(rerun.ocr_rerun_request.status, 'Pending integration');
  assert.equal(rerun.status, 'Draft'); assert.equal(blocked(rerun), true);
});

test('reassignment keeps a reporting-company receipt and requires fresh accounting validation', () => {
  const document = report({ ...draft(), status: 'Approved' });
  const changed = transition(document, { type: 'organization', issueId: latest(document).id, organizationId: 'c2', note: 'Buyer confirmed' }, 'Worker');
  assert.equal(changed.status, 'Correcting'); assert.equal(blocked(changed), true);
  assert.equal(latest(changed).documentLabel, 'INV-1'); assert.equal(latest(changed).organizationId, 'c1');
  const transferred = report({ ...draft(), status: 'Transferred' });
  assert.throws(() => transition(transferred, { type: 'organization', issueId: latest(transferred).id, organizationId: 'c2', note: 'Buyer confirmed' }, 'Worker'), /Reverse the accounting transfer/);
  const receipts = source('../src/components/DocumentIssueReceipts.tsx');
  assert.match(receipts, /issue.organizationId === companyId/);
  assert.match(receipts, /canAccessIssueOrganization/);
  assert.doesNotMatch(receipts, /document\.total_amount|document\.line_items|document\.number/);
});

test('every unresolved issue must be resolved; resolution does not approve, transfer, or rerun OCR', () => {
  const document = report(report(draft()));
  const resolvedOne = transition(document, { type: 'resolve', issueId: latest(document).id, note: 'Corrected amount' }, 'Worker');
  assert.equal(blocked(resolvedOne), true);
  const resolved = transition(resolvedOne, { type: 'resolve', issueId: document.digitization_issues[0].id, note: 'Organization checked' }, 'Worker');
  assert.equal(blocked(resolved), false); assert.equal(status(resolved), 'Resolved');
  assert.equal(resolved.status, 'Draft'); assert.equal(resolved.ocr_rerun_request, undefined);
  assert.equal(guard(resolved, { status: 'Approved' }, 'Accountant').status, 'Approved');
  assert.throws(() => transition(resolved, { type: 'resolve', issueId: latest(resolved).id, note: 'Again' }, 'Worker'), /no longer open/);
  assert.throws(() => transition(document, { type: 'resolve', issueId: latest(document).id, note: '' }, 'Worker'), /note/);
});

test('reporting an approved document does not revoke approval; returning to draft activates the guard', () => {
  const approved = report({ ...draft(), status: 'Approved' });
  assert.equal(approved.status, 'Approved'); assert.equal(blocked(approved), false);
  const reopened = guard(approved, { status: 'Draft' }, 'Accountant');
  assert.equal(blocked(reopened), true);
  assert.throws(() => guard(reopened, { status: 'Transferred' }, 'Accountant'), /Resolve/);
});

function adapterFixture() {
  const storage = new Map();
  const localStorage = { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value) };
  const permissions = { worker: true, organizations: new Set(['c1', 'c2']) };
  const api = {};
  const require = name => {
    if (name === './documentStorno') {
      const storno = {}; new Function('exports', compile('../src/lib/documentStorno.ts'))(storno); return storno;
    }
    if (name === './documentIssues') return core;
    if (name === './currentUser') return { getCurrentUserName: () => 'Test user' };
    if (name === './generalLedgerUsage') return { rememberLedgerTableUsage() {} };
    if (name === './recordLifecycle') return { removeOrDeactivateRecords: (rows, ids) => rows.filter(row => !ids.has(row.id)) };
    if (name === './documentIssueAccess') return { canReviewDocumentIssues: () => permissions.worker, canAccessIssueOrganization: company => permissions.organizations.has(company.id) };
    throw new Error(name);
  };
  const fakeWindow = { localStorage, setTimeout, clearTimeout, dispatchEvent() {} };
  new Function('exports', 'require', 'window', 'navigator', 'fetch', 'CustomEvent', compile('../src/lib/supabase.ts'))(api, require, fakeWindow, {}, async () => { throw new Error('Static deployment'); }, class { constructor(type, options) { this.type = type; this.detail = options?.detail; } });
  const put = (table, rows) => storage.set(`finansu-harmonija-v4:data:${table}`, JSON.stringify(rows));
  const get = table => JSON.parse(storage.get(`finansu-harmonija-v4:data:${table}`));
  put('companies', [{ id: 'c1', name: 'Company 1' }, { id: 'c2', name: 'Company 2' }]);
  put('documents', [draft(), { ...draft(), id: 'd2' }]); put('document_history', []);
  return { ...api, get, put, permissions, storage };
}

test('actual adapter blocks bulk transfers atomically, and stale upserts cannot erase issue state', async () => {
  const f = adapterFixture();
  const stale = f.get('documents')[0];
  await f.applyDocumentIssueAction('d1', 'c1', { type: 'report', message: 'Check amount' });
  const result = await f.supabase.from('documents').update({ status: 'Transferred' }).in('id', ['d1', 'd2']);
  assert.match(result.error.message, /Resolve/);
  assert.ok(f.get('documents').every(document => document.status === 'Draft'));
  const upsert = await f.supabase.from('documents').upsert({ ...stale, status: 'Approved' }, { onConflict: 'id' });
  assert.match(upsert.error.message, /Resolve/);
  const edited = await f.supabase.from('documents').upsert({ ...stale, number: 'NEW-1' }, { onConflict: 'id' });
  assert.equal(edited.error, null); assert.equal(latest(f.get('documents')[0]).status, 'Open');
});

test('actual commands recheck worker permissions, organization scope and document identity', async () => {
  const f = adapterFixture();
  const reported = await f.applyDocumentIssueAction('d1', 'c1', { type: 'report', message: 'Wrong company' });
  f.permissions.worker = false;
  await assert.rejects(f.applyDocumentIssueAction('d1', 'c1', { type: 'resolve', issueId: latest(reported).id, note: 'Done' }), /Only MESO Worker/);
  f.permissions.worker = true; f.permissions.organizations.delete('c2');
  await assert.rejects(f.applyDocumentIssueAction('d1', 'c1', { type: 'organization', issueId: latest(reported).id, organizationId: 'c2', note: 'Wrong buyer' }), /selected organization/);
  await assert.rejects(f.applyDocumentIssueAction('d1', 'c2', { type: 'report', message: 'Stale' }), /organization has changed/);
  f.permissions.organizations.delete('c1');
  await assert.rejects(f.applyDocumentIssueAction('d1', 'c1', { type: 'report', message: 'No access' }), /access/);
});

test('report, correction, resolution and reload retain exact audit; reported documents cannot be removed', async () => {
  const f = adapterFixture();
  const document = await f.applyDocumentIssueAction('d1', 'c1', { type: 'report', message: 'Wrong company' });
  const issueId = latest(document).id;
  await f.applyDocumentIssueAction('d1', 'c1', { type: 'start', issueId });
  await f.supabase.from('documents').update({ number: 'CORRECT-1' }).eq('id', 'd1');
  const resolved = await f.applyDocumentIssueAction('d1', 'c1', { type: 'resolve', issueId, note: 'Verified buyer and corrected invoice number' });
  assert.equal(latest(resolved).events.length, 4); assert.equal(resolved.status, 'Draft');
  const reload = await f.supabase.from('documents').select('*').eq('id', 'd1');
  assert.deepEqual(reload.data[0].digitization_issues, resolved.digitization_issues);
  assert.equal(f.get('document_history').length, 3);
  const removed = await f.supabase.from('documents').delete().eq('id', 'd1');
  assert.match(removed.error.message, /history/); assert.equal(f.get('documents').length, 2);
});

test('concurrent reports and updates preserve all documents and both reports', async () => {
  const f = adapterFixture();
  await Promise.all([
    f.applyDocumentIssueAction('d1', 'c1', { type: 'report', message: 'Amount' }),
    f.applyDocumentIssueAction('d1', 'c1', { type: 'report', message: 'Company' }),
    f.supabase.from('documents').update({ number: 'SECOND-2' }).eq('id', 'd2'),
  ]);
  assert.equal(f.get('documents')[0].digitization_issues.length, 2);
  assert.equal(f.get('documents')[1].number, 'SECOND-2');
});

test('unreadable document storage fails closed instead of dropping report history', async () => {
  const f = adapterFixture(); f.storage.set('finansu-harmonija-v4:data:documents', '{broken');
  const result = await f.supabase.from('documents').update({ status: 'Approved' }).eq('id', 'd1');
  assert.match(result.error.message, /not overwritten/);
  assert.equal(f.storage.get('finansu-harmonija-v4:data:documents'), '{broken');
});

test('both accountant entry points and worker queue are wired, and transfer history is recorded only after a successful guarded write', () => {
  const documents = source('../src/components/Documents.tsx');
  const detail = source('../src/components/DocumentDetailPanel.tsx');
  assert.match(documents, /label: "Issue status"/);
  assert.match(documents, /aria-label=\{`Report issue for/);
  assert.match(detail, /onClick=\{\(\) => setShowIssueDialog\(true\)\}/);
  assert.match(detail, /<DocumentIssueDialog documentId=\{doc.id\}/);
  assert.match(source('../src/components/OcrReviewView.tsx'), /<DocumentIssueQueue \/>/);
  // Without a connected API, neither bulk nor per-row send may simulate a transfer.
  assert.doesNotMatch(documents, /update\(\{ status: 'Transferred' \}\)/);
  assert.doesNotMatch(documents, /importMenuRecords\(/);
  const delivery = source('../src/components/DocumentDeliveryDialog.tsx');
  assert.match(delivery, /hasBlockingDocumentIssue/);
  assert.match(delivery, /<PageActionButton disabled icon=\{<Send/);
});
