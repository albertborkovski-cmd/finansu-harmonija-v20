import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const load = path => {
  const exports = {};
  const output = ts.transpileModule(source(path), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText;
  new Function('exports', output)(exports);
  return exports;
};
const core = load('../src/lib/ocrLearning.ts');
const { findLearningDocumentTask, learningDocumentQueue, exampleLearningDocument } = load('../src/lib/ocrLearningDocuments.ts');
const store = core.createLearningExamples();
const item = store.evidence[0];

test('document source lookup uses both exact document and company IDs, not a shared filename', () => {
  const other = { id: 'x', name: item.documentName, accounting: { companyId: 'other', documentId: item.documentId } };
  const match = { id: 'y', name: item.documentName, accounting: { companyId: item.companyId, documentId: item.documentId } };
  assert.equal(findLearningDocumentTask(item, [{ other }, { match }]), match);
  assert.equal(findLearningDocumentTask(item, [{ other }, { sameName: { name: item.documentName } }]), undefined);
});

test('file position is based on distinct teaching documents in the same scope', () => {
  const queue = learningDocumentQueue(item, store);
  assert.equal(queue.length, 2);
  const repeated = { ...item, id: 'new-confirmation', confirmedAt: '2026-10-29T12:00:00Z' };
  const scoped = learningDocumentQueue(item, { ...store, evidence: [...store.evidence, repeated, { ...repeated, companyId: 'different' }] });
  assert.equal(scoped.length, 2);
  assert.equal(scoped[0].id, repeated.id);
});

test('example view contains known teaching values but no invented invoice amount or products', () => {
  const task = exampleLearningDocument(item, store);
  assert.equal(task.name, item.documentName);
  assert.equal(task.fields.companyName, item.supplierName);
  assert.equal(task.accounting.expenseAccount, '6202');
  assert.equal(task.accounting.vatClassifier, 'PVM1');
  assert.equal(task.fields.totalAmount, '');
  assert.equal(task.fields.invoiceDate, '');
  assert.deepEqual(task.products, []);
});

test('read-only workflow reuses document extraction layout and guards writes and work-time logging', () => {
  const workspace = source('../src/components/WorkspaceView.tsx');
  const view = source('../src/components/OcrLearningDocumentView.tsx');
  assert.match(view, /<WorkspaceDocumentEditor/);
  assert.match(view, /\n\s+readOnly\n/);
  assert.match(view, /companyId=\{evidence.companyId\}/);
  assert.match(workspace, /<fieldset disabled=\{readOnly\}/);
  assert.match(workspace, /const saveDocumentTask = async \(nextTask: WorkspaceTask\) => \{\s+if \(readOnly\) return;/);
  assert.match(workspace, /const commitWorkTime = \(\) => \{\s+if \(readOnly\) return;/);
  assert.match(workspace, /if \(!readOnly && !closed.current\)/);
  assert.match(workspace, /if \(companyId\) query = query.eq\('company_id', companyId\)/);
  assert.match(workspace, /readOnly \? context : suggestDocumentAccounting\(context\)/);
  assert.match(workspace, /readOnly \? <PageActionButton onClick=\{onBack\}>Close/);
  assert.match(workspace, /Original file is not available/);
});
