import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const compiled = ts.transpileModule(readFileSync(new URL('../src/lib/glJournalClosing.ts', import.meta.url), 'utf8'), {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext },
}).outputText;
const { closingPeriodError, loadClosingPeriod, saveClosingPeriod } = await import(`data:text/javascript;base64,${Buffer.from(compiled).toString('base64')}`);

test('closing periods require valid dates in chronological order', () => {
  assert.ok(closingPeriodError({ from: '', to: '' }));
  assert.ok(closingPeriodError({ from: '2026-10-01', to: '' }));
  assert.ok(closingPeriodError({ from: '2026-10-31', to: '2026-10-01' }));
  assert.ok(closingPeriodError({ from: '2026-02-29', to: '2026-03-01' }));
  assert.equal(closingPeriodError({ from: '2024-02-29', to: '2024-02-29' }), '');
  assert.equal(closingPeriodError({ from: '2026-01-01', to: '2026-12-31' }), '');
});

test('saved selections are isolated by company and closing type and contain no accounting postings', () => {
  const data = new Map();
  const storage = { getItem: key => data.get(key) ?? null, setItem: (key, value) => data.set(key, value) };
  const annual = { from: '2026-01-01', to: '2026-12-31' };
  const monthly = { from: '2026-09-01', to: '2026-09-30' };
  saveClosingPeriod(storage, 'alice', 'classes56', annual);
  saveClosingPeriod(storage, 'alice', 'vat', monthly);
  assert.deepEqual(loadClosingPeriod(storage, 'alice', 'classes56'), annual);
  assert.deepEqual(loadClosingPeriod(storage, 'alice', 'vat'), monthly);
  assert.equal(loadClosingPeriod(storage, 'bob', 'vat'), null);
  assert.equal(data.size, 2);
  for (const value of data.values()) assert.deepEqual(Object.keys(JSON.parse(value)).sort(), ['from', 'to']);
});

test('invalid storage is ignored and invalid periods are never saved', () => {
  assert.equal(loadClosingPeriod({ getItem: () => 'broken' }, 'alice', 'vat'), null);
  assert.equal(loadClosingPeriod({ getItem: () => '{"from":"tomorrow","to":"later"}' }, 'alice', 'vat'), null);
  assert.throws(() => saveClosingPeriod({ setItem: () => assert.fail('must not write') }, 'alice', 'vat', { from: '', to: '' }));
  assert.throws(() => saveClosingPeriod({ setItem: () => { throw new Error('Storage full'); } }, 'alice', 'vat', { from: '2026-10-01', to: '2026-10-31' }), /Storage full/);
});

test('journal toolbar keeps column grouping while removing the requested controls', () => {
  const view = readFileSync(new URL('../src/components/CompanyGlJournalView.tsx', import.meta.url), 'utf8');
  assert.doesNotMatch(view, /Journal data source|Journal grouping|>Group by<|>Expand all<|>Collapse all</);
  assert.match(view, /Close classes 5 &amp; 6/);
  assert.match(view, /VAT closing/);
  assert.match(view, /toggleColumnGroups/);
  assert.match(view, /GlJournalClosingDialog key=\{`\$\{company.id\}:\$\{closingKind\}`\}/);
});

test('VAT closing is period-only; email controls belong to the separate reconciliation action', () => {
  const dialog = readFileSync(new URL('../src/components/GlJournalClosingDialog.tsx', import.meta.url), 'utf8');
  assert.match(dialog, /emailOnly \? 'max-w-\[680px\]' : 'max-w-\[480px\]'/);
  assert.match(dialog, /emailOnly && kind === 'vat' && <section[^>]*aria-label="VAT reconciliation email"/);
  assert.match(dialog, /emailOnly && kind === 'vat' && <PageActionButton icon=\{<Mail/);
  assert.match(dialog, /!emailOnly && <PageActionButton icon=\{<Save/);
  assert.match(dialog, /\(\['from', 'to'\] as const\)\.map/);
  assert.doesNotMatch(dialog, /\{kind === 'vat' && <(?:section|PageActionButton)/);
  const email = readFileSync(new URL('../src/components/VatReconciliationCompanyDialog.tsx', import.meta.url), 'utf8');
  assert.match(email, /<GlJournalClosingDialog[^>]* emailOnly /);
});
