import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';

const read = path => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const css = read('src/index.css');
const scrollbar = read('src/components/HorizontalTableScrollbar.tsx');
const rule = selector => {
  const start = css.indexOf(`\n${selector} {`);
  assert.notEqual(start, -1, `Missing ${selector}`);
  return css.slice(start, css.indexOf('}', start) + 1);
};

test('native and shared scrollbars use the same FH blue and light track', () => {
  assert.match(css, /--system-scrollbar-thumb: #007EA7;/);
  assert.match(rule('*'), /scrollbar-color: var\(--system-scrollbar-thumb\) var\(--system-scrollbar-track\)/);
  for (const selector of ['::-webkit-scrollbar-thumb', '.system-scrollbar-thumb']) {
    assert.match(rule(selector), /background: var\(--system-scrollbar-thumb\)/);
  }
  for (const selector of ['::-webkit-scrollbar-track', '.system-scrollbar-track']) {
    assert.match(rule(selector), /background: var\(--system-scrollbar-track\)/);
  }
  assert.doesNotMatch(rule('.profile-activity-scrollbar'), /scrollbar-color/);
});

test('thumb has at least 3:1 contrast against its track', () => {
  const luminance = token => {
    const hex = css.match(new RegExp(`--system-scrollbar-${token}: #(\\w{6});`))[1];
    const rgb = hex.match(/../g).map(pair => parseInt(pair, 16) / 255)
      .map(value => value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4);
    return rgb[0] * 0.2126 + rgb[1] * 0.7152 + rgb[2] * 0.0722;
  };
  assert.ok((luminance('track') + 0.05) / (luminance('thumb') + 0.05) >= 3);
});

test('shared control retains drag, step and disabled states with distinct styling', () => {
  assert.match(scrollbar, /system-scrollbar-track/);
  assert.match(scrollbar, /system-scrollbar-thumb/);
  assert.match(scrollbar, /aria-disabled=\{!canScroll\}/);
  assert.match(scrollbar, /data-dragging=\{dragging\}/);
  assert.match(scrollbar, /onPointerDown=\{startDrag\} onPointerMove=\{drag\}/);
  assert.equal((scrollbar.match(/system-scrollbar-arrow/g) || []).length, 2);
  assert.match(css, /\.system-scrollbar-thumb\[data-dragging="true"\]/);
  assert.match(rule('.system-scrollbar-track[aria-disabled="true"] .system-scrollbar-thumb'), /var\(--system-scrollbar-disabled\)/);
  assert.match(rule('.scrollbar-hide'), /scrollbar-width: none/);
  assert.match(rule('.scrollbar-hide::-webkit-scrollbar'), /display: none/);
});
