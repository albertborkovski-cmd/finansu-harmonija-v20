import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const compile = source => ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } }).outputText;
const url = source => `data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;
const lifecycleUrl = url(compile(read('../src/lib/recordLifecycle.ts')));
const statusUrl = url(compile(read('../src/lib/externalRoleUserStatus.ts')).replace("'./recordLifecycle'", JSON.stringify(lifecycleUrl)));
const { usersAssignedToRoles, assignedUsersStatusAction, toggleExternalUsers, isExternalUserInactive, EXTERNAL_USERS_STORAGE_KEY } = await import(statusUrl);
const identitySource = read('../src/components/SettingsIdentityManagementView.tsx');
const roles = [{ id: 'client', name: 'Client' }, { id: 'auditor', name: 'External auditor' }];
const user = (id, assigned = 'Client', extra = {}) => ({ id, email: `${id}@example.test`, fullName: id, roles: assigned, status: 'Active', organizations: 'Alice Stone', activityLog: '[]', ...extra });
const toggle = (users, ids = users.map(row => row.id)) => toggleExternalUsers(users, new Set(ids), 'Administrator', '2026-10-30 15:00');

test('selected role IDs target only their current assigned users and deduplicate overlapping roles', () => {
  const users = [user('one'), user('two', ' client , EXTERNAL AUDITOR '), user('three', 'External auditor'), user('unrelated', 'Other')];
  assert.deepEqual(usersAssignedToRoles(roles, users, new Set(['client', 'auditor'])).map(row => row.id), ['one', 'two', 'three']);
  assert.equal(usersAssignedToRoles(roles, users, new Set(['deleted-role'])).length, 0);
  assert.equal(assignedUsersStatusAction([]), null);
});

test('deactivation and second-click activation preserve roles, companies, permissions and history', () => {
  const original = [user('one', 'Client', { permissions: 'READ, UPDATE', documentsEdited: '4' }), user('other', 'Client')];
  const disabled = toggle(original, ['one']);
  assert.equal(disabled.action, 'deactivate');
  assert.deepEqual(disabled.changedIds, ['one']);
  assert.equal(disabled.users[0].status, 'Inactive');
  assert.equal(disabled.users[0].inactive, 'true');
  assert.equal(disabled.users[0].active, 'false');
  assert.equal(disabled.users[0].statusBeforeRoleDeactivation, 'Active');
  assert.equal(disabled.users[1], original[1]);
  assert.equal(original[0].status, 'Active');
  const restored = toggle(JSON.parse(JSON.stringify(disabled.users)), ['one']);
  assert.equal(restored.action, 'activate');
  assert.equal(restored.users[0].status, 'Active');
  assert.equal(restored.users[0].inactive, 'false');
  assert.equal(restored.users[0].active, 'true');
  assert.equal(restored.users[0].statusBeforeRoleDeactivation, undefined);
  for (const key of ['roles', 'organizations', 'permissions', 'activityLog', 'documentsEdited']) assert.equal(restored.users[0][key], original[0][key]);
  assert.deepEqual(roles, [{ id: 'client', name: 'Client' }, { id: 'auditor', name: 'External auditor' }]);
});

test('mixed selection first deactivates active users, then re-enables the whole selected group', () => {
  const inactive = user('inactive', 'Client', { status: 'Inactive', inactive: 'true', active: 'false' });
  const first = toggle([inactive, user('active')]);
  assert.equal(first.action, 'deactivate');
  assert.deepEqual(first.changedIds, ['active']);
  assert.equal(first.users[0], inactive);
  const second = toggle(first.users);
  assert.equal(second.action, 'activate');
  assert.deepEqual(second.changedIds, ['inactive', 'active']);
  assert.ok(second.users.every(row => row.status === 'Active'));
});

test('re-enabling does not activate pending invitations or remove an independent block', () => {
  const original = [user('pending', 'Client', { status: 'Unactivated' }), user('blocked', 'Client', { status: 'Blocked' })];
  const restored = toggle(toggle(original).users).users;
  assert.deepEqual(restored.map(row => row.status), ['Unactivated', 'Blocked']);
  assert.ok(restored.every(row => row.inactive === 'false'));
});

test('legacy enabled flags are restored and stale/empty selections are no-ops', () => {
  const original = [user('legacy', 'Client', { status: 'Enabled', enabled: 'true' })];
  const disabled = toggle(original);
  assert.equal(disabled.users[0].enabled, 'false');
  assert.equal(toggle(disabled.users).users[0].enabled, 'true');
  assert.equal(toggle(original, []).action, null);
  assert.deepEqual(toggle(original, ['deleted']).changedIds, []);
  assert.equal(toggle(original, ['deleted']).users[0], original[0]);
});

test('user selection does not depend on roles or expand to other users sharing those roles', () => {
  const original = [user('one'), user('two'), user('no-role', ''), user('other', 'External auditor')];
  const changed = toggle(original, ['one', 'no-role', 'deleted-user']);
  assert.deepEqual(changed.changedIds, ['one', 'no-role']);
  assert.equal(changed.selectedCount, 2);
  assert.equal(changed.users[1], original[1]);
  assert.equal(changed.users[3], original[3]);
  assert.deepEqual(toggle(original, ['client']).changedIds, []);
});

test('users disabled by the previous Roles action can be restored from Users', () => {
  const disabled = user('old', 'Client', { status: 'Inactive', inactive: 'true', active: 'false', statusBeforeRoleDeactivation: 'Unactivated' });
  const restored = toggle([disabled]);
  assert.equal(restored.action, 'activate');
  assert.equal(restored.users[0].status, 'Unactivated');
  assert.equal(restored.users[0].inactive, 'false');
});

test('session check reads only the external directory and supports retained boolean inactive flags', () => {
  const storage = { getItem(key) { assert.equal(key, EXTERNAL_USERS_STORAGE_KEY); return JSON.stringify([user('one', 'Client', { inactive: true })]); } };
  assert.equal(isExternalUserInactive(' ONE@example.test ', storage), true);
  assert.equal(isExternalUserInactive('other@example.test', storage), false);
  assert.equal(isExternalUserInactive('one@example.test', { getItem: () => '[]' }), false);
});

function declaration(source, name) {
  const tree = ts.createSourceFile('source.tsx', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  let found;
  const visit = node => {
    if (ts.isVariableDeclaration(node) && node.name.getText(tree) === name) found = `const ${node.getText(tree)};`;
    ts.forEachChild(node, visit);
  };
  visit(tree);
  assert.ok(found, `Missing ${name}`);
  return found;
}

const handler = await import(url(compile(`
  import { toggleExternalUsers } from ${JSON.stringify(statusUrl)};
  let audience, section, selected;
  const loadRows = (audience, section) => globalThis.statusFixture[audience][section];
  const persistRows = (audience, section, rows) => { globalThis.statusFixture[audience][section] = rows; };
  const setRows = rows => { globalThis.statusFixture.rendered = rows; };
  const setUserStatusNotice = notice => { globalThis.statusFixture.notice = notice; };
  const getCurrentUserName = () => 'Administrator';
  const timestamp = () => '2026-10-29 15:00';
  ${declaration(identitySource, 'toggleSelectedExternalUsers')}
  export function run(nextAudience, nextSection, ids) { audience = nextAudience; section = nextSection; selected = new Set(ids); toggleSelectedExternalUsers(); }
`)));

test('handler rechecks current users, persists only selected external users, and keeps selection intact', () => {
  const internal = { Roles: [{ id: 'client', name: 'Client' }], Users: [user('internal')] };
  globalThis.statusFixture = { 'External users': { Roles: roles, Users: [user('selected'), user('same-role')] }, 'Internal users': internal };
  handler.run('External users', 'Users', ['selected']);
  assert.equal(statusFixture['External users'].Users[0].status, 'Inactive');
  assert.equal(statusFixture['External users'].Users[1].status, 'Active');
  assert.equal(statusFixture.rendered, statusFixture['External users'].Users);
  assert.equal(statusFixture['External users'].Roles, roles);
  assert.equal(statusFixture['Internal users'], internal);
  handler.run('External users', 'Users', ['selected']);
  assert.equal(statusFixture['External users'].Users[0].status, 'Active');
  for (const [audience, section] of [['Internal users', 'Roles'], ['Internal users', 'Users'], ['External users', 'Roles']]) {
    handler.run(audience, section, ['selected', 'internal']);
    assert.equal(statusFixture['External users'].Users[0].status, 'Active');
    assert.equal(statusFixture['Internal users'].Users[0].status, 'Active');
  }
  assert.doesNotMatch(declaration(identitySource, 'toggleSelectedExternalUsers'), /setSelected|removeOrDeactivateRecords|loadRows\('External users', 'Roles'\)/);
});

test('bulk control replaces delete in external Users only and sessions observe status changes', () => {
  const control = identitySource.match(/section === 'Users' && audience === 'External users' && <button[\s\S]*?<\/button>/)?.[0];
  assert.ok(control);
  assert.match(control, /data-button-family="bulk-user-status"/);
  assert.match(control, /<Power size=\{16\} aria-hidden="true" \/>/);
  assert.match(control, /bg-transparent p-0 text-\[#7288A3\] transition-colors enabled:hover:text-\[#007EA7\]/);
  assert.match(control, /disabled:cursor-not-allowed disabled:opacity-40/);
  assert.match(control, /disabled=\{!externalUsersAction\}/);
  assert.match(control, /onClick=\{toggleSelectedExternalUsers\}/);
  assert.doesNotMatch(identitySource, /BulkDeleteButton|users assigned to selected roles|toggleAssignedExternalUsers/);
  assert.match(identitySource, /selectedExternalUsers = useMemo\(\(\) => audience === 'External users' && section === 'Users'\s*\? rows\.filter\(user => selected\.has\(user\.id\)\)/);
  assert.doesNotMatch(control, /PageActionButton|<span|bg-\[#F5F5F5\]|text-\[#B4B6B8\]/);
  assert.equal(read('../src/index.css').match(/button\[data-button-family="bulk-user-status"\]/g)?.length, 2);
  const app = read('../src/App.tsx');
  assert.match(app, /if \(isExternalUserInactive\(session.email, window.localStorage\)\)/);
  assert.match(app, /addEventListener\(SETTINGS_DATA_CHANGED_EVENT, check\)/);
  assert.match(app, /removeEventListener\(SETTINGS_DATA_CHANGED_EVENT, check\)/);
});

test('new logins and reloaded sessions deny deactivated external users, including the demo persona', async () => {
  const access = await import(url(compile(read('../src/lib/accessControl.ts')).replace("'./recordLifecycle'", JSON.stringify(lifecycleUrl))));
  const values = new Map([[EXTERNAL_USERS_STORAGE_KEY, JSON.stringify(toggle([user('aurika', 'Client', { email: 'aurika.z@meso.lt' })]).users)]]);
  globalThis.localStorage = { getItem: key => values.get(key) ?? null };
  assert.deepEqual(access.resolveSessionForEmail('aurika.z@meso.lt').roleNames, ['Inactive']);
  assert.deepEqual(access.parseSession(JSON.stringify({ email: 'aurika.z@meso.lt' })).roleNames, ['Inactive']);
  assert.ok(access.resolveSessionForEmail('albertborkvski@gmail.com').roleNames.includes('Administrator'));
  values.set(EXTERNAL_USERS_STORAGE_KEY, JSON.stringify(toggle(JSON.parse(values.get(EXTERNAL_USERS_STORAGE_KEY))).users));
  assert.deepEqual(access.resolveSessionForEmail('aurika.z@meso.lt').roleNames, ['External demo user']);
});
