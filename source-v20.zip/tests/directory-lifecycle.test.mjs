import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = (path) => readFileSync(new URL(path, import.meta.url), 'utf8');
const transpile = (source) => ts.transpileModule(source, {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext },
}).outputText;
const moduleUrl = (source) => `data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;
const lifecycleUrl = moduleUrl(transpile(read('../src/lib/recordLifecycle.ts')));
const identitySource = read('../src/components/SettingsIdentityManagementView.tsx');
const emailSource = read('../src/components/OrganizationEmailSettingsView.tsx');

function declaration(source, name) {
  const tree = ts.createSourceFile('component.tsx', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  let found;
  const visit = (node) => {
    if (ts.isFunctionDeclaration(node) && node.name?.text === name) found = node.getText(tree);
    if (ts.isVariableDeclaration(node) && node.name.getText(tree) === name) found = `const ${node.getText(tree)};`;
    ts.forEachChild(node, visit);
  };
  visit(tree);
  assert.ok(found, `Missing ${name}`);
  return found;
}

const directory = await import(moduleUrl(transpile(`
  import { isInactiveRecord, isRecordLinked, removeOrDeactivateRecords } from ${JSON.stringify(lifecycleUrl)};
  const storageKey = (audience, section) => 'finansu-harmonija:test:' + audience + ':' + section;
  const loadRows = (_audience, section) => section === 'Users' ? globalThis.fixture.users : globalThis.fixture.roles;
  const readDeletedIds = () => new Set(globalThis.fixture.deleted);
  const persistDeletedIds = (_audience, _section, ids) => { globalThis.fixture.deleted = [...ids]; };
  const persistRows = (audience, section, rows) => { globalThis.fixture.persistedAudience = audience; globalThis.fixture[section === 'Users' ? 'users' : 'roles'] = rows; };
  const isProtectedSystemRole = (_audience, row) => row?.id === 'protected-role';
  const setRows = rows => { globalThis.fixture.rendered = rows; };
  const setSelected = selected => { globalThis.fixture.selected = selected; };
  let audience, section, key;
  ${declaration(identitySource, 'internalUserStatus')}
  ${declaration(identitySource, 'isDirectoryRowLinked')}
  ${declaration(identitySource, 'isRetainedInactiveDirectoryRow')}
  ${declaration(identitySource, 'roleDeleteDisabledReason')}
  ${declaration(identitySource, 'readRoles')}
  ${declaration(identitySource, 'remove')}
  export { internalUserStatus, isDirectoryRowLinked, isRetainedInactiveDirectoryRow, roleDeleteDisabledReason, readRoles };
  export function removeRows(nextSection, ids, nextAudience = 'Internal users') {
    audience = nextAudience; section = nextSection; key = storageKey(audience, section);
    remove(new Set(ids));
  }
`)));

const email = await import(moduleUrl(transpile(`
  const loadOrganizationEmailHistory = () => globalThis.fixture.history;
  let companyId, companyName;
  ${declaration(emailSource, 'hasTemplateHistory')}
  export function linked(template, id, name) { companyId = id; companyName = name; return hasTemplateHistory(template); }
`)));

const linkedData = await import(moduleUrl(transpile(read('../src/lib/linkedSettingsData.ts'))
  .replace(/(['"])\.\/supabase\1/g, JSON.stringify(moduleUrl('export const recordAdministrativeAction = async () => {};')))));

function setup(patch = {}) {
  const values = new Map();
  globalThis.window = { localStorage: {
    get length() { return values.size; },
    key: (index) => [...values.keys()][index] ?? null,
    getItem: (key) => values.get(key) ?? null,
    setItem: (key, value) => values.set(key, value),
  } };
  globalThis.fixture = { roles: [], users: [], deleted: [], history: [], ...patch };
  return globalThis.fixture;
}

for (const audience of ['Internal users', 'External users']) {
test(`${audience}: assigned, system and inactive roles cannot be deleted or deactivated`, () => {
  for (const userStatus of ['Active', 'Inactive']) {
    const roles = [
      { id: 'protected-role', name: 'Administrator' },
      { id: 'used', name: 'Auditor' },
      { id: 'inactive', name: 'Inactive', inactive: true, active: false },
    ];
    const fixture = setup({ roles, users: [{ id: 'user', roles: 'Reviewer, Auditor', status: userStatus }] });
    for (const role of roles) assert.ok(directory.roleDeleteDisabledReason(audience, role));
    directory.removeRows('Roles', roles.map((row) => row.id), audience);
    assert.deepEqual(fixture.roles, roles);
    assert.equal(fixture.users[0].roles, 'Reviewer, Auditor');
    assert.deepEqual(fixture.deleted, []);
    assert.equal(fixture.rendered, undefined);
  }
});

test(`${audience}: unused custom roles can be deleted`, () => {
  const role = { id: 'custom-role', name: 'Unused custom role' };
  const fixture = setup({ roles: [role] });
  assert.equal(directory.roleDeleteDisabledReason(audience, role), undefined);
  directory.removeRows('Roles', [role.id], audience);
  assert.deepEqual(fixture.roles, []);
  assert.deepEqual(fixture.deleted, [role.id]);
  assert.equal(fixture.persistedAudience, audience);
});

test(`${audience}: deletion rechecks user assignments instead of relying on the displayed count`, () => {
  const role = { id: 'custom-role', name: 'Auditor', assignedUsers: '0' };
  const fixture = setup({ roles: [role] });
  assert.equal(directory.roleDeleteDisabledReason(audience, role), undefined);
  fixture.users.push({ id: 'user', roles: 'Reviewer, AUDITOR ' });
  directory.removeRows('Roles', [role.id], audience);
  assert.deepEqual(fixture.roles, [role]);
  assert.deepEqual(fixture.deleted, []);
  assert.equal(fixture.roles[0].inactive, undefined);
});

test(`${audience}: roles referenced by other records remain intact`, () => {
  const role = { id: 'custom-role', name: 'Auditor' };
  const fixture = setup({ roles: [role] });
  window.localStorage.setItem('finansu-harmonija:test:related-records', JSON.stringify([{ roleId: role.id }]));
  assert.ok(directory.roleDeleteDisabledReason(audience, role));
  directory.removeRows('Roles', [role.id], audience);
  assert.deepEqual(fixture.roles, [role]);
  assert.deepEqual(fixture.deleted, []);
});
}

test('user relationships and history remain intact after deactivation', () => {
  const fixture = setup({ users: [{ id: 'user', fullName: 'Test User', roles: 'Auditor', organizations: 'Example', status: 'Active', documentsCreated: '2' }] });
  directory.removeRows('Users', ['user']);
  assert.equal(fixture.users[0].status, 'Inactive');
  assert.equal(fixture.users[0].roles, 'Auditor');
  assert.equal(fixture.users[0].organizations, 'Example');
  assert.equal(fixture.users[0].documentsCreated, '2');
  assert.deepEqual(fixture.deleted, []);
  assert.equal(directory.internalUserStatus(fixture.users[0].status), 'Inactive');
});

test('unused users can still be physically deleted and tombstoned', () => {
  const fixture = setup({ users: [{ id: 'unused', fullName: 'Unused' }] });
  directory.removeRows('Users', ['unused']);
  assert.deepEqual(fixture.users, []);
  assert.deepEqual(fixture.deleted, ['unused']);
});

const unusedInternalUser = {
  id: 'unused-internal', fullName: 'Unused Internal User', email: 'unused@example.test',
  roles: 'Meso accountant', organizations: 'Unassigned', status: 'Unactivated',
  lastLogin: 'No login recorded', loginHistory: '[]', documentsCreated: '0', documentsEdited: '0',
  activityLog: JSON.stringify([{ action: 'Created user profile' }, { action: 'Updated user profile' }]),
};

test('a mandatory role and administrator profile edits do not prevent deleting an unused internal user', () => {
  const fixture = setup({ users: [{ ...unusedInternalUser }] });
  assert.equal(directory.isDirectoryRowLinked('Internal users', 'Users', fixture.users[0]), false);
  directory.removeRows('Users', [unusedInternalUser.id]);
  assert.deepEqual(fixture.users, []);
  assert.deepEqual(fixture.deleted, [unusedInternalUser.id]);
});

test('unused internal users previously deactivated by the old policy can be deleted', () => {
  const user = { ...unusedInternalUser, status: 'Inactive', inactive: true, active: false };
  const fixture = setup({ users: [user] });
  assert.equal(directory.isRetainedInactiveDirectoryRow('Internal users', 'Users', user), false);
  directory.removeRows('Users', [user.id]);
  assert.deepEqual(fixture.users, []);
  assert.deepEqual(fixture.deleted, [user.id]);
});

test('organization assignments, document counters and real history each retain internal users', () => {
  for (const usage of [
    { organizations: 'Alice Stone' },
    { organizations: 'All organizations' },
    { documentsCreated: '1' },
    { documentsEdited: '1' },
    { lastLogin: '2026-10-29 12:00' },
    { loginHistory: JSON.stringify([{ date: '2026-10-29', status: 'Successful' }]) },
    { activityLog: JSON.stringify([{ action: 'Edited document INV-001' }]) },
    { activityLog: '{unreadable' },
    { activityLog: '{"unexpected":"history"}' },
  ]) {
    const user = { ...unusedInternalUser, ...usage };
    const fixture = setup({ users: [user] });
    assert.equal(directory.isDirectoryRowLinked('Internal users', 'Users', user), true);
    directory.removeRows('Users', [user.id]);
    assert.equal(fixture.users[0].inactive, true);
    assert.equal(fixture.users[0].activityLog, user.activityLog);
    assert.deepEqual(fixture.deleted, []);
  }
});

test('persisted company assignments and documents protect users even when their profile appears unused', () => {
  for (const [key, references] of [
    ['finansu-harmonija:v7:organization-users:alice:internal', [unusedInternalUser.id]],
    ['finansu-harmonija-v4:data:documents', [{ id: 'doc-1', created_by: unusedInternalUser.fullName }]],
    ['finansu-harmonija-v4:data:document_history', [{ id: 'history-1', user_id: unusedInternalUser.id }]],
  ]) {
    const fixture = setup({ users: [{ ...unusedInternalUser }] });
    window.localStorage.setItem(key, JSON.stringify(references));
    directory.removeRows('Users', [unusedInternalUser.id]);
    assert.equal(fixture.users[0].inactive, true);
    assert.deepEqual(fixture.deleted, []);
  }
});

test('bulk deletion rechecks current relationships and retains previously used inactive accounts', () => {
  const usedInactive = { ...unusedInternalUser, id: 'used-inactive', documentsEdited: '1', inactive: true, active: false };
  const nowAssigned = { ...unusedInternalUser, id: 'now-assigned' };
  const fixture = setup({ users: [{ ...unusedInternalUser }, usedInactive, nowAssigned] });
  assert.equal(directory.isDirectoryRowLinked('Internal users', 'Users', nowAssigned), false);
  window.localStorage.setItem('finansu-harmonija:v7:organization-users:alice:internal', JSON.stringify([nowAssigned.id]));
  directory.removeRows('Users', fixture.users.map((user) => user.id));
  assert.deepEqual(fixture.users.map((user) => user.id), ['used-inactive', 'now-assigned']);
  assert.ok(fixture.users.every((user) => user.inactive));
  assert.deepEqual(fixture.deleted, [unusedInternalUser.id]);
});

test('external user lifecycle remains unchanged', () => {
  const fixture = setup({ users: [{ ...unusedInternalUser }] });
  directory.removeRows('Users', [unusedInternalUser.id], 'External users');
  assert.equal(fixture.users[0].inactive, true);
  assert.deepEqual(fixture.deleted, []);
});

test('bulk deletion is absent; External Users have a status toggle and individual lifecycle actions remain', () => {
  assert.doesNotMatch(identitySource, /BulkDeleteButton/);
  assert.match(identitySource, /\{section === 'Users' && audience === 'External users' && <button\s+type="button"\s+data-button-family="bulk-user-status"/);
  assert.match(identitySource, /\{section === 'Users' && <RowDeleteButton/);
});

test('internal and external roles share duplicate and guarded delete controls and action width', () => {
  assert.match(identitySource, /\{section === 'Roles' && <RowDeleteButton/);
  assert.match(identitySource, /\{section === 'Roles' && \(\s*<button[\s\S]*?onClick=\{\(\) => duplicateRole\(row\)\}/);
  assert.match(identitySource, /disabled=\{Boolean\(roleDeleteDisabledReason\(audience, row\)\)\}/);
  assert.equal(declaration(identitySource, 'actionColumnWidth'), 'const actionColumnWidth = 104;');
  assert.doesNotMatch(declaration(identitySource, 'roleDeleteDisabledReason'), /audience !== 'Internal users'/);
  assert.doesNotMatch(declaration(identitySource, 'remove'), /section === 'Roles' && audience !== 'Internal users'/);
});

const duplication = await import(moduleUrl(transpile(`
  let template, editing;
  const setRoleTemplate = value => { template = value; };
  const setEditing = value => { editing = value; };
  const isSystemAdministratorRole = () => false;
  const isInactiveRecord = row => row.inactive === true;
  const useState = value => [typeof value === 'function' ? value() : value, () => {}];
  const useMemo = callback => callback();
  ${declaration(identitySource, 'duplicateRole')}
  export function duplicate(source, audience, users) {
    duplicateRole(source);
    const initial = undefined;
    const loadRows = requestedAudience => { if (requestedAudience !== audience) throw new Error('Wrong audience'); return users; };
    ${declaration(identitySource, '[name, setName]')}
    ${declaration(identitySource, 'configuration')}
    ${declaration(identitySource, 'availableUsers')}
    ${declaration(identitySource, '[assignedUserIds, setAssignedUserIds]')}
    return { editing, name, configuration, assignedUserIds };
  }
`)));

test('both audiences duplicate configuration into a new unnamed role without assigned users', () => {
  for (const audience of ['Internal users', 'External users']) {
    const role = { id: 'original', name: 'Reviewer', description: 'Review documents', assignedUsers: '1',
      permissions: 'READ, UPDATE', menuAccess: '{"documents":{"view":true,"edit":true}}',
      actionPermissions: '{"documents":["READ","UPDATE"]}', menuVisibility: '{"documents":true}',
      managedOrganizations: 'Alice Stone', managedUsers: 'user-one', managedRoles: 'Reviewer' };
    const result = duplication.duplicate(role, audience, [{ id: 'assigned', roles: 'Reviewer' }]);
    assert.equal(result.editing, 'new');
    assert.equal(result.name, '');
    assert.deepEqual(result.assignedUserIds, []);
    assert.deepEqual(result.configuration, role);
    assert.notEqual(result.configuration, role);
    assert.match(identitySource, /disabled=\{!name\.trim\(\)\}/);
    assert.match(identitySource, /id: initial\?\.id \?\? `role-\$\{Date\.now\(\)\}`/);
  }
});

test('inactive roles remain in the directory but cannot be assigned to new users', () => {
  setup({ roles: [{ id: 'active', name: 'Active role' }, { id: 'inactive', name: 'Inactive role', inactive: true }] });
  assert.deepEqual(directory.readRoles('Internal users'), ['Active role']);
  assert.equal(globalThis.fixture.roles.length, 2);
});

test('built-in directory defaults never overwrite saved inactive state', () => {
  setup();
  const key = linkedData.directoryStorageKey('Internal users');
  const inactive = { id: 'user-system-administrator', email: 'albertborkvski@gmail.com', status: 'Inactive', inactive: true, active: false };
  window.localStorage.setItem(key, JSON.stringify([inactive]));
  const user = linkedData.loadLinkedDirectoryUsers('Internal users').find((row) => row.id === inactive.id);
  assert.equal(user.status, 'Inactive');
  assert.equal(user.inactive, true);
  assert.equal(user.active, false);
  assert.equal(linkedData.loadLinkedDirectoryUsers('Internal users').filter((row) => row.id === inactive.id).length, 1);
});

test('email history protects templates by name, language and organization', () => {
  setup({ history: [{ templateName: 'Debt reconciliation', language: 'EN', organizationId: 'org-one', sender: 'Example' }] });
  const template = { name: 'Debt reconciliation', language: 'EN' };
  assert.equal(email.linked(template, 'org-one', 'Example'), true);
  assert.equal(email.linked(template, 'org-two', 'Other'), false);
  assert.equal(email.linked({ ...template, language: 'LT' }, 'org-one', 'Example'), false);
  assert.equal(email.linked(template), true);
});

test('legacy email history is matched to the original organization name', () => {
  setup({ history: [{ templateName: 'Debt reconciliation', language: 'EN', sender: 'Example' }] });
  assert.equal(email.linked({ name: 'Debt reconciliation', language: 'EN' }, 'org-one', 'Example'), true);
  assert.equal(email.linked({ name: 'Debt reconciliation', language: 'EN' }, 'org-two', 'Other'), false);
});

test('all directory tables expose full-row inactive styling and shared lifecycle actions', () => {
  for (const name of ['Companies', 'CompanyClientsView', 'SettingsIdentityManagementView', 'OrganizationEmailSettingsView']) {
    const source = read(`../src/components/${name}.tsx`);
    assert.match(source, /data-record-inactive=\{isInactiveRecord\(/, name);
    assert.match(source, /removeOrDeactivateRecords\(/, name);
    assert.match(source, /<RowDeleteButton/, name);
  }
  assert.match(read('../src/components/CompanyClientsView.tsx'), /\{ \.\.\.client, \.\.\.normalized \}/);
  assert.match(identitySource, /const savedRow = \{ \.\.\.existing, \.\.\.row \}/);
});
