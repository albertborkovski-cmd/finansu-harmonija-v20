import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const api = {};
new Function('exports', ts.transpileModule(read('../src/lib/documentProcessingStatus.ts'), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
}).outputText)(api);

test('processing options remove only Overdue, retaining all other choices', () => {
  assert.deepEqual(api.DOCUMENT_PROCESSING_STATUSES, [
    'Draft', 'Pending', 'Paid', 'Processing', 'Rejected', 'Provide Additional',
    'Exception', 'Transferred', 'Duplicate', 'Not Documented',
  ]);
});

test('legacy payment lateness is not displayed as processing status or converted into approval', () => {
  const record = Object.freeze({ status: 'Overdue', due_end_date: '2025-01-01' });
  for (const value of [record.status, ' overdue ', 'OVERDUE']) assert.equal(api.documentProcessingStatus(value), '');
  assert.equal(record.status, 'Overdue');
  assert.equal(record.due_end_date, '2025-01-01');
  for (const status of [...api.DOCUMENT_PROCESSING_STATUSES, 'New', 'Approved', 'Correcting', 'Manual'])
    assert.equal(api.documentProcessingStatus(status), status);
});

test('list, status filter, create and copy use shared processing states without changing historical data', () => {
  const list = read('../src/components/Documents.tsx');
  const form = read('../src/components/CreateDocumentModal.tsx');
  assert.match(list, /\.\.\.DOCUMENT_PROCESSING_STATUSES/);
  assert.match(list, /new Set\(docs\.map\(\(document\) => documentProcessingStatus\(document.status\)\)/);
  assert.match(list, /documentProcessingStatus\(doc.status\) \|\| '—'/);
  assert.match(form, /const STATUSES = DOCUMENT_PROCESSING_STATUSES/);
  assert.match(form, /status: documentProcessingStatus\(initialData\?\.status \?\? EMPTY.status\) \|\| \(viewOnly \? '' : 'Draft'\)/);
  assert.match(read('../src/components/DocumentDetailPanel.tsx'), /Overdue: "#EF4444"/); // Existing audit history remains readable.
});
