import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = file => readFileSync(new URL(file, import.meta.url), 'utf8');
const compile = file => ts.transpileModule(source(file), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const core = {};
new Function('exports', compile('../src/lib/documentInlineEditing.ts'))(core);
const fixture = (allocations = 1, products = 20) => ({
  id: 'doc-1', company_id: 'company-1', status: 'Draft', notes: 'Original note', document_purpose: 'Office supplies', order_no: 'PO-1',
  expense_account: '6000', vat_classifier: 'PVM1', department_code: 'D1', object_project: 'P1', cost_center: 'C1', series: 'INV',
  summary_line_items: Array.from({ length: allocations }, (_, i) => ({ id: `allocation-${i}`, expense: '6000', vatClass: 'PVM1', department: 'D1', object: 'P1', center: 'C1', subtotal: '100.00', total: '121.00' })),
  line_items: Array.from({ length: products }, (_, i) => ({ id: `ocr-${i}`, product: `Product ${i}`, qty: '1', expense: 'OCR raw value' })),
});
const patch = (doc, key, value, allowed = true) => core.documentInlinePatch(doc, key, value, core.documentInlineSnapshot(doc), allowed);

test('accounting allocation count never uses the number of OCR products', () => {
  assert.equal(core.documentAllocationCount(fixture(1, 40)), 1);
  assert.equal(core.documentAllocationCount(fixture(3, 1)), 3);
  assert.equal(core.documentAllocationCount(fixture(2, 0)), 2);
  assert.equal(core.documentAllocationCount(fixture(0, 40)), 1); // Legacy document-level allocation.
  assert.equal(core.documentAllocationCount({ ...fixture(), summary_line_items: 'invalid' }), 0);
});

test('document-level fields are editable with multiple allocations and change no allocation/product data', () => {
  const doc = fixture(3), original = structuredClone(doc);
  assert.deepEqual(patch(doc, 'note', 'New note'), { notes: 'New note' });
  assert.deepEqual(patch(doc, 'accountableResponsible', 'Test person'), { accountable_responsible: 'Test person' });
  assert.deepEqual(patch(doc, 'type', 'Purchase'), { type: 'Purchase' });
  assert.deepEqual(patch(doc, 'documentType', 'Invoices'), { document_type: 'Invoices', document_subtype: '' });
  assert.deepEqual(patch(doc, 'documentPurpose', 'Services'), { document_purpose: 'Services' });
  assert.deepEqual(patch(doc, 'orderNo', 'PO-2'), { order_no: 'PO-2' });
  assert.deepEqual(patch(doc, 'series', 'NEW'), { series: 'NEW' });
  assert.deepEqual(doc, original);
});

test('single-allocation edits update only that allocation and header, never OCR rows or amounts', () => {
  const doc = fixture(1, 40);
  for (const [key, [db, lineKey]] of Object.entries(core.DOCUMENT_ALLOCATION_FIELDS)) {
    const change = patch(doc, key, 'new');
    assert.equal(change[db], 'new');
    assert.deepEqual(change.summary_line_items, [{ ...doc.summary_line_items[0], [lineKey]: 'new' }]);
    assert.equal(change.line_items, undefined);
    assert.equal(change.summary_line_items[0].subtotal, '100.00');
  }
});

test('multiple allocations cannot be mass-overwritten, even when their GL accounts are identical', () => {
  const doc = fixture(2, 1);
  for (const key of Object.keys(core.DOCUMENT_ALLOCATION_FIELDS)) assert.throws(() => patch(doc, key, 'new'), /document card/);
  assert.equal(core.documentInlineValue(doc, 'expenseAccount'), '6000');
  doc.summary_line_items[1].expense = '6300';
  assert.equal(core.documentInlineValue(doc, 'expenseAccount'), '');
});

test('rights, confirmed/transferred/in-flight states and invalid fields block every direct edit', () => {
  for (const key of ['note', 'expenseAccount', 'type', 'accountableResponsible', 'documentType', 'orderNo', 'documentPurpose']) {
    assert.throws(() => patch(fixture(), key, 'new', false), /access/);
    for (const overrides of [
      { status: 'Approved' }, { status: 'Transferred' }, { status: 'Processing' }, { accounting_note_status: 'Approved' },
      { accounting_posting: {} }, { accounting_storno: {} }, { inactive: true }, { is_active: false }, { exported_at: '2026-11-03' },
    ]) assert.throws(() => patch({ ...fixture(), ...overrides }, key, 'new'));
  }
  for (const key of ['company_id', 'status', 'number', 'line_items']) assert.throws(() => patch(fixture(), key, 'new'), /document card/);
});

test('changing document type clears only the old subtype and requires a nonempty value', () => {
  const doc = { ...fixture(3), document_type: 'Invoices', document_subtype: 'Credit invoice' };
  assert.deepEqual(patch(doc, 'documentType', 'Contracts'), { document_type: 'Contracts', document_subtype: '' });
  assert.deepEqual(patch(doc, 'documentType', 'Invoices'), { document_type: 'Invoices' });
  assert.throws(() => patch(doc, 'documentType', ''), /required/);
  const snapshot = core.documentInlineSnapshot(doc);
  doc.document_subtype = 'Standard invoice';
  assert.throws(() => core.documentInlinePatch(doc, 'documentType', 'Contracts', snapshot, true), /changed/);
});

test('stale form values and allocation changes are rejected before any overwrite', () => {
  const doc = fixture(), snapshot = core.documentInlineSnapshot(doc);
  doc.notes = 'Changed by another accountant';
  assert.throws(() => core.documentInlinePatch(doc, 'note', 'overwrite', snapshot, true), /changed/);
  const split = fixture(2);
  assert.throws(() => core.documentInlinePatch(split, 'expenseAccount', '6300', snapshot, true), /document card/);
});

function adapterFixture() {
  const store = new Map(); const localStorage = { getItem: key => store.get(key) ?? null, setItem: (key, value) => store.set(key, value) };
  let allowed = true;
  const issues = {}, storno = {}, api = {};
  new Function('exports', compile('../src/lib/documentIssues.ts'))(issues);
  new Function('exports', compile('../src/lib/documentStorno.ts'))(storno);
  const require = name => {
    if (name === './documentInlineEditing') return core;
    if (name === './documentEditAccess') return { canEditCompanyDocuments: () => allowed };
    if (name === './documentIssues') return issues;
    if (name === './documentStorno') return storno;
    if (name === './currentUser') return { getCurrentUserName: () => 'Test accountant' };
    if (name === './generalLedgerUsage') return { rememberLedgerTableUsage() {} };
    if (name === './recordLifecycle') return { removeOrDeactivateRecords: rows => rows };
    throw Error(name);
  };
  new Function('exports', 'require', 'window', 'navigator', 'fetch', 'CustomEvent', compile('../src/lib/supabase.ts'))(api, require,
    { localStorage, setTimeout, clearTimeout, dispatchEvent() {} }, {}, async () => { throw Error('Static test'); }, class {});
  const put = (table, rows) => store.set(`finansu-harmonija-v4:data:${table}`, JSON.stringify(rows));
  const get = table => JSON.parse(store.get(`finansu-harmonija-v4:data:${table}`));
  put('documents', [fixture()]); put('companies', [{ id: 'company-1', name: 'Company 1' }]); put('document_history', []);
  return { ...api, put, get, revoke: () => { allowed = false; } };
}

test('actual write command persists changes and audit; concurrent stale writes cannot overwrite them', async () => {
  const f = adapterFixture(), doc = fixture(), snapshot = core.documentInlineSnapshot(doc);
  const results = await Promise.allSettled([
    f.applyDocumentInlineEdit(doc.id, doc.company_id, 'note', 'Saved note', snapshot),
    f.applyDocumentInlineEdit(doc.id, doc.company_id, 'note', 'Stale overwrite', snapshot),
  ]);
  assert.equal(results.filter(row => row.status === 'fulfilled').length, 1);
  const saved = f.get('documents')[0];
  assert.equal(saved.notes, 'Saved note');
  assert.deepEqual(saved.line_items, doc.line_items); assert.deepEqual(saved.summary_line_items, doc.summary_line_items);
  assert.equal(saved.inline_edit_history.length, 1); assert.equal(f.get('document_history').length, 1);
  assert.match(saved.inline_edit_history[0].details, /Original note.*Saved note/);
});

test('actual command rechecks organization, permission, allocation count and document status', async () => {
  const f = adapterFixture(), doc = fixture(), snapshot = core.documentInlineSnapshot(doc);
  await assert.rejects(f.applyDocumentInlineEdit(doc.id, 'another-company', 'note', 'x', snapshot), /moved/);
  f.put('documents', [fixture(2)]);
  await assert.rejects(f.applyDocumentInlineEdit(doc.id, doc.company_id, 'expenseAccount', '6300', snapshot), /document card/);
  f.put('documents', [{ ...doc, status: 'Approved' }]);
  await assert.rejects(f.applyDocumentInlineEdit(doc.id, doc.company_id, 'note', 'x', snapshot), /confirmed/);
  f.put('documents', [doc]); f.revoke();
  await assert.rejects(f.applyDocumentInlineEdit(doc.id, doc.company_id, 'note', 'x', snapshot), /access/);
  assert.equal(f.get('document_history').length, 0);
});

test('UI uses the shared rule and existing document card, with no expanded-row bypass', () => {
  const list = source('../src/components/Documents.tsx');
  assert.match(list, /disabled=\{Boolean\(inlineError\(doc, col.key\)\)\}/);
  assert.doesNotMatch(list, /disabled=\{doc.hasProductDetails\}|updateDocumentLineLookup|updateLineItemProductGroup/);
  assert.match(list, /DocumentInlineTextCell/);
  assert.match(list, /key: "note", label: "Note"/);
  assert.match(list, /applyDocumentInlineEdit/);
  assert.match(list, /<DocumentDetailPanel/);
  assert.match(list, /col.key === 'documentType'[\s\S]*?<DocumentInlineSelectCell/);
  assert.match(list, /loadOrganizationReferenceRecords\('Document type'\)/);
  assert.match(list, /\['note', 'documentPurpose', 'orderNo', 'type', 'accountableResponsible'\]\.includes\(col.key\)/);
  assert.match(list, /aria-label=\{`Status for/);
});

test('all requested document fields persist independently of allocation count with audit', async () => {
  const f = adapterFixture();
  f.put('documents', [fixture(3, 1)]);
  const edits = { documentType: 'Invoices', orderNo: 'PO-UPDATED', type: 'Sale', documentPurpose: 'Updated purpose', accountableResponsible: 'Test person' };
  for (const [field, value] of Object.entries(edits)) {
    const current = f.get('documents')[0];
    await f.applyDocumentInlineEdit(current.id, current.company_id, field, value, core.documentInlineSnapshot(current));
    assert.equal(core.documentInlineValue(f.get('documents')[0], field), value);
  }
  assert.deepEqual(f.get('documents')[0].summary_line_items, fixture(3, 1).summary_line_items);
  assert.equal(f.get('documents')[0].inline_edit_history.length, Object.keys(edits).length);
  assert.equal(f.get('document_history').length, Object.keys(edits).length);
});

test('fresh role rights, active user status and explicit company assignments are all required', () => {
  const api = {}, store = new Map();
  let view = true, edit = true, scoped = true;
  const session = { email: 'test@example.invalid', roleNames: ['External accountant'] };
  const user = { id: 'test-user', email: session.email, status: 'Active', organizations: 'Company 1' };
  let assigned = [];
  const require = name => {
    if (name === './accessControl') return { parseSession: () => session, canViewMenu: () => view, canEditMenu: () => edit };
    if (name === './currentUser') return { AUTH_SESSION_KEY: 'session' };
    if (name === './recordLifecycle') return { isInactiveRecord: row => row.inactive === true };
    if (name === './linkedSettingsData') return {
      canAccessAssignedOrganization: () => scoped,
      loadLinkedDirectoryUsers: audience => audience === 'External users' ? [user] : [],
      loadOrganizationUserIds: () => assigned,
      organizationAssignmentStorageKey: id => `assignment:${id}`,
    };
    throw Error(name);
  };
  new Function('exports', 'require', 'window', compile('../src/lib/documentEditAccess.ts'))(api, require, { localStorage: { getItem: key => store.get(key) ?? null } });
  const company = { id: 'company-1', name: 'Company 1' };
  assert.equal(api.canEditCompanyDocuments(company), true);
  assert.equal(api.canEditCompanyDocuments({ id: 'company-2', name: 'Company 2' }), false);
  store.set('assignment:company-1', '[]');
  assert.equal(api.canEditCompanyDocuments(company), false);
  assigned = ['test-user']; assert.equal(api.canEditCompanyDocuments(company), true);
  edit = false; assert.equal(api.canEditCompanyDocuments(company), false); edit = true;
  view = false; assert.equal(api.canEditCompanyDocuments(company), false); view = true;
  scoped = false; assert.equal(api.canEditCompanyDocuments(company), false); scoped = true;
  for (const status of ['Blocked', 'Unactivated', 'Disabled']) { user.status = status; assert.equal(api.canEditCompanyDocuments(company), false); }
});
