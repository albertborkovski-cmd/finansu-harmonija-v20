import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const compile = path => ts.transpileModule(source(path), {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
}).outputText;
const core = {};
new Function('exports', compile('../src/lib/ocrLearning.ts'))(core);
const presentation = {};
new Function('require', 'exports', compile('../src/lib/ocrLearningPresentation.ts'))(id => {
  assert.equal(id, './ocrLearning');
  return core;
}, presentation);
const rows = core.learnedRows(core.createLearningExamples());
const { filterLearningRows, learnedColumnValue, learningStatusLabel, learningStatusReason, restoreLearningColumns, LEARNING_STATUS_FILTERS, LEARNING_VALUE_COLUMNS } = presentation;

test('column migration removes retired fields and preserves remaining column preferences', () => {
  const defaults = LEARNING_VALUE_COLUMNS.map(column => ({ ...column, key: `learned:${column.key}`, visible: true }));
  const restored = restoreLearningColumns([
    { key: 'learned:product_name', label: 'Product name', width: 245, visible: false },
    { key: 'vatRate', label: 'VAT rate', width: 85, visible: true },
    { key: 'learned:vat_classifier', label: 'VAT classifier', width: 190, visible: false },
    { key: 'learned:expense_account', label: 'Expense account', width: 175, visible: true },
  ], defaults);
  assert.equal(restored.length, LEARNING_VALUE_COLUMNS.length);
  assert.equal(restored[0].key, 'learned:vat_classifier');
  assert.equal(restored[0].visible, false);
  assert.equal(restored[0].width, 190);
  assert.equal(restored[1].width, 175);
  assert.equal(restored[1].visible, true);
  assert.ok(!restored.some(column => column.key === 'vatRate'));
  assert.deepEqual(new Set(restored.map(column => column.key)), new Set(defaults.map(column => column.key)));
  assert.deepEqual(restoreLearningColumns(restored, defaults), restored);
});

test('named columns only show their own confirmed learning, never context or unrelated extracted values', () => {
  const expense = rows.find(row => row.field === 'expense_account');
  const vat = rows.find(row => row.field === 'vat_classifier');
  assert.equal(learnedColumnValue(expense, 'learned:expense_account'), expense.value);
  assert.equal(learnedColumnValue(expense, 'learned:vat_classifier'), '');
  assert.equal(learnedColumnValue(vat, 'learned:vat_classifier'), 'PVM1');
  assert.equal(learnedColumnValue(vat, 'learned:expense_account'), '');
  assert.equal(learnedColumnValue(expense, 'value'), expense.value);
  assert.equal(learnedColumnValue(vat, 'value'), 'PVM1');
  assert.equal(learnedColumnValue({ ...expense, total: 0 }, 'value'), '');
  for (const key of ['counterparty_name', 'counterparty_code', 'product_name', 'unit_price', 'total_amount']) {
    assert.ok(!LEARNING_VALUE_COLUMNS.some(column => column.key === key));
    assert.equal(learnedColumnValue(expense, `learned:${key}`), '');
  }
  assert.equal(learnedColumnValue({ ...expense, total: 0 }, 'learned:expense_account'), '');
  assert.equal(new Set(LEARNING_VALUE_COLUMNS.map(column => column.key)).size, LEARNING_VALUE_COLUMNS.length);
  assert.ok(LEARNING_VALUE_COLUMNS.every(column => column.label !== 'VAT rate'));
  assert.deepEqual(LEARNING_VALUE_COLUMNS.map(column => column.label), ['Expense account', 'VAT classifier']);
});

test('restored Field and Value columns are visible together before the existing learning columns', () => {
  const defaults = ['companyName', 'supplierKey', 'field', 'value', 'learned:expense_account', 'learned:vat_classifier', 'status']
    .map(key => ({ key, visible: true, width: 160 }));
  const stored = defaults.filter(column => column.key !== 'field' && column.key !== 'value')
    .map(column => ({ ...column, width: 180 }));
  const restored = restoreLearningColumns(stored, defaults);
  assert.deepEqual(restored.map(column => column.key), defaults.map(column => column.key));
  assert.equal(restored.find(column => column.key === 'field').visible, true);
  assert.equal(restored.find(column => column.key === 'value').visible, true);
  assert.equal(restored.find(column => column.key === 'supplierKey').width, 180);
  assert.deepEqual(restoreLearningColumns(restored, defaults), restored);
});

test('removing duplicate field columns retains Field, Value and all other table preferences', () => {
  const defaults = ['companyName', 'supplierKey', 'field', 'value', 'status', 'consistency', 'total', 'lastSeen']
    .map(key => ({ key, visible: true, width: 160 }));
  const stored = [...defaults, { key: 'learned:expense_account', visible: true, width: 160 },
    { key: 'learned:vat_classifier', visible: true, width: 150 }];
  assert.deepEqual(restoreLearningColumns(stored, defaults), defaults);
});

test('status groups partition the same filtered set without double-counting values', () => {
  const all = filterLearningRows(rows, '', {});
  const counts = LEARNING_STATUS_FILTERS.filter(item => item.value).map(item => all.filter(row => row.status === item.value).length);
  assert.deepEqual(counts, [2, 3, 0, 0]);
  assert.equal(counts.reduce((sum, count) => sum + count, 0), all.length);
});

test('company filters use stable IDs even when company names are identical', () => {
  const duplicate = { ...rows[0], id: 'other', companyId: 'other-company' };
  const result = filterLearningRows([...rows, duplicate], '', { companyName: ['other-company'] });
  assert.deepEqual(result.map(row => row.id), ['other']);
});

test('system filters combine company, supplier, field and zero VAT correctly', () => {
  const result = filterLearningRows(rows, '', {
    companyName: ['sample-learning-company'], supplierKey: ['134678891'], field: ['vat_classifier'], vatRate: ['0'],
  });
  assert.equal(result.length, 1);
  assert.equal(result[0].value, 'PVM1');
});

test('search finds suppliers and competing values, and clearing restores all rows', () => {
  assert.equal(filterLearningRows(rows, '  bALtic  ', {}).length, 1);
  assert.equal(filterLearningRows(rows, '6202', {}).length, 3);
  assert.equal(filterLearningRows(rows, 'not present', {}).length, 0);
  assert.equal(filterLearningRows(rows, '', {}).length, rows.length);
});

test('review reasons distinguish insufficient history from conflicting teaching', () => {
  assert.match(learningStatusReason(rows.find(row => row.total === 1)), /1 of 2 required documents/);
  assert.match(learningStatusReason(rows.find(row => row.consistency === 0.6)), /60% agreement is below the 90% threshold/);
});

test('example eligibility never claims real automatic filling', () => {
  const ready = rows.find(row => row.status === 'Used automatically');
  assert.equal(learningStatusLabel(ready), 'Ready · example');
  assert.match(learningStatusReason(ready), /never fills real documents/);
  assert.equal(learningStatusLabel({ ...ready, sample: false }), 'Automatic');
  assert.match(learningStatusReason({ ...ready, sample: false }), /filled automatically/);
});

test('paused and inactive reasons override confidence', () => {
  assert.match(learningStatusReason({ ...rows[0], status: 'Paused' }), /is paused/);
  assert.match(learningStatusReason({ ...rows[0], status: 'Inactive', total: 0 }), /History is retained/);
});

test('view retains shared table tools, grid alignment and opt-in teaching history', () => {
  const view = source('../src/components/OcrMachineLearningView.tsx');
  assert.match(view, /<SystemAddFilters/);
  assert.match(view, /system-table-header-row/);
  assert.equal((view.match(/style=\{\{ gridTemplateColumns \}\}/g) || []).length, 2);
  assert.match(view, /\{expanded && <TeachingHistory/);
  assert.match(view, /data-table-workspace-tools/);
  assert.match(view, /<HorizontalTableScrollbar scrollRef=\{tableScrollRef\}/);
  assert.doesNotMatch(view, /draftFilters/);
  assert.match(view, /changeLearningState\(row.id, action\)/);
  assert.doesNotMatch(view, /key: 'vatRate'|label: 'VAT rate'|label: 'Learned value'.*visible: true/);
  const columnDefinitions = view.slice(view.indexOf('const COLUMNS:'), view.indexOf('const dateTime'));
  assert.match(columnDefinitions, /key: 'field', label: 'Field'.*visible: true/);
  assert.match(columnDefinitions, /key: 'value', label: 'Value the system will use'.*visible: true/);
  assert.doesNotMatch(columnDefinitions, /LEARNING_VALUE_COLUMNS|learned:|label: 'Expense account'|label: 'VAT classifier'/);
  assert.match(view, /key === 'field'\) return .*LEARNING_FIELDS\[row.field\]/);
  assert.doesNotMatch(columnDefinitions, /visible: false/);
  assert.match(view, /setColumns\(current => restoreLearningColumns\(current, COLUMNS\)\)/);
  assert.match(view, /ariaLabel=\{`View \$\{item.documentName\}`\}/);
  assert.match(view, /onOpenDocument=\{onOpenDocument\}/);
  assert.match(source('../src/components/OcrReviewView.tsx'), /<OcrLearningDocumentView/);
  assert.doesNotMatch(view, /aria-label=\{evidence \? 'Reviewed document'/);
});

test('competing values are attached to their own learning record with supplier and field context', () => {
  const view = source('../src/components/OcrMachineLearningView.tsx');
  const details = view.slice(view.indexOf('function CompetingLearningValues'), view.indexOf('function TeachingHistory'));
  assert.match(details, /row.companyName.*row.supplierName.*LEARNING_FIELDS\[row.field\]/);
  assert.match(details, /\{row.supplierName\} · \{LEARNING_FIELDS\[row.field\]\}/);
  assert.match(details, /<dl/);
  assert.match(details, /<dt[^>]*>\{candidate.value\}<\/dt>/);
  assert.match(details, /<dd[^>]*>\{candidate.count\} document/);
  assert.match(details, /py-1\.5 text-\[11px\] leading-4/);
  assert.match(details, /border-l-2 border-\[#007EA7\]\/25/);
  assert.doesNotMatch(details, /rounded-md|font-semibold|flex-col/);
  assert.match(view, /const hasCompetingValues = row.candidates.length > 1/);
  assert.match(view, /\{hasCompetingValues && <CompetingLearningValues row=\{row\} \/>\}\s*\{expanded && <TeachingHistory row=\{row\}/);
});

test('help is an icon-only Dashboard-style popup and the worker queue shortcut is removed', () => {
  const view = source('../src/components/OcrMachineLearningView.tsx');
  const dashboard = source('../src/components/Dashboard.tsx');
  assert.doesNotMatch(view, /Worker review queue|onOpenReviewQueue|ListChecks/);
  assert.doesNotMatch(dashboard, /onOpenReviewQueue/);
  assert.match(view, /useDropdownDismiss\(showHelp, helpRef, \(\) => setShowHelp\(false\)\)/);
  const trigger = view.slice(view.indexOf('<button type="button" aria-label="How it works"'), view.indexOf('{showHelp &&'));
  assert.match(trigger, /<Info size=\{20\}/);
  assert.match(trigger, /aria-haspopup="dialog"/);
  assert.doesNotMatch(trigger, /Chevron|>How it works</);
  const popup = view.slice(view.indexOf('{showHelp &&'), view.indexOf('<OcrBreadcrumb'));
  assert.match(popup, /role="dialog" aria-label="Machine learning information"/);
  assert.match(popup, /absolute right-0 top-9/);
  assert.match(popup, /Auto-fill requires \{LEARNING_MIN_DOCUMENTS\}\+ reviewed documents and \{LEARNING_MIN_CONSISTENCY \* 100\}%\+ agreement/);
  assert.equal((view.match(/Auto-fill requires/g) ?? []).length, 1);
});
